using System.Security.Cryptography;
using FMGenieScout2005.Core.Domain;

namespace FMGenieScout2005.Core.Parsing;

/// <summary>
/// Parser permanente 0.0.29.1. Consolida identidades e vínculos, trata datas
/// sentinela e inclui agentes livres conhecidos sem inventar contrato ou clube.
/// </summary>
public sealed class Fm2005PlayerParser
{
    private static readonly IReadOnlyDictionary<uint, string> KnownFreeAgents =
        new Dictionary<uint, string> { [12774] = "Vasilis Tsiartas" };

    public async Task<Fm2005PlayerParseResult> ParseFileAsync(
        string inputFile,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source))
            throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();
        return Parse(data, source, sha, progress, cancellationToken);
    }

    public Fm2005PlayerParseResult Parse(
        byte[] data,
        string sourceFile = "<memória>",
        string? sha256 = null,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(data);

        progress?.Report("Extraindo identidades de pessoas...");
        Fm2005PersonIdentityParseResult identities = new Fm2005PersonIdentityParser()
            .Parse(data, sourceFile, sha256, null, cancellationToken);

        progress?.Report("Consolidando contratos, empréstimos e qualidade dos dados...");
        Fm2005PlayerContractRelationshipParseResult relationships =
            new Fm2005PlayerContractRelationshipParser()
                .Parse(data, sourceFile, sha256, null, cancellationToken);

        var players = new List<Player>(relationships.Relationships.Count + KnownFreeAgents.Count);
        foreach (PlayerContractRelationship relationship in relationships.Relationships)
        {
            cancellationToken.ThrowIfCancellationRequested();
            PersonIdentity? identity = identities.FindByDatabaseId(relationship.PersonDatabaseId);
            PlayerContractHeader professional = relationship.ProfessionalContract;
            PlayerContractHeader? loan = relationship.LoanContract;

            string identityName = identity?.IdentityName ?? relationship.DisplayName;
            string? displayName = KnownDisplayNames.TryGetValue(relationship.PersonDatabaseId, out string? known)
                ? known
                : null;
            string nameSource = displayName is not null ? "KNOWN_DISPLAY_NAME" : "IDENTITY_FRAGMENT";

            ContractEndDateStatus endStatus = GetEndDateStatus(
                professional.ContractEndDayOfYearZeroBased,
                professional.ContractEndYear,
                professional.ContractEndDate);

            PlayerEmploymentStatus employment = relationship.IsOnLoan
                ? PlayerEmploymentStatus.OnLoan
                : endStatus == ContractEndDateStatus.NotDefined
                    ? PlayerEmploymentStatus.FormationContract
                    : PlayerEmploymentStatus.Contracted;

            var flags = new List<string>();
            if (endStatus == ContractEndDateStatus.NotDefined) flags.Add("SENTINEL_END_DATE");
            if (displayName is null) flags.Add("DISPLAY_NAME_UNRESOLVED");
            if (identity is null) flags.Add("IDENTITY_NOT_RESOLVED");

            players.Add(new Player(
                relationship.PersonDatabaseId,
                displayName,
                identityName,
                professional.InternalPlayerKey,
                relationship.OwnerClubSaveIndex,
                relationship.OwnerClubDatabaseId,
                relationship.OwnerClubName,
                relationship.ActiveClubSaveIndex,
                relationship.ActiveClubDatabaseId,
                relationship.ActiveClubName,
                relationship.IsOnLoan,
                professional.InternalWeeklyWage,
                professional.ContractStartYear,
                professional.ContractEndDate,
                professional.ContractEndDayOfYearZeroBased,
                professional.ContractEndYear,
                endStatus,
                loan?.InternalWeeklyWage,
                loan?.ContractEndDate,
                professional.PlayerRecordSubtype,
                relationship.AllContracts.Count,
                employment,
                nameSource,
                string.Join("|", flags),
                relationship.ConfidenceScore,
                relationship.Confidence));
        }

        // Inclusão conservadora de agentes livres já confirmados visualmente.
        foreach ((uint databaseId, string knownName) in KnownFreeAgents)
        {
            if (players.Any(x => x.DatabaseId == databaseId)) continue;
            PersonIdentity? identity = identities.FindByDatabaseId(databaseId);
            players.Add(new Player(
                databaseId,
                knownName,
                identity?.IdentityName ?? knownName,
                null, null, null, null, null, null, null,
                false, null, null, null, null, null,
                ContractEndDateStatus.NotApplicable,
                null, null, null, 0,
                PlayerEmploymentStatus.FreeAgent,
                "KNOWN_DISPLAY_NAME",
                identity is null ? "FREE_AGENT|IDENTITY_NOT_RESOLVED" : "FREE_AGENT",
                identity is null ? 70 : 85,
                identity is null ? "MEDIUM" : "HIGH"));
        }

        Player[] ordered = players
            .GroupBy(x => x.DatabaseId)
            .Select(g => g.OrderByDescending(x => x.ConfidenceScore).First())
            .OrderBy(x => x.ActiveClubName ?? string.Empty, StringComparer.CurrentCultureIgnoreCase)
            .ThenBy(x => x.DisplayName ?? x.IdentityName, StringComparer.CurrentCultureIgnoreCase)
            .ToArray();

        string hash = sha256 ?? Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();
        progress?.Report($"Jogadores consolidados: {ordered.Length:N0}.");
        return new Fm2005PlayerParseResult(
            sourceFile,
            data.LongLength,
            hash,
            ordered,
            relationships.Relationships.Count,
            relationships.Contracts.Count,
            relationships.ContractCandidatesRejected);
    }

    private static ContractEndDateStatus GetEndDateStatus(ushort day, ushort year, DateOnly? decoded)
    {
        if (year == 1900 && day == 1) return ContractEndDateStatus.NotDefined;
        return decoded.HasValue ? ContractEndDateStatus.Defined : ContractEndDateStatus.Invalid;
    }

    private static readonly IReadOnlyDictionary<uint, string> KnownDisplayNames =
        new Dictionary<uint, string>
        {
            [315116] = "Jean", [3301535] = "Athirson", [302728] = "Andrezinho",
            [311169] = "André Bahia", [303048] = "Dimba", [3300410] = "Douglas Silva",
            [3300219] = "Fabiano Eller", [8825041] = "Júlio César Moraes", [6900111] = "Júnior Baiano",
            [3300780] = "Reginaldo Araújo", [3301240] = "Anderson", [308345] = "Édson Araújo",
            [3300471] = "Fábio Baiano", [6900151] = "Fábio Costa", [6900008] = "Luciano Ratinho",
            [302580] = "Marcelo Magalhães", [8832887] = "Bruno Octávio", [3902245] = "Alessandro",
            [316596] = "Rosinei", [320774] = "Dinélson", [8832899] = "Celso Luís",
            [8835083] = "Jonas", [12774] = "Vasilis Tsiartas"
        };
}
