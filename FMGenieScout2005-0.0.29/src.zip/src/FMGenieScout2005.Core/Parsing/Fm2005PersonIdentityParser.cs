using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using FMGenieScout2005.Core.Domain;

namespace FMGenieScout2005.Core.Parsing;

/// <summary>
/// Lê a tabela de identidades de pessoas descoberta pelo diagnóstico 0.0.21.
/// Layout validado: Int32 NameLength | UTF-16LE Name | UInt16 0 | UInt16 RecordType |
/// UInt32 StructureMarker(189) | UInt32 SequenceIndex | UInt32 DatabaseId.
/// </summary>
public sealed class Fm2005PersonIdentityParser
{
    private const int MinimumNameLength = 2;
    private const int MaximumNameLength = 80;
    private const uint ExpectedStructureMarker = 189;
    private const uint MaximumSequenceIndex = 250_000;
    private const uint MaximumDatabaseId = 25_000_000;
    private const int TailSize = 16;

    public async Task<Fm2005PersonIdentityParseResult> ParseFileAsync(
        string inputFile,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source))
            throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();
        return Parse(data, source, sha, progress, cancellationToken);
    }

    public Fm2005PersonIdentityParseResult Parse(
        ReadOnlySpan<byte> data,
        string sourceFile = "<memória>",
        string? sha256 = null,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        progress?.Report("Extraindo identidades permanentes de pessoas...");
        var accepted = new List<PersonIdentity>();
        int rejected = 0;

        for (int recordOffset = 0; recordOffset <= data.Length - 4 - TailSize; recordOffset++)
        {
            if ((recordOffset & 0x3FFF) == 0) cancellationToken.ThrowIfCancellationRequested();

            int nameLength = BinaryPrimitives.ReadInt32LittleEndian(data.Slice(recordOffset, 4));
            if (nameLength < MinimumNameLength || nameLength > MaximumNameLength) continue;

            int nameByteLength = checked(nameLength * 2);
            int nameOffset = recordOffset + 4;
            int nameEnd = nameOffset + nameByteLength;
            if (nameEnd + TailSize > data.Length) continue;

            if (BinaryPrimitives.ReadUInt16LittleEndian(data.Slice(nameEnd, 2)) != 0) continue;

            string name = Encoding.Unicode.GetString(data.Slice(nameOffset, nameByteLength));
            if (!IsPlausibleName(name)) continue;

            ushort recordType = BinaryPrimitives.ReadUInt16LittleEndian(data.Slice(nameEnd + 2, 2));
            uint marker = BinaryPrimitives.ReadUInt32LittleEndian(data.Slice(nameEnd + 4, 4));
            uint sequenceIndex = BinaryPrimitives.ReadUInt32LittleEndian(data.Slice(nameEnd + 8, 4));
            uint databaseId = BinaryPrimitives.ReadUInt32LittleEndian(data.Slice(nameEnd + 12, 4));

            int score = 0;
            if (marker == ExpectedStructureMarker) score += 60; else { rejected++; continue; }
            if (sequenceIndex is > 0 and <= MaximumSequenceIndex) score += 15; else { rejected++; continue; }
            if (databaseId is > 0 and <= MaximumDatabaseId) score += 15; else { rejected++; continue; }
            if (recordType <= 32) score += 5;
            if (name.Length >= 3) score += 5;

            accepted.Add(new PersonIdentity(
                sequenceIndex,
                databaseId,
                name,
                recordType,
                marker,
                recordOffset,
                nameOffset,
                nameLength,
                score));
        }

        PersonIdentity[] unique = accepted
            .GroupBy(x => x.DatabaseId)
            .Select(g => g
                .OrderByDescending(x => x.ConfidenceScore)
                .ThenBy(x => x.RecordOffset)
                .First())
            .OrderBy(x => x.SequenceIndex)
            .ThenBy(x => x.DatabaseId)
            .ToArray();

        string hash = sha256 ?? Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();
        progress?.Report($"Identidades extraídas: {unique.Length:N0}.");
        return new Fm2005PersonIdentityParseResult(sourceFile, data.Length, hash, unique, rejected);
    }

    private static bool IsPlausibleName(string value)
    {
        if (string.IsNullOrWhiteSpace(value) || value.Length is < MinimumNameLength or > MaximumNameLength) return false;

        int letters = 0;
        foreach (char c in value)
        {
            UnicodeCategory category = char.GetUnicodeCategory(c);
            if (char.IsLetter(c)) letters++;
            else if (!(char.IsDigit(c) || char.IsWhiteSpace(c) || c is '.' or '-' or '\'' or '(' or ')' or '&')) return false;
            if (category is UnicodeCategory.Control or UnicodeCategory.Surrogate or UnicodeCategory.PrivateUse) return false;
        }

        return letters >= 2 && letters * 2 >= value.Length;
    }
}
