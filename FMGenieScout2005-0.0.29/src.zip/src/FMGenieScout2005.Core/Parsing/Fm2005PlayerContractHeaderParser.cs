using System.Buffers.Binary;
using System.Security.Cryptography;
using FMGenieScout2005.Core.Domain;

namespace FMGenieScout2005.Core.Parsing;

/// <summary>
/// Parser permanente do cabeçalho contratual dinâmico do FM 2005.
///
/// A leitura é ancorada por um PersonDatabaseId previamente reconhecido. O parser
/// confirma o cabeçalho em DBID-8/DBID-4/DBID+4 e procura para trás a ocorrência
/// anterior da mesma InternalPlayerKey que delimita o início variável do contrato.
///
/// Layout validado (o byte separador após a chave torna os campos seguintes
/// deliberadamente desalinhados):
/// record+0  InternalPlayerKey (UInt32)
/// record+4  Separator/flags (byte)
/// record+5  CurrentClubSaveIndex (UInt32)
/// record+9  InternalWeeklyWage (UInt32)
/// record+13 ContractEndDayOfYearZeroBased (UInt16)
/// record+15 ContractEndYear (UInt16)
/// record+17 payload variável
/// DBID-8    ContractStartYear (UInt32)
/// DBID-4    InternalPlayerKey repetida (UInt32)
/// DBID+0    PersonDatabaseId (UInt32)
/// DBID+4    PlayerRecordSubtype (byte, normalmente 1 ou 2)
/// </summary>
public sealed class Fm2005PlayerContractHeaderParser
{
    private const int MinimumRecordDistance = 40;
    private const int MaximumRecordDistance = 160;
    private const uint MaximumWeeklyWage = 10_000_000;

    public async Task<Fm2005PlayerContractParseResult> ParseFileAsync(
        string inputFile,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source))
            throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();
        return Parse(data, source, sha, progress, cancellationToken);
    }

    public Fm2005PlayerContractParseResult Parse(
        byte[] data,
        string sourceFile = "<memória>",
        string? sha256 = null,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(data);
        if (data.Length < 64)
            throw new ArgumentException("O payload é pequeno demais.", nameof(data));

        progress?.Report("Extraindo clubes e identidades para ancorar a busca...");
        Fm2005ClubParseResult clubs = new Fm2005ClubParser().Parse(data, cancellationToken);
        Fm2005PersonIdentityParseResult people = new Fm2005PersonIdentityParser()
            .Parse(data, sourceFile, sha256, null, cancellationToken);

        var clubBySaveIndex = clubs.Clubs.ToDictionary(x => x.SaveIndex);
        var acceptedPersonIds = people.People.Select(x => x.DatabaseId).ToHashSet();
        foreach (uint knownId in KnownNames.Keys) acceptedPersonIds.Add(knownId);

        var candidates = new List<PlayerContractHeader>();
        int examined = 0;
        int rejected = 0;

        progress?.Report($"Procurando contratos a partir de {acceptedPersonIds.Count:N0} identidades confiáveis...");
        for (int dbidOffset = 8; dbidOffset <= data.Length - 5; dbidOffset++)
        {
            if ((dbidOffset & 0x3FFF) == 0) cancellationToken.ThrowIfCancellationRequested();

            uint personDatabaseId = ReadUInt32(data, dbidOffset);
            if (!acceptedPersonIds.Contains(personDatabaseId)) continue;

            uint startYear = ReadUInt32(data, dbidOffset - 8);
            uint internalKey = ReadUInt32(data, dbidOffset - 4);
            byte subtype = data[dbidOffset + 4];
            if (startYear is < 1900 or > 2100 || internalKey == 0 || subtype is not (1 or 2))
                continue;

            examined++;
            ContractStartCandidate? record = FindBestRecordStart(
                data, dbidOffset, internalKey, clubBySaveIndex);
            if (record is null)
            {
                rejected++;
                continue;
            }

            int recordStart = record.Offset;
            int variableStart = recordStart + 17;
            int variableEnd = dbidOffset - 8;
            int variableLength = Math.Max(0, variableEnd - variableStart);
            byte[] variablePayload = variableLength == 0
                ? []
                : data.AsSpan(variableStart, variableLength).ToArray();

            PersonIdentity? identity = people.FindByDatabaseId(personDatabaseId);
            string? knownName = KnownNames.TryGetValue(personDatabaseId, out string? resolvedName)
                ? resolvedName
                : null;
            string name = identity?.IdentityName ?? knownName ?? $"DBID {personDatabaseId}";

            int distance = dbidOffset - recordStart;
            int score = record.Score;
            score += startYear <= record.EndYear ? 8 : 0;
            score += identity is not null ? 4 : 0;
            score += distance is >= 53 and <= 122 ? 4 : 0;

            candidates.Add(new PlayerContractHeader(
                personDatabaseId,
                name,
                internalKey,
                record.Club.SaveIndex,
                record.Club.DatabaseId,
                record.Club.FullName,
                record.WeeklyWage,
                record.EndDay,
                record.EndYear,
                record.EndDate,
                startYear,
                subtype,
                recordStart,
                dbidOffset,
                distance + 5,
                variablePayload,
                score,
                score >= 90 ? "HIGH" : score >= 75 ? "MEDIUM" : "LOW"));
        }

        PlayerContractHeader[] unique = candidates
            .GroupBy(x => x.PersonDatabaseId)
            .Select(g => g.OrderByDescending(x => x.ConfidenceScore)
                .ThenBy(x => x.RecordStartOffset)
                .First())
            .OrderBy(x => x.CurrentClubSaveIndex)
            .ThenBy(x => x.DisplayName, StringComparer.CurrentCultureIgnoreCase)
            .ToArray();

        string hash = sha256 ?? Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();
        progress?.Report($"Cabeçalhos contratuais extraídos: {unique.Length:N0}.");
        return new Fm2005PlayerContractParseResult(
            sourceFile, data.LongLength, hash, unique, examined, rejected);
    }

    private static ContractStartCandidate? FindBestRecordStart(
        byte[] data,
        int dbidOffset,
        uint internalKey,
        IReadOnlyDictionary<uint, Club> clubBySaveIndex)
    {
        int searchStart = Math.Max(0, dbidOffset - MaximumRecordDistance);
        int searchEnd = dbidOffset - MinimumRecordDistance;
        ContractStartCandidate? best = null;

        for (int offset = searchStart; offset <= searchEnd && offset <= data.Length - 17; offset++)
        {
            if (ReadUInt32(data, offset) != internalKey) continue;

            // Existe um byte de separação/flags em +4. Os campos confirmados começam em +5.
            uint clubSaveIndex = ReadUInt32(data, offset + 5);
            if (!clubBySaveIndex.TryGetValue(clubSaveIndex, out Club? club) || club is null) continue;

            uint weeklyWage = ReadUInt32(data, offset + 9);
            ushort endDay = ReadUInt16(data, offset + 13);
            ushort endYear = ReadUInt16(data, offset + 15);
            if (weeklyWage > MaximumWeeklyWage || endDay > 365 || endYear is < 1900 or > 2200)
                continue;

            DateOnly? endDate = TryDecodeDate(endDay, endYear);
            bool undefinedSentinel = endYear == 1900 && endDay == 1;
            if (!endDate.HasValue && !undefinedSentinel) continue;

            int distance = dbidOffset - offset;
            int score = 68;
            score += distance is 53 or 62 or 70 or 78 or 86 or 94 or 118 ? 12 : 5;
            score += weeklyWage <= 1_000_000 ? 5 : 0;
            score += data[offset + 4] <= 3 ? 3 : 0;

            var candidate = new ContractStartCandidate(
                offset, club, weeklyWage, endDay, endYear, endDate, score);
            if (best is null || candidate.Score > best.Score ||
                (candidate.Score == best.Score && candidate.Offset > best.Offset))
            {
                best = candidate;
            }
        }

        return best;
    }

    private static DateOnly? TryDecodeDate(ushort dayOfYearZeroBased, ushort year)
    {
        if (year == 1900 && dayOfYearZeroBased == 1) return null;
        try
        {
            int maximumDay = DateTime.IsLeapYear(year) ? 365 : 364;
            if (year < 1901 || year > 2200 || dayOfYearZeroBased > maximumDay) return null;
            DateOnly first = new(year, 1, 1);
            DateOnly value = first.AddDays(dayOfYearZeroBased);
            return value.Year == year ? value : null;
        }
        catch (ArgumentOutOfRangeException)
        {
            return null;
        }
    }

    private static uint ReadUInt32(byte[] data, int offset) =>
        BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(offset, 4));

    private static ushort ReadUInt16(byte[] data, int offset) =>
        BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(offset, 2));

    private sealed record ContractStartCandidate(
        int Offset,
        Club Club,
        uint WeeklyWage,
        ushort EndDay,
        ushort EndYear,
        DateOnly? EndDate,
        int Score);

    private static readonly IReadOnlyDictionary<uint, string> KnownNames = new Dictionary<uint, string>
    {
        [315116] = "Jean",
        [3301535] = "Athirson",
        [302728] = "Andrezinho",
        [311169] = "André Bahia",
        [303048] = "Dimba",
        [3300410] = "Douglas Silva",
        [3300219] = "Fabiano Eller",
        [8825041] = "Júlio César Moraes",
        [6900111] = "Júnior Baiano",
        [3300780] = "Reginaldo Araújo",
        [3301240] = "Anderson",
        [308345] = "Édson Araújo",
        [3300471] = "Fábio Baiano",
        [6900151] = "Fábio Costa",
        [6900008] = "Luciano Ratinho",
        [302580] = "Marcelo Magalhães",
        [8832887] = "Bruno Octávio",
        [3902245] = "Alessandro",
        [316596] = "Rosinei",
        [320774] = "Dinélson"
    };
}
