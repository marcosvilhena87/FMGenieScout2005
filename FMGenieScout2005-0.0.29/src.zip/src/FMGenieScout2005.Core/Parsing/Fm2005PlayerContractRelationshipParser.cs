using System.Buffers.Binary;
using System.Security.Cryptography;
using FMGenieScout2005.Core.Domain;

namespace FMGenieScout2005.Core.Parsing;

/// <summary>
/// Parser permanente 0.0.28.9. Parte de PersonDatabaseIds confiáveis, encontra
/// todos os cabeçalhos contratuais que compartilham a mesma InternalPlayerKey e
/// consolida contrato profissional, empréstimo, clube proprietário e clube ativo.
/// </summary>
public sealed class Fm2005PlayerContractRelationshipParser
{
    private const int MinimumRecordDistance = 40;
    private const int MaximumRecordDistance = 180;
    private const uint MaximumWeeklyWage = 10_000_000;

    public async Task<Fm2005PlayerContractRelationshipParseResult> ParseFileAsync(
        string inputFile,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source))
            throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();
        return Parse(data, source, sha, progress, cancellationToken);
    }

    public Fm2005PlayerContractRelationshipParseResult Parse(
        byte[] data,
        string sourceFile = "<memória>",
        string? sha256 = null,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(data);
        if (data.Length < 64) throw new ArgumentException("O payload é pequeno demais.", nameof(data));

        progress?.Report("Extraindo clubes e identidades...");
        Fm2005ClubParseResult clubs = new Fm2005ClubParser().Parse(data, cancellationToken);
        Fm2005PersonIdentityParseResult people = new Fm2005PersonIdentityParser()
            .Parse(data, sourceFile, sha256, null, cancellationToken);

        Dictionary<uint, Club> clubBySaveIndex = clubs.Clubs.ToDictionary(x => x.SaveIndex);
        HashSet<uint> acceptedPersonIds = people.People.Select(x => x.DatabaseId).ToHashSet();
        foreach (uint id in KnownNames.Keys) acceptedPersonIds.Add(id);

        var contracts = new List<PlayerContractHeader>();
        int anchorsExamined = 0;
        int rejected = 0;

        progress?.Report($"Procurando múltiplos contratos de {acceptedPersonIds.Count:N0} identidades...");
        for (int dbidOffset = 8; dbidOffset <= data.Length - 5; dbidOffset++)
        {
            if ((dbidOffset & 0x3FFF) == 0) cancellationToken.ThrowIfCancellationRequested();

            uint personDatabaseId = ReadUInt32(data, dbidOffset);
            if (!acceptedPersonIds.Contains(personDatabaseId)) continue;

            uint startYear = ReadUInt32(data, dbidOffset - 8);
            uint internalKey = ReadUInt32(data, dbidOffset - 4);
            byte subtype = data[dbidOffset + 4];
            if (startYear is < 1900 or > 2100 || internalKey == 0 || subtype is not (1 or 2))
                continue;

            anchorsExamined++;
            PersonIdentity? identity = people.FindByDatabaseId(personDatabaseId);
            string displayName = identity?.IdentityName
                ?? (KnownNames.TryGetValue(personDatabaseId, out string? knownName) ? knownName : null)
                ?? $"DBID {personDatabaseId}";

            int acceptedAtAnchor = 0;
            foreach (int recordStart in FindRecordStarts(data, dbidOffset, internalKey))
            {
                if (!TryReadHeader(data, recordStart, clubBySaveIndex, out ParsedHeader? parsed) || parsed is null)
                {
                    rejected++;
                    continue;
                }

                int variableStart = recordStart + 17;
                int variableEnd = dbidOffset - 8;
                if (variableEnd < variableStart)
                {
                    rejected++;
                    continue;
                }

                int variableLength = variableEnd - variableStart;
                byte[] variablePayload = variableLength == 0
                    ? []
                    : data.AsSpan(variableStart, variableLength).ToArray();

                int recordLength = dbidOffset - recordStart + 5;
                int score = 78;
                score += recordLength is 53 or 62 or 70 or 78 or 86 or 94 or 108 or 118 or 124 or 132 ? 12 : 5;
                score += parsed.WeeklyWage <= 1_000_000 ? 4 : 0;
                score += data[recordStart + 4] <= 3 ? 2 : 0;

                contracts.Add(new PlayerContractHeader(
                    personDatabaseId,
                    displayName,
                    internalKey,
                    parsed.Club.SaveIndex,
                    parsed.Club.DatabaseId,
                    parsed.Club.FullName,
                    parsed.WeeklyWage,
                    parsed.EndDay,
                    parsed.EndYear,
                    parsed.EndDate,
                    startYear,
                    subtype,
                    recordStart,
                    dbidOffset,
                    recordLength,
                    variablePayload,
                    score,
                    score >= 90 ? "HIGH" : score >= 80 ? "MEDIUM" : "LOW"));
                acceptedAtAnchor++;
            }

            if (acceptedAtAnchor == 0) rejected++;
        }

        PlayerContractHeader[] uniqueContracts = contracts
            .GroupBy(x => new { x.PersonDatabaseId, x.RecordStartOffset, x.CurrentClubSaveIndex })
            .Select(g => g.OrderByDescending(x => x.ConfidenceScore).First())
            .OrderBy(x => x.PersonDatabaseId)
            .ThenBy(x => x.RecordStartOffset)
            .ToArray();

        PlayerContractRelationship[] relationships = uniqueContracts
            .GroupBy(x => x.PersonDatabaseId)
            .Select(BuildRelationship)
            .OrderBy(x => x.ActiveClubSaveIndex)
            .ThenBy(x => x.DisplayName, StringComparer.CurrentCultureIgnoreCase)
            .ToArray();

        string hash = sha256 ?? Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();
        progress?.Report($"Relacionamentos contratuais extraídos: {relationships.Length:N0}; empréstimos: {relationships.Count(x => x.IsOnLoan):N0}.");
        return new Fm2005PlayerContractRelationshipParseResult(
            sourceFile, data.LongLength, hash, relationships, uniqueContracts, anchorsExamined, rejected);
    }

    private static PlayerContractRelationship BuildRelationship(IGrouping<uint, PlayerContractHeader> group)
    {
        PlayerContractHeader[] ordered = group
            .OrderBy(x => x.RecordStartOffset)
            .ThenByDescending(x => x.ConfidenceScore)
            .ToArray();

        PlayerContractHeader professional = ordered[0];
        PlayerContractHeader? loan = ordered.Length > 1 ? ordered[^1] : null;
        PlayerContractHeader active = loan ?? professional;
        PlayerLoanState loanState = loan is null || loan.CurrentClubSaveIndex == professional.CurrentClubSaveIndex
            ? PlayerLoanState.NotOnLoan
            : PlayerLoanState.OnLoan;

        int score = professional.ConfidenceScore;
        if (loan is not null) score = Math.Min(100, (professional.ConfidenceScore + loan.ConfidenceScore) / 2 + 5);
        if (loanState == PlayerLoanState.OnLoan) score = Math.Min(100, score + 3);

        return new PlayerContractRelationship(
            group.Key,
            professional.DisplayName,
            professional,
            loanState == PlayerLoanState.OnLoan ? loan : null,
            ordered,
            professional.CurrentClubSaveIndex,
            professional.CurrentClubDatabaseId,
            professional.CurrentClubName,
            active.CurrentClubSaveIndex,
            active.CurrentClubDatabaseId,
            active.CurrentClubName,
            loanState,
            score,
            score >= 92 ? "HIGH" : score >= 82 ? "MEDIUM" : "LOW");
    }

    private static IEnumerable<int> FindRecordStarts(byte[] data, int dbidOffset, uint internalKey)
    {
        int start = Math.Max(0, dbidOffset - MaximumRecordDistance);
        int end = dbidOffset - MinimumRecordDistance;
        for (int offset = start; offset <= end && offset <= data.Length - 17; offset++)
        {
            if (ReadUInt32(data, offset) == internalKey) yield return offset;
        }
    }

    private static bool TryReadHeader(
        byte[] data,
        int recordStart,
        IReadOnlyDictionary<uint, Club> clubBySaveIndex,
        out ParsedHeader? header)
    {
        header = null;
        if (recordStart < 0 || recordStart + 17 > data.Length) return false;

        uint clubSaveIndex = ReadUInt32(data, recordStart + 5);
        if (!clubBySaveIndex.TryGetValue(clubSaveIndex, out Club? club) || club is null) return false;

        uint weeklyWage = ReadUInt32(data, recordStart + 9);
        ushort endDay = ReadUInt16(data, recordStart + 13);
        ushort endYear = ReadUInt16(data, recordStart + 15);
        if (weeklyWage > MaximumWeeklyWage || endDay > 365 || endYear is < 1900 or > 2200) return false;

        DateOnly? endDate = TryDecodeDate(endDay, endYear);
        bool undefinedSentinel = endYear == 1900 && endDay == 1;
        if (!endDate.HasValue && !undefinedSentinel) return false;
        header = new ParsedHeader(club, weeklyWage, endDay, endYear, endDate);
        return true;
    }

    private static DateOnly? TryDecodeDate(ushort dayOfYearZeroBased, ushort year)
    {
        if (year == 1900 && dayOfYearZeroBased == 1) return null;
        try
        {
            int maximumDay = DateTime.IsLeapYear(year) ? 365 : 364;
            if (year < 1901 || year > 2200 || dayOfYearZeroBased > maximumDay) return null;
            DateOnly value = new DateOnly(year, 1, 1).AddDays(dayOfYearZeroBased);
            return value.Year == year ? value : null;
        }
        catch (ArgumentOutOfRangeException)
        {
            return null;
        }
    }

    private static uint ReadUInt32(byte[] data, int offset) =>
        BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(offset, 4));

    private static ushort ReadUInt16(byte[] data, int offset) =>
        BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(offset, 2));

    private sealed record ParsedHeader(
        Club Club,
        uint WeeklyWage,
        ushort EndDay,
        ushort EndYear,
        DateOnly? EndDate);

    private static readonly IReadOnlyDictionary<uint, string> KnownNames = new Dictionary<uint, string>
    {
        [315116] = "Jean", [3301535] = "Athirson", [302728] = "Andrezinho",
        [311169] = "André Bahia", [303048] = "Dimba", [3300410] = "Douglas Silva",
        [3300219] = "Fabiano Eller", [8825041] = "Júlio César Moraes", [6900111] = "Júnior Baiano",
        [3300780] = "Reginaldo Araújo", [3301240] = "Anderson", [308345] = "Édson Araújo",
        [3300471] = "Fábio Baiano", [6900151] = "Fábio Costa", [6900008] = "Luciano Ratinho",
        [302580] = "Marcelo Magalhães", [8832887] = "Bruno Octávio", [3902245] = "Alessandro",
        [316596] = "Rosinei", [320774] = "Dinélson"
    };
}
