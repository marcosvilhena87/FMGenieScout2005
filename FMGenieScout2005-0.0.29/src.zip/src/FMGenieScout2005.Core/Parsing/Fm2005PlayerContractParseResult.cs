using FMGenieScout2005.Core.Domain;

namespace FMGenieScout2005.Core.Parsing;

public sealed class Fm2005PlayerContractParseResult
{
    private readonly IReadOnlyDictionary<uint, PlayerContractHeader> _byDatabaseId;

    public Fm2005PlayerContractParseResult(
        string sourceFile,
        long sourceSize,
        string sha256,
        IReadOnlyList<PlayerContractHeader> contracts,
        int candidatesExamined,
        int candidatesRejected)
    {
        SourceFile = sourceFile;
        SourceSize = sourceSize;
        Sha256 = sha256;
        Contracts = contracts;
        CandidatesExamined = candidatesExamined;
        CandidatesRejected = candidatesRejected;
        _byDatabaseId = contracts
            .GroupBy(x => x.PersonDatabaseId)
            .ToDictionary(g => g.Key, g => g.OrderByDescending(x => x.ConfidenceScore).First());
    }

    public string SourceFile { get; }
    public long SourceSize { get; }
    public string Sha256 { get; }
    public IReadOnlyList<PlayerContractHeader> Contracts { get; }
    public int CandidatesExamined { get; }
    public int CandidatesRejected { get; }

    public PlayerContractHeader? FindByPersonDatabaseId(uint databaseId) =>
        _byDatabaseId.TryGetValue(databaseId, out PlayerContractHeader? contract) ? contract : null;

    public IReadOnlyList<PlayerContractHeader> FindByClubDatabaseId(uint clubDatabaseId) =>
        Contracts.Where(x => x.CurrentClubDatabaseId == clubDatabaseId)
            .OrderBy(x => x.DisplayName, StringComparer.CurrentCultureIgnoreCase)
            .ToArray();
}
