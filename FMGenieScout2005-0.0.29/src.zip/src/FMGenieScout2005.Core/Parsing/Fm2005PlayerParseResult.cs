using FMGenieScout2005.Core.Domain;

namespace FMGenieScout2005.Core.Parsing;

public sealed class Fm2005PlayerParseResult
{
    private readonly IReadOnlyDictionary<uint, Player> _byDatabaseId;

    public Fm2005PlayerParseResult(
        string sourceFile,
        long sourceSize,
        string sha256,
        IReadOnlyList<Player> players,
        int relationshipCount,
        int contractCount,
        int rejectedContractCandidates)
    {
        SourceFile = sourceFile;
        SourceSize = sourceSize;
        Sha256 = sha256;
        Players = players;
        RelationshipCount = relationshipCount;
        ContractCount = contractCount;
        RejectedContractCandidates = rejectedContractCandidates;
        _byDatabaseId = players.ToDictionary(x => x.DatabaseId);
    }

    public string SourceFile { get; }
    public long SourceSize { get; }
    public string Sha256 { get; }
    public IReadOnlyList<Player> Players { get; }
    public int RelationshipCount { get; }
    public int ContractCount { get; }
    public int RejectedContractCandidates { get; }

    public Player? FindByDatabaseId(uint databaseId) =>
        _byDatabaseId.TryGetValue(databaseId, out Player? player) ? player : null;

    public IReadOnlyList<Player> SearchByName(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return [];
        string query = text.Trim();
        return Players
            .Where(x => (x.DisplayName?.Contains(query, StringComparison.OrdinalIgnoreCase) ?? false)
                || x.IdentityName.Contains(query, StringComparison.OrdinalIgnoreCase))
            .OrderBy(x => x.DisplayName ?? x.IdentityName, StringComparer.CurrentCultureIgnoreCase)
            .ToArray();
    }

    public IReadOnlyList<Player> FindByActiveClubDatabaseId(uint clubDatabaseId) =>
        Players.Where(x => x.ActiveClubDatabaseId == clubDatabaseId)
            .OrderBy(x => x.DisplayName ?? x.IdentityName, StringComparer.CurrentCultureIgnoreCase)
            .ToArray();

    public IReadOnlyList<Player> FindByOwnerClubDatabaseId(uint clubDatabaseId) =>
        Players.Where(x => x.OwnerClubDatabaseId == clubDatabaseId)
            .OrderBy(x => x.DisplayName ?? x.IdentityName, StringComparer.CurrentCultureIgnoreCase)
            .ToArray();

    public IReadOnlyList<Player> FindLoans() =>
        Players.Where(x => x.IsOnLoan)
            .OrderBy(x => x.DisplayName ?? x.IdentityName, StringComparer.CurrentCultureIgnoreCase)
            .ToArray();
}
