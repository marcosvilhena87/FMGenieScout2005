using FMGenieScout2005.Core.Domain;

namespace FMGenieScout2005.Core.Parsing;

public sealed class Fm2005PersonIdentityParseResult
{
    private readonly IReadOnlyDictionary<uint, PersonIdentity> _byDatabaseId;
    private readonly IReadOnlyDictionary<uint, PersonIdentity> _bySequenceIndex;

    public Fm2005PersonIdentityParseResult(
        string sourceFile,
        long sourceSize,
        string sha256,
        IReadOnlyList<PersonIdentity> people,
        int rejectedCandidateCount)
    {
        SourceFile = sourceFile;
        SourceSize = sourceSize;
        Sha256 = sha256;
        People = people;
        RejectedCandidateCount = rejectedCandidateCount;
        _byDatabaseId = people.ToDictionary(x => x.DatabaseId);
        _bySequenceIndex = people
            .GroupBy(x => x.SequenceIndex)
            .ToDictionary(g => g.Key, g => g.OrderByDescending(x => x.ConfidenceScore).First());
    }

    public string SourceFile { get; }
    public long SourceSize { get; }
    public string Sha256 { get; }
    public IReadOnlyList<PersonIdentity> People { get; }
    public int RejectedCandidateCount { get; }

    public PersonIdentity? FindByDatabaseId(uint databaseId) =>
        _byDatabaseId.TryGetValue(databaseId, out PersonIdentity? person) ? person : null;

    public PersonIdentity? FindBySequenceIndex(uint sequenceIndex) =>
        _bySequenceIndex.TryGetValue(sequenceIndex, out PersonIdentity? person) ? person : null;

    public IReadOnlyList<PersonIdentity> SearchByName(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return [];
        return People
            .Where(x => x.IdentityName.Contains(text.Trim(), StringComparison.OrdinalIgnoreCase))
            .OrderBy(x => x.IdentityName, StringComparer.CurrentCultureIgnoreCase)
            .ToArray();
    }
}
