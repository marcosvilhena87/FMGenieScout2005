using FMGenieScout2005.Core.Domain;

namespace FMGenieScout2005.Core.Parsing;

public sealed class Fm2005PlayerContractRelationshipParseResult
{
    private readonly IReadOnlyDictionary<uint, PlayerContractRelationship> _byPersonDatabaseId;

    public Fm2005PlayerContractRelationshipParseResult(
        string sourceFile,
        long sourceSize,
        string sha256,
        IReadOnlyList<PlayerContractRelationship> relationships,
        IReadOnlyList<PlayerContractHeader> contracts,
        int personAnchorsExamined,
        int contractCandidatesRejected)
    {
        SourceFile = sourceFile;
        SourceSize = sourceSize;
        Sha256 = sha256;
        Relationships = relationships;
        Contracts = contracts;
        PersonAnchorsExamined = personAnchorsExamined;
        ContractCandidatesRejected = contractCandidatesRejected;
        _byPersonDatabaseId = relationships.ToDictionary(x => x.PersonDatabaseId);
    }

    public string SourceFile { get; }
    public long SourceSize { get; }
    public string Sha256 { get; }
    public IReadOnlyList<PlayerContractRelationship> Relationships { get; }
    public IReadOnlyList<PlayerContractHeader> Contracts { get; }
    public int PersonAnchorsExamined { get; }
    public int ContractCandidatesRejected { get; }

    public PlayerContractRelationship? FindByPersonDatabaseId(uint databaseId) =>
        _byPersonDatabaseId.TryGetValue(databaseId, out PlayerContractRelationship? relationship)
            ? relationship
            : null;

    public IReadOnlyList<PlayerContractRelationship> FindByOwnerClubDatabaseId(uint clubDatabaseId) =>
        Relationships.Where(x => x.OwnerClubDatabaseId == clubDatabaseId)
            .OrderBy(x => x.DisplayName, StringComparer.CurrentCultureIgnoreCase)
            .ToArray();

    public IReadOnlyList<PlayerContractRelationship> FindByActiveClubDatabaseId(uint clubDatabaseId) =>
        Relationships.Where(x => x.ActiveClubDatabaseId == clubDatabaseId)
            .OrderBy(x => x.DisplayName, StringComparer.CurrentCultureIgnoreCase)
            .ToArray();

    public IReadOnlyList<PlayerContractRelationship> FindLoans() =>
        Relationships.Where(x => x.IsOnLoan)
            .OrderBy(x => x.DisplayName, StringComparer.CurrentCultureIgnoreCase)
            .ToArray();
}
