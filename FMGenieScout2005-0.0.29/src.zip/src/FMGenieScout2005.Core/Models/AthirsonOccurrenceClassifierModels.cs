namespace FMGenieScout2005.Core.Models;

public sealed record AthirsonOccurrenceClassification(
    long AnchorOffset,
    int Ordinal,
    bool IdentityMarker189AtMinus8,
    int Utf16NameCount,
    int KnownValueHitCount,
    int SemanticPairHitCount,
    double LayoutSimilarity,
    int ZeroByteCount,
    int FfffffffCount,
    double Score,
    string Classification,
    string Evidence);

public sealed record AthirsonSemanticComparison(
    string Target,
    string DataType,
    int RelativeOffset,
    long JeanExpected,
    long JeanActual,
    long AthirsonExpected,
    long AthirsonActual,
    bool JeanMatch,
    bool AthirsonMatch,
    string Assessment,
    double Score);

public sealed record AthirsonOccurrenceClassifierReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    long JeanAnchor,
    IReadOnlyList<long> AthirsonAnchors,
    long SelectedAthirsonAnchor,
    IReadOnlyList<AthirsonOccurrenceClassification> Classifications,
    IReadOnlyList<AthirsonSemanticComparison> SemanticComparisons,
    string OutputDirectory,
    DateTimeOffset GeneratedAt);
