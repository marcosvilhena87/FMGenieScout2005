namespace FMGenieScout2005.Core.Models;

public sealed record KnownLoanCase(
    string Player,
    uint PersonDatabaseId,
    uint OwnerClubDatabaseId,
    string OwnerClub,
    uint ActiveClubDatabaseId,
    string ActiveClub,
    string RosterContextClub,
    string ExpectedDirection);

public sealed record LoanRelationshipCaseResult(
    string Player,
    uint PersonDatabaseId,
    bool ContractFound,
    uint? ContractClubSaveIndex,
    uint? ContractClubDatabaseId,
    string? ContractClub,
    uint? ExpectedOwnerSaveIndex,
    uint? ExpectedActiveSaveIndex,
    bool ActiveClubConfirmed,
    int OwnerReferenceHits,
    int DistinctClubReferences,
    string Assessment);

public sealed record LoanClubReferenceHit(
    string Player,
    uint PersonDatabaseId,
    string ReferenceWidth,
    long AbsoluteOffset,
    int RelativeToRecordStart,
    int RelativeToDatabaseId,
    uint ClubSaveIndex,
    uint ClubDatabaseId,
    string ClubName,
    bool IsContractClub,
    bool IsExpectedOwnerClub,
    bool IsExpectedActiveClub,
    string Region,
    string Assessment);

public sealed record LoanOwnerOffsetSummary(
    string ReferenceWidth,
    string AlignmentAnchor,
    int RelativeOffset,
    int PlayersCovered,
    int HitCount,
    string Players,
    string Assessment);

public sealed record LoanRelationshipDiagnosticReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    IReadOnlyList<KnownLoanCase> KnownCases,
    IReadOnlyList<LoanRelationshipCaseResult> Cases,
    IReadOnlyList<LoanClubReferenceHit> Hits,
    IReadOnlyList<LoanOwnerOffsetSummary> OwnerOffsetSummaries,
    int ContractsParsed,
    string OutputDirectory,
    DateTimeOffset GeneratedAtUtc);
