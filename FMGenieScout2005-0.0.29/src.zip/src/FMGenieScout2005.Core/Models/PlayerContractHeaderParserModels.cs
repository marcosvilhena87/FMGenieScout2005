using FMGenieScout2005.Core.Domain;

namespace FMGenieScout2005.Core.Models;

public sealed record PlayerContractValidationRow(
    string Player,
    uint PersonDatabaseId,
    uint ExpectedClubDatabaseId,
    string ExpectedClub,
    bool ContractFound,
    uint? FoundClubSaveIndex,
    uint? FoundClubDatabaseId,
    string? FoundClub,
    uint? InternalWeeklyWage,
    DateOnly? ContractEndDate,
    uint? ContractStartYear,
    byte? RecordSubtype,
    string Assessment);

public sealed record PlayerContractOptionChunk(
    string Player,
    uint PersonDatabaseId,
    int ChunkIndex,
    int RelativeOffsetFromRecordStart,
    string Hex,
    ulong LittleEndianValue,
    int Length,
    string Assessment);

public sealed record PlayerContractHeaderParserReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    IReadOnlyList<PlayerContractHeader> Contracts,
    IReadOnlyList<PlayerContractValidationRow> Validation,
    IReadOnlyList<PlayerContractOptionChunk> OptionChunks,
    int CandidatesExamined,
    int CandidatesRejected,
    string OutputDirectory,
    DateTimeOffset GeneratedAtUtc);
