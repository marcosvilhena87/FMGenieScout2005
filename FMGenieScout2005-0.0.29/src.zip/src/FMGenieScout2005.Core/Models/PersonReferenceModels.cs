namespace FMGenieScout2005.Core.Models;

public sealed record KnownPersonReferenceSample(
    string DisplayName,
    uint DatabaseId);

public sealed record PersonReferenceOccurrence(
    string DisplayName,
    uint DatabaseId,
    uint InternalPersonId,
    string ReferenceKind,
    long Offset,
    long RelativeToIdentityRecord,
    bool IsIdentityRecordOccurrence,
    string ContextHex);

public sealed record PersonReferenceClubHit(
    string DisplayName,
    uint DatabaseId,
    uint InternalPersonId,
    string ReferenceKind,
    long ReferenceOffset,
    string ClubReferenceKind,
    string DataType,
    uint ClubReferenceValue,
    long ClubReferenceOffset,
    int RelativeOffset,
    bool IsIdentityRecordOccurrence);

public sealed record PersonReferenceOffsetSummary(
    string ReferenceKind,
    string ClubReferenceKind,
    string DataType,
    int RelativeOffset,
    int DistinctPlayers,
    int TotalHits,
    string Players,
    string Assessment);

public sealed record PersonReferenceDiagnosticReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    uint ClubDatabaseId,
    uint ClubSaveIndex,
    IReadOnlyList<PersonReferenceOccurrence> Occurrences,
    IReadOnlyList<PersonReferenceClubHit> ClubHits,
    IReadOnlyList<PersonReferenceOffsetSummary> OffsetSummaries,
    IReadOnlyList<string> MissingPeople,
    string OutputDirectory,
    DateTimeOffset GeneratedAtUtc);
