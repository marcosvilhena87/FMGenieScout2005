using FMGenieScout2005.Core.Domain;

namespace FMGenieScout2005.Core.Models;

public sealed record KnownPlayerValidation(
    string Player,
    uint DatabaseId,
    uint? ExpectedOwnerClubDatabaseId,
    uint? ExpectedActiveClubDatabaseId,
    bool ExpectedLoan,
    PlayerEmploymentStatus ExpectedEmploymentStatus);

public sealed record PlayerValidationResult(
    string Player,
    uint DatabaseId,
    bool Found,
    string? OwnerClub,
    string? ActiveClub,
    bool? IsOnLoan,
    PlayerEmploymentStatus? EmploymentStatus,
    bool OwnerMatches,
    bool ActiveMatches,
    bool LoanMatches,
    bool EmploymentMatches,
    string Assessment);

public sealed record PlayerParserReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    IReadOnlyList<Player> Players,
    IReadOnlyList<KnownPlayerValidation> KnownValidations,
    IReadOnlyList<PlayerValidationResult> ValidationResults,
    int RelationshipCount,
    int ContractCount,
    int RejectedContractCandidates,
    string OutputDirectory,
    DateTimeOffset GeneratedAtUtc);
