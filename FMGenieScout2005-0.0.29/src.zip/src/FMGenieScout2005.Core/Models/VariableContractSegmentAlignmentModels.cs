namespace FMGenieScout2005.Core.Models;

public sealed record ContractSegmentLandmark(
    string Player,
    string Landmark,
    long AnchorOffset,
    int RelativeOffset,
    long AbsoluteOffset,
    long Value,
    string DataType,
    string Confidence);

public sealed record VariableContractSegment(
    string Player,
    int SegmentIndex,
    string StartLandmark,
    string EndLandmark,
    int StartRelativeOffset,
    int EndRelativeOffset,
    int Length,
    string Signature,
    int ZeroBytes,
    int FfffffffCount,
    string HexPreview);

public sealed record ContractSegmentAlignment(
    int AlignmentIndex,
    string JeanStartLandmark,
    string JeanEndLandmark,
    string AthirsonStartLandmark,
    string AthirsonEndLandmark,
    int JeanLength,
    int AthirsonLength,
    double CategorySimilarity,
    string Assessment,
    string Evidence);

public sealed record VariableContractSegmentAlignmentReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    long JeanAnchor,
    long AthirsonAnchor,
    IReadOnlyList<ContractSegmentLandmark> Landmarks,
    IReadOnlyList<VariableContractSegment> Segments,
    IReadOnlyList<ContractSegmentAlignment> Alignments,
    string OutputDirectory,
    DateTimeOffset GeneratedAt);
