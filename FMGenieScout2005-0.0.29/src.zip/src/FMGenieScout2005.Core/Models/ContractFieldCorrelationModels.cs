namespace FMGenieScout2005.Core.Models;

public sealed record KnownContractSample(
    string DisplayName,
    uint PersonDatabaseId,
    uint ExpectedClubDatabaseId,
    string ExpectedClubName,
    int MonthlyWage,
    DateOnly ExpirationDate,
    string SquadStatus,
    string SampleStatus);

public sealed record RosterIdentitySample(
    string DisplayName,
    uint PersonDatabaseId,
    uint ExpectedClubDatabaseId,
    string ExpectedClubName);

public sealed record ContractPersonReference(
    string DisplayName,
    uint PersonDatabaseId,
    uint InternalPersonId,
    uint ExpectedClubDatabaseId,
    string ReferenceKind,
    long ReferenceOffset,
    bool IsIdentityOccurrence);

public sealed record ContractSalaryHit(
    string DisplayName,
    uint PersonDatabaseId,
    string ReferenceKind,
    long ReferenceOffset,
    string Representation,
    long EncodedValue,
    long ValueOffset,
    int RelativeOffset,
    int MonthlyWage);

public sealed record ContractDateHit(
    string DisplayName,
    uint PersonDatabaseId,
    string ReferenceKind,
    long ReferenceOffset,
    string Representation,
    string EncodedValue,
    long ValueOffset,
    int RelativeOffset,
    DateOnly ExpirationDate);

public sealed record ContractClubHit(
    string DisplayName,
    uint PersonDatabaseId,
    string ReferenceKind,
    long ReferenceOffset,
    string Width,
    uint ClubSaveIndex,
    long ValueOffset,
    int RelativeOffset,
    uint ResolvedClubDatabaseId,
    string ResolvedClubName,
    bool ExpectedClub);

public sealed record ContractCorrelationCandidate(
    string DisplayName,
    uint PersonDatabaseId,
    string ReferenceKind,
    long ReferenceOffset,
    bool IsIdentityOccurrence,
    int MonthlyWage,
    DateOnly ExpirationDate,
    uint ExpectedClubDatabaseId,
    string ExpectedClubName,
    string SalaryRepresentation,
    int? SalaryRelativeOffset,
    string DateRepresentation,
    int? DateRelativeOffset,
    string ClubWidth,
    int? ClubRelativeOffset,
    uint? ResolvedClubDatabaseId,
    string? ResolvedClubName,
    int EvidenceScore,
    string Assessment,
    string ContextHex);

public sealed record ContractFieldOffsetSummary(
    string EvidenceKind,
    string ReferenceKind,
    string Representation,
    int RelativeOffset,
    int DistinctPlayers,
    int FlamengoPlayers,
    int CorinthiansPlayers,
    string PlayerNames,
    string Assessment);

public sealed record ContractFieldCorrelationReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    uint FlamengoSaveIndex,
    uint CorinthiansSaveIndex,
    IReadOnlyList<KnownContractSample> KnownContracts,
    IReadOnlyList<RosterIdentitySample> RosterSamples,
    IReadOnlyList<ContractPersonReference> PersonReferences,
    IReadOnlyList<ContractSalaryHit> SalaryHits,
    IReadOnlyList<ContractDateHit> DateHits,
    IReadOnlyList<ContractClubHit> ClubHits,
    IReadOnlyList<ContractCorrelationCandidate> Candidates,
    IReadOnlyList<ContractFieldOffsetSummary> OffsetSummaries,
    IReadOnlyList<string> MissingPeople,
    string OutputDirectory,
    DateTimeOffset GeneratedAtUtc);
