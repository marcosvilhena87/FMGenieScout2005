namespace FMGenieScout2005.Core.Models;

public sealed record JeanContractFieldValue(
    int RelativeOffset,
    long AbsoluteOffset,
    string DataType,
    string RawHex,
    string Value,
    string Interpretation,
    double Score);

public sealed record JeanDuplicateField(
    string DataType,
    string Value,
    int FirstRelativeOffset,
    int SecondRelativeOffset,
    int Distance,
    int Occurrences);

public sealed record JeanKnownValueCandidate(
    string Target,
    string Representation,
    string ExpectedValue,
    int RelativeOffset,
    long AbsoluteOffset,
    string ActualValue,
    double ErrorRatio,
    string Assessment);

public sealed record JeanContractRecordFieldReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    uint PersonDatabaseId,
    IReadOnlyList<long> AnchorOffsets,
    IReadOnlyList<JeanContractFieldValue> Fields,
    IReadOnlyList<JeanDuplicateField> Duplicates,
    IReadOnlyList<JeanKnownValueCandidate> KnownValueCandidates,
    string OutputDirectory,
    DateTimeOffset GeneratedAt);
