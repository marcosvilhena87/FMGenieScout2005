namespace FMGenieScout2005.Core.Models;

public sealed record KnownMultiContractLoanCase(
    string Player,
    uint PersonDatabaseId,
    uint OwnerClubDatabaseId,
    string OwnerClub,
    uint ActiveClubDatabaseId,
    string ActiveClub,
    string ExpectedDirection);

public sealed record LoanContractCandidate(
    string Player,
    uint PersonDatabaseId,
    uint InternalPlayerKey,
    long RecordStartOffset,
    long? PersonDatabaseIdOffset,
    string DiscoveryMethod,
    uint ClubSaveIndex,
    uint ClubDatabaseId,
    string ClubName,
    uint InternalWeeklyWage,
    ushort EndDayOfYearZeroBased,
    ushort EndYear,
    DateOnly? EndDate,
    uint? ContractStartYear,
    byte Separator,
    byte? PlayerRecordSubtype,
    int RecordLengthToDatabaseId,
    string ContractKind,
    int ConfidenceScore,
    string Assessment);

public sealed record LoanOptionEntry(
    string Player,
    uint PersonDatabaseId,
    long ContractRecordStart,
    string ContractKind,
    int EntryIndex,
    int RelativeOffset,
    string RawHex,
    byte Byte0,
    byte Byte1,
    ushort UInt16At0,
    ushort UInt16At2,
    uint UInt32At0,
    uint UInt32At4,
    uint? ResolvedClubSaveIndex,
    uint? ResolvedClubDatabaseId,
    string? ResolvedClubName,
    string Assessment);

public sealed record LoanMultiContractCaseResult(
    string Player,
    uint PersonDatabaseId,
    bool ProfessionalContractFound,
    string? ProfessionalClub,
    bool LoanContractFound,
    string? LoanClub,
    bool OwnerConfirmed,
    bool ActiveConfirmed,
    int ContractCandidates,
    int OptionEntries,
    string ExpectedDirection,
    string Assessment);

public sealed record LoanOptionTypeSummary(
    int RelativeOffset,
    int EntryIndex,
    int PlayersCovered,
    int HitCount,
    string ResolvedClubs,
    string Players,
    string Assessment);

public sealed record LoanOptionEntryDiagnosticReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    IReadOnlyList<KnownMultiContractLoanCase> KnownCases,
    IReadOnlyList<LoanContractCandidate> Contracts,
    IReadOnlyList<LoanOptionEntry> Entries,
    IReadOnlyList<LoanMultiContractCaseResult> Cases,
    IReadOnlyList<LoanOptionTypeSummary> Summaries,
    string OutputDirectory,
    DateTimeOffset GeneratedAtUtc);
