namespace FMGenieScout2005.Core.Models;

public sealed record KnownPostIdPlayer(string Name, uint DatabaseId, int? ContractStartYear, string ExpectedClub);

public sealed record PostIdPlayerAnchor(
    string Player,
    uint DatabaseId,
    long AnchorOffset,
    int CandidateCount,
    double SelectionScore,
    uint ContractStartYear,
    uint InternalKey,
    byte RecordSubtype,
    string Assessment);

public sealed record PostIdFieldValue(
    string Player,
    uint DatabaseId,
    long AnchorOffset,
    int RelativeOffset,
    string DataType,
    long SignedValue,
    ulong UnsignedValue,
    string Hex,
    string Category,
    bool Aligned);

public sealed record PostIdFieldSummary(
    int RelativeOffset,
    string DataType,
    int PlayerCount,
    int DistinctValueCount,
    int ZeroCount,
    int FfffffffCount,
    bool SameCategoryAcrossPlayers,
    bool DuplicateWithPreviousField,
    string Values,
    string Assessment);

public sealed record InternalKeyOccurrence(
    string Player,
    uint InternalKey,
    long SourceAnchor,
    long OccurrenceOffset,
    int RelativeToSource,
    string ContextHex,
    string Assessment);

public sealed record PostIdPlayerRecordFieldReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    IReadOnlyList<PostIdPlayerAnchor> Anchors,
    IReadOnlyList<PostIdFieldValue> Fields,
    IReadOnlyList<PostIdFieldSummary> Summaries,
    IReadOnlyList<InternalKeyOccurrence> InternalKeyOccurrences,
    string OutputDirectory,
    DateTimeOffset GeneratedAt);
