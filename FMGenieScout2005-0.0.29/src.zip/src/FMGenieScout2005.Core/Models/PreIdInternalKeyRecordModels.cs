namespace FMGenieScout2005.Core.Models;

public sealed record PreIdInternalKeyAnchor(
    string Player,
    uint DatabaseId,
    byte RecordSubtype,
    long DatabaseIdOffset,
    uint ContractStartYear,
    uint InternalKey,
    long PreviousKeyOffset,
    int PreviousKeyDistance,
    int SegmentLength,
    int PreviousKeyCandidateCount,
    string Assessment);

public sealed record PreIdInternalKeyField(
    string Player,
    uint DatabaseId,
    byte RecordSubtype,
    int SegmentLength,
    string AlignmentOrigin,
    int RelativeOffset,
    string DataType,
    long SignedValue,
    ulong UnsignedValue,
    string Hex,
    string Category);

public sealed record PreIdSegmentSignature(
    byte RecordSubtype,
    int SegmentLength,
    int PlayerCount,
    string Players,
    string Signature,
    string Assessment);

public sealed record PreIdAlignedFieldSummary(
    byte RecordSubtype,
    string AlignmentOrigin,
    int RelativeOffset,
    string DataType,
    int PlayerCount,
    int DistinctValueCount,
    int ZeroCount,
    int FfffffffCount,
    string Values,
    string Assessment);

public sealed record PreIdInternalKeyRecordReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    IReadOnlyList<PreIdInternalKeyAnchor> Anchors,
    IReadOnlyList<PreIdInternalKeyField> Fields,
    IReadOnlyList<PreIdSegmentSignature> Signatures,
    IReadOnlyList<PreIdAlignedFieldSummary> Summaries,
    string OutputDirectory,
    DateTimeOffset GeneratedAt);
