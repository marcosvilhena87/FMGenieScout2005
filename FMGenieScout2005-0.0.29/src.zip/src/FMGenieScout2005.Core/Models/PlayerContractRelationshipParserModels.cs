using FMGenieScout2005.Core.Domain;

namespace FMGenieScout2005.Core.Models;

public sealed record KnownRelationshipValidation(
    string Player,
    uint PersonDatabaseId,
    uint ExpectedOwnerClubDatabaseId,
    string ExpectedOwnerClub,
    uint ExpectedActiveClubDatabaseId,
    string ExpectedActiveClub,
    bool ExpectedLoan);

public sealed record RelationshipValidationResult(
    string Player,
    uint PersonDatabaseId,
    bool Found,
    string? OwnerClub,
    string? ActiveClub,
    bool? IsOnLoan,
    bool OwnerMatches,
    bool ActiveMatches,
    bool LoanMatches,
    string Assessment);

public sealed record PlayerContractRelationshipParserReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    IReadOnlyList<PlayerContractRelationship> Relationships,
    IReadOnlyList<PlayerContractHeader> Contracts,
    IReadOnlyList<KnownRelationshipValidation> KnownValidations,
    IReadOnlyList<RelationshipValidationResult> ValidationResults,
    int PersonAnchorsExamined,
    int ContractCandidatesRejected,
    string OutputDirectory,
    DateTimeOffset GeneratedAtUtc);
