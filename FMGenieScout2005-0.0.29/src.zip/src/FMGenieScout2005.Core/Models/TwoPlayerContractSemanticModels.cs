namespace FMGenieScout2005.Core.Models;

public sealed record TwoPlayerKnownContract(
    string Player,
    uint PersonDatabaseId,
    int BirthYear,
    int ContractStartYear,
    int ContractEndYear,
    int WeeklyWage,
    int AppearanceBonus,
    int GoalBonus,
    int AssistBonus,
    int DisplayedValue,
    int ReleaseClause,
    int AnnualRisePercent);

public sealed record TwoPlayerFieldComparison(
    int RelativeOffset,
    long JeanAbsoluteOffset,
    long AthirsonAbsoluteOffset,
    string DataType,
    string JeanRawHex,
    string AthirsonRawHex,
    string JeanValue,
    string AthirsonValue,
    bool Equal,
    string SemanticAssessment,
    double Score);

public sealed record TwoPlayerKnownValueHit(
    string Player,
    string Target,
    string DataType,
    int ExpectedValue,
    int RelativeOffset,
    long AbsoluteOffset,
    string RawHex,
    long ActualValue,
    string Assessment);

public sealed record TwoPlayerSharedSemanticCandidate(
    string Target,
    string DataType,
    int RelativeOffset,
    int JeanExpected,
    long JeanActual,
    int AthirsonExpected,
    long AthirsonActual,
    bool JeanMatch,
    bool AthirsonMatch,
    string Assessment,
    double Score);

public sealed record TwoPlayerContractSemanticReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    TwoPlayerKnownContract Jean,
    TwoPlayerKnownContract Athirson,
    IReadOnlyList<long> JeanAnchors,
    IReadOnlyList<long> AthirsonAnchors,
    IReadOnlyList<TwoPlayerFieldComparison> FieldComparisons,
    IReadOnlyList<TwoPlayerKnownValueHit> KnownValueHits,
    IReadOnlyList<TwoPlayerSharedSemanticCandidate> SharedCandidates,
    string OutputDirectory,
    DateTimeOffset GeneratedAt);
