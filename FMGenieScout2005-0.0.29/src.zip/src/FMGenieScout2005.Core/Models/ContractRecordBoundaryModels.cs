namespace FMGenieScout2005.Core.Models;

public sealed record ContractBoundarySample(
    string DisplayName,
    uint PersonDatabaseId,
    uint ExpectedClubDatabaseId,
    string ExpectedClubName,
    string SampleGroup);

public sealed record ContractReferenceOccurrence(
    string DisplayName,
    uint PersonDatabaseId,
    uint InternalPersonId,
    uint ExpectedClubDatabaseId,
    string ExpectedClubName,
    string SampleGroup,
    string ReferenceKind,
    uint ReferenceValue,
    long ReferenceOffset,
    bool IsIdentityOccurrence,
    int PreviousZeroRunDistance,
    int NextZeroRunDistance,
    int PreviousReferenceDistance,
    int NextReferenceDistance,
    string StructuralSignature,
    string SignatureHash,
    string ContextHex);

public sealed record ContractSignatureCluster(
    string ReferenceKind,
    string StructuralSignature,
    string SignatureHash,
    int OccurrenceCount,
    int DistinctPlayers,
    int FlamengoPlayers,
    int CorinthiansPlayers,
    int NormalPlayers,
    int SpecialStatusPlayers,
    int MinPreviousZeroRunDistance,
    int MaxPreviousZeroRunDistance,
    int MinNextZeroRunDistance,
    int MaxNextZeroRunDistance,
    string PlayerNames,
    string Assessment);

public sealed record ContractBoundaryCandidate(
    string ReferenceKind,
    int RelativeOffset,
    string BoundaryKind,
    int OccurrenceCount,
    int DistinctPlayers,
    int FlamengoPlayers,
    int CorinthiansPlayers,
    string PlayerNames,
    string Assessment);

public sealed record ContractRecordBoundaryReport(
    string SourceFile,
    long SourceSize,
    string Sha256,
    uint FlamengoSaveIndex,
    uint CorinthiansSaveIndex,
    IReadOnlyList<ContractReferenceOccurrence> Occurrences,
    IReadOnlyList<ContractSignatureCluster> SignatureClusters,
    IReadOnlyList<ContractBoundaryCandidate> BoundaryCandidates,
    IReadOnlyList<string> MissingPeople,
    string OutputDirectory,
    DateTimeOffset GeneratedAtUtc);
