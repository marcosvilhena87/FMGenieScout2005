namespace FMGenieScout2005.Core.Domain;

/// <summary>
/// Cabeçalho contratual dinâmico de um jogador no game_db.payload.bin do FM 2005.
/// Os campos foram validados pelos diagnósticos 0.0.28.3 a 0.0.28.5 e corrigidos na 0.0.28.6.1 para considerar o byte separador em record+4.
/// </summary>
public sealed record PlayerContractHeader(
    uint PersonDatabaseId,
    string DisplayName,
    uint InternalPlayerKey,
    uint CurrentClubSaveIndex,
    uint? CurrentClubDatabaseId,
    string? CurrentClubName,
    uint InternalWeeklyWage,
    ushort ContractEndDayOfYearZeroBased,
    ushort ContractEndYear,
    DateOnly? ContractEndDate,
    uint ContractStartYear,
    byte PlayerRecordSubtype,
    long RecordStartOffset,
    long PersonDatabaseIdOffset,
    int RecordLength,
    byte[] VariablePayload,
    int ConfidenceScore,
    string Confidence);
