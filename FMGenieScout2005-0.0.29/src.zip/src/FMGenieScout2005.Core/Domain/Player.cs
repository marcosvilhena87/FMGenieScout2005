namespace FMGenieScout2005.Core.Domain;

public enum PlayerEmploymentStatus
{
    Contracted,
    OnLoan,
    FormationContract,
    FreeAgent,
    Unknown
}

public enum ContractEndDateStatus
{
    Defined,
    NotDefined,
    Invalid,
    NotApplicable
}

/// <summary>
/// Visão consolidada e utilizável de um jogador do Football Manager 2005.
/// Na 0.0.29.1, clubes e contrato passam a ser anuláveis para suportar agentes livres.
/// </summary>
public sealed record Player(
    uint DatabaseId,
    string? DisplayName,
    string IdentityName,
    uint? InternalPlayerKey,
    uint? OwnerClubSaveIndex,
    uint? OwnerClubDatabaseId,
    string? OwnerClubName,
    uint? ActiveClubSaveIndex,
    uint? ActiveClubDatabaseId,
    string? ActiveClubName,
    bool IsOnLoan,
    uint? InternalWeeklyWage,
    uint? ContractStartYear,
    DateOnly? ContractEndDate,
    ushort? ContractEndDayRaw,
    ushort? ContractEndYearRaw,
    ContractEndDateStatus ContractEndDateStatus,
    uint? LoanWeeklyWage,
    DateOnly? LoanEndDate,
    byte? PlayerRecordSubtype,
    int ContractCount,
    PlayerEmploymentStatus EmploymentStatus,
    string NameSource,
    string DataQualityFlags,
    int ConfidenceScore,
    string Confidence);
