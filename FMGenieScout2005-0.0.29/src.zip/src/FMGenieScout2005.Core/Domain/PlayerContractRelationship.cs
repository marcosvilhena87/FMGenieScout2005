namespace FMGenieScout2005.Core.Domain;

public enum PlayerLoanState
{
    NotOnLoan,
    OnLoan
}

public enum LoanDirection
{
    NotApplicable,
    LoanedIn,
    LoanedOut,
    UnrelatedPerspective
}

/// <summary>
/// Consolidação permanente dos contratos ligados à mesma pessoa.
/// O contrato profissional representa o clube proprietário; quando existe,
/// o contrato de empréstimo representa o clube ativo durante o empréstimo.
/// </summary>
public sealed record PlayerContractRelationship(
    uint PersonDatabaseId,
    string DisplayName,
    PlayerContractHeader ProfessionalContract,
    PlayerContractHeader? LoanContract,
    IReadOnlyList<PlayerContractHeader> AllContracts,
    uint OwnerClubSaveIndex,
    uint? OwnerClubDatabaseId,
    string? OwnerClubName,
    uint ActiveClubSaveIndex,
    uint? ActiveClubDatabaseId,
    string? ActiveClubName,
    PlayerLoanState LoanState,
    int ConfidenceScore,
    string Confidence)
{
    public bool IsOnLoan => LoanState == PlayerLoanState.OnLoan;

    public LoanDirection GetDirectionRelativeToClub(uint clubDatabaseId)
    {
        if (!IsOnLoan) return LoanDirection.NotApplicable;
        if (ActiveClubDatabaseId == clubDatabaseId) return LoanDirection.LoanedIn;
        if (OwnerClubDatabaseId == clubDatabaseId) return LoanDirection.LoanedOut;
        return LoanDirection.UnrelatedPerspective;
    }
}
