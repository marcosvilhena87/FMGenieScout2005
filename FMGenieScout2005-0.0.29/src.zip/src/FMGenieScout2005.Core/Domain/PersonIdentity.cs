namespace FMGenieScout2005.Core.Domain;

/// <summary>
/// Identidade permanente de uma pessoa no banco de dados do Football Manager 2005.
/// </summary>
public sealed record PersonIdentity(
    uint SequenceIndex,
    uint DatabaseId,
    string IdentityName,
    ushort RecordType,
    uint StructureMarker,
    long RecordOffset,
    long NameOffset,
    int NameLength,
    int ConfidenceScore);
