using System.Globalization;
using System.Text;
using FMGenieScout2005.Core.Domain;
using FMGenieScout2005.Core.Models;
using FMGenieScout2005.Core.Parsing;

namespace FMGenieScout2005.Core.Diagnostics;

public sealed class PlayerParserDiagnostic
{
    private static readonly KnownPlayerValidation[] KnownValidations =
    [
        new("Reginaldo Araújo", 3300780, 104776, 322, true, PlayerEmploymentStatus.OnLoan),
        new("Anderson", 3301240, 322, 301266, true, PlayerEmploymentStatus.OnLoan),
        new("Édson Araújo", 308345, 319, 104750, true, PlayerEmploymentStatus.OnLoan),
        new("Luciano Ratinho", 6900008, 319, 324, true, PlayerEmploymentStatus.OnLoan),
        new("Marcelo Magalhães", 302580, 319, 324, true, PlayerEmploymentStatus.OnLoan),
        new("Jean", 315116, 322, 322, false, PlayerEmploymentStatus.Contracted),
        new("Athirson", 3301535, 322, 322, false, PlayerEmploymentStatus.Contracted),
        new("Celso Luís", 8832899, null, null, false, PlayerEmploymentStatus.FormationContract),
        new("Jonas", 8835083, null, null, false, PlayerEmploymentStatus.FormationContract),
        new("Vasilis Tsiartas", 12774, null, null, false, PlayerEmploymentStatus.FreeAgent)
    ];

    public async Task<PlayerParserReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        Fm2005PlayerParseResult parsed = await new Fm2005PlayerParser()
            .ParseFileAsync(inputFile, progress, cancellationToken)
            .ConfigureAwait(false);

        PlayerValidationResult[] validation = KnownValidations.Select(expected =>
        {
            Player? actual = parsed.FindByDatabaseId(expected.DatabaseId);
            bool found = actual is not null;
            bool ownerMatches = expected.ExpectedOwnerClubDatabaseId is null
                || actual?.OwnerClubDatabaseId == expected.ExpectedOwnerClubDatabaseId;
            bool activeMatches = expected.ExpectedActiveClubDatabaseId is null
                || actual?.ActiveClubDatabaseId == expected.ExpectedActiveClubDatabaseId;
            bool loanMatches = actual?.IsOnLoan == expected.ExpectedLoan;
            bool employmentMatches = actual?.EmploymentStatus == expected.ExpectedEmploymentStatus;
            string assessment = found && ownerMatches && activeMatches && loanMatches && employmentMatches
                ? "VALIDATED"
                : !found ? "NOT_FOUND" : "REVIEW";

            return new PlayerValidationResult(
                expected.Player,
                expected.DatabaseId,
                found,
                actual?.OwnerClubName,
                actual?.ActiveClubName,
                actual?.IsOnLoan,
                actual?.EmploymentStatus,
                ownerMatches,
                activeMatches,
                loanMatches,
                employmentMatches,
                assessment);
        }).ToArray();

        var report = new PlayerParserReport(
            parsed.SourceFile,
            parsed.SourceSize,
            parsed.Sha256,
            parsed.Players,
            KnownValidations,
            validation,
            parsed.RelationshipCount,
            parsed.ContractCount,
            parsed.RejectedContractCandidates,
            output,
            DateTimeOffset.UtcNow);

        progress?.Report("Gravando base consolidada e relatórios de qualidade...");
        await File.WriteAllTextAsync(Path.Combine(output, "fm2005-player-parser-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "players.csv"), FormatPlayersCsv(report.Players), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "players-on-loan.csv"), FormatPlayersCsv(report.Players.Where(x => x.IsOnLoan)), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "players-free-agents.csv"), FormatPlayersCsv(report.Players.Where(x => x.EmploymentStatus == PlayerEmploymentStatus.FreeAgent)), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "players-formation-contracts.csv"), FormatPlayersCsv(report.Players.Where(x => x.EmploymentStatus == PlayerEmploymentStatus.FormationContract)), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "players-with-undefined-contract-end.csv"), FormatPlayersCsv(report.Players.Where(x => x.ContractEndDateStatus == ContractEndDateStatus.NotDefined)), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "players-data-quality-flags.csv"), FormatPlayersCsv(report.Players.Where(x => !string.IsNullOrWhiteSpace(x.DataQualityFlags))), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "players-by-active-club.csv"), FormatPlayersCsv(report.Players.OrderBy(x => x.ActiveClubName).ThenBy(x => x.DisplayName ?? x.IdentityName)), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "player-parser-validation.csv"), FormatValidationCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "player-parser-contexts.txt"), FormatContexts(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        progress?.Report("Fm2005PlayerParser 0.0.29.1 concluído.");
        return report;
    }

    public static string FormatReportForUi(PlayerParserReport report) => FormatReport(report);

    public static string FormatReport(PlayerParserReport report)
    {
        int loans = report.Players.Count(x => x.IsOnLoan);
        int freeAgents = report.Players.Count(x => x.EmploymentStatus == PlayerEmploymentStatus.FreeAgent);
        int formation = report.Players.Count(x => x.EmploymentStatus == PlayerEmploymentStatus.FormationContract);
        int undefinedDates = report.Players.Count(x => x.ContractEndDateStatus == ContractEndDateStatus.NotDefined);
        int validated = report.ValidationResults.Count(x => x.Assessment == "VALIDATED");
        int ownerClubs = report.Players.Select(x => x.OwnerClubDatabaseId).Where(x => x.HasValue).Distinct().Count();
        int activeClubs = report.Players.Select(x => x.ActiveClubDatabaseId).Where(x => x.HasValue).Distinct().Count();

        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — PlayerParserDataQuality 0.0.29.1");
        sb.AppendLine(new string('=', 96));
        sb.AppendLine($"Arquivo: {report.SourceFile}");
        sb.AppendLine($"Tamanho: {report.SourceSize:N0} bytes");
        sb.AppendLine($"SHA-256: {report.Sha256}");
        sb.AppendLine($"Jogadores consolidados: {report.Players.Count:N0}");
        sb.AppendLine($"Jogadores emprestados: {loans:N0}");
        sb.AppendLine($"Contratos de formação: {formation:N0}");
        sb.AppendLine($"Agentes livres confirmados: {freeAgents:N0}");
        sb.AppendLine($"Datas de término N/D: {undefinedDates:N0}");
        sb.AppendLine($"Clubes proprietários distintos: {ownerClubs:N0}");
        sb.AppendLine($"Clubes ativos distintos: {activeClubs:N0}");
        sb.AppendLine($"Contratos individuais: {report.ContractCount:N0}");
        sb.AppendLine($"Relacionamentos de origem: {report.RelationshipCount:N0}");
        sb.AppendLine($"Candidatos contratuais rejeitados: {report.RejectedContractCandidates:N0}");
        sb.AppendLine($"Validação conhecida: {validated}/{report.ValidationResults.Count}");
        sb.AppendLine();
        sb.AppendLine("Casos conhecidos:");
        foreach (PlayerValidationResult row in report.ValidationResults)
            sb.AppendLine($"  {row.Player,-22} owner={row.OwnerClub ?? "-",-28} active={row.ActiveClub ?? "-",-28} status={row.EmploymentStatus?.ToString() ?? "-",-18} {row.Assessment}");
        sb.AppendLine();
        sb.AppendLine("Sentinela confirmada: EndYear=1900 e EndDay=1 significa término não definido (N/D), não 02/01/1900.");
        sb.AppendLine("Arquivos gerados: players.csv, players-on-loan.csv, players-free-agents.csv, players-formation-contracts.csv, players-with-undefined-contract-end.csv, players-data-quality-flags.csv, players-by-active-club.csv e player-parser-validation.csv.");
        sb.AppendLine("O arquivo de save não foi modificado.");
        return sb.ToString();
    }

    private static string FormatPlayersCsv(IEnumerable<Player> players)
    {
        var sb = new StringBuilder("database_id,display_name,identity_name,name_source,employment_status,internal_player_key,owner_club_save_index,owner_club_database_id,owner_club,active_club_save_index,active_club_database_id,active_club,is_on_loan,weekly_wage_internal,contract_start_year,contract_end_date,contract_end_date_status,contract_end_day_raw,contract_end_year_raw,loan_weekly_wage_internal,loan_end_date,record_subtype,contract_count,data_quality_flags,score,confidence\r\n");
        foreach (Player x in players)
        {
            sb.AppendLine(string.Join(',',
                x.DatabaseId,
                Csv(x.DisplayName),
                Csv(x.IdentityName),
                x.NameSource,
                x.EmploymentStatus,
                x.InternalPlayerKey?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                x.OwnerClubSaveIndex?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                x.OwnerClubDatabaseId?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                Csv(x.OwnerClubName),
                x.ActiveClubSaveIndex?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                x.ActiveClubDatabaseId?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                Csv(x.ActiveClubName),
                x.IsOnLoan,
                x.InternalWeeklyWage?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                x.ContractStartYear?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                x.ContractEndDate?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) ?? string.Empty,
                x.ContractEndDateStatus,
                x.ContractEndDayRaw?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                x.ContractEndYearRaw?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                x.LoanWeeklyWage?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                x.LoanEndDate?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) ?? string.Empty,
                x.PlayerRecordSubtype?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                x.ContractCount,
                Csv(x.DataQualityFlags),
                x.ConfidenceScore,
                x.Confidence));
        }
        return sb.ToString();
    }

    private static string FormatValidationCsv(PlayerParserReport report)
    {
        var sb = new StringBuilder("player,database_id,found,owner_club,active_club,is_on_loan,employment_status,owner_matches,active_matches,loan_matches,employment_matches,assessment\r\n");
        foreach (PlayerValidationResult x in report.ValidationResults)
            sb.AppendLine(string.Join(',', Csv(x.Player), x.DatabaseId, x.Found, Csv(x.OwnerClub), Csv(x.ActiveClub), x.IsOnLoan?.ToString() ?? string.Empty, x.EmploymentStatus?.ToString() ?? string.Empty, x.OwnerMatches, x.ActiveMatches, x.LoanMatches, x.EmploymentMatches, x.Assessment));
        return sb.ToString();
    }

    private static string FormatContexts(PlayerParserReport report)
    {
        var sb = new StringBuilder();
        foreach (Player x in report.Players.Take(500))
        {
            sb.AppendLine($"[{x.DisplayName ?? x.IdentityName}] DBID={x.DatabaseId} identity={x.IdentityName} source={x.NameSource}");
            sb.AppendLine($"  status={x.EmploymentStatus} | owner={x.OwnerClubName ?? "-"} | active={x.ActiveClubName ?? "-"} | loan={x.IsOnLoan}");
            sb.AppendLine($"  wage={x.InternalWeeklyWage?.ToString() ?? "-"} | start={x.ContractStartYear?.ToString() ?? "-"} | end={x.ContractEndDate?.ToString("yyyy-MM-dd") ?? "N/D"} ({x.ContractEndDateStatus}) | flags={x.DataQualityFlags}");
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string Csv(string? value)
    {
        string text = value ?? string.Empty;
        return '"' + text.Replace("\"", "\"\"") + '"';
    }
}
