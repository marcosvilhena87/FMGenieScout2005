using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using FMGenieScout2005.Core.Domain;
using FMGenieScout2005.Core.Models;
using FMGenieScout2005.Core.Parsing;

namespace FMGenieScout2005.Core.Diagnostics;

/// <summary>
/// Procura globalmente referências ao DatabaseId e ao identificador interno de pessoas conhecidas
/// e verifica se essas ocorrências compartilham um vínculo próximo com o Flamengo.
/// Somente leitura; nenhum byte do save é modificado.
/// </summary>
public sealed class PersonReferenceDiagnostic
{
    private const uint FlamengoDatabaseId = 322;
    private const int ClubSearchRadius = 256;
    private const int ContextBefore = 48;
    private const int ContextAfter = 80;

    private static readonly KnownPersonReferenceSample[] KnownPeople =
    [
        new("Andrezinho", 302728),
        new("André Bahia", 311169),
        new("Bruno Santos", 8832815),
        new("Dimba", 303048),
        new("Douglas Silva", 3300410),
        new("Fabiano Eller", 3300219),
        new("Júlio César Moraes", 8825041),
        new("Júnior Baiano", 6900111),
        new("Reginaldo Araújo", 3300780)
    ];

    private readonly Fm2005PersonIdentityParser _personParser = new();
    private readonly Fm2005ClubParser _clubParser = new();

    public async Task<PersonReferenceDiagnosticReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source))
            throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);

        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();

        progress?.Report("Resolvendo identidades e o índice do Flamengo...");
        Fm2005PersonIdentityParseResult people = _personParser.Parse(data, source, sha, progress, cancellationToken);
        Fm2005ClubParseResult clubs = _clubParser.Parse(data, cancellationToken);
        Club? flamengo = clubs.FindByDatabaseId(FlamengoDatabaseId);
        if (flamengo is null)
            throw new InvalidDataException("O Flamengo (ClubDatabaseId 322) não foi localizado no payload.");

        uint clubSaveIndex = flamengo.SaveIndex;
        var occurrences = new List<PersonReferenceOccurrence>();
        var clubHits = new List<PersonReferenceClubHit>();
        var missing = new List<string>();

        foreach (KnownPersonReferenceSample sample in KnownPeople)
        {
            cancellationToken.ThrowIfCancellationRequested();
            PersonIdentity? person = people.FindByDatabaseId(sample.DatabaseId);
            if (person is null)
            {
                missing.Add($"{sample.DisplayName} ({sample.DatabaseId}) — identidade não encontrada");
                continue;
            }

            progress?.Report($"Procurando referências de {sample.DisplayName}...");
            AddReferenceKind(data, sample, person, "DATABASE_ID", sample.DatabaseId,
                person.RecordOffset, occurrences, clubHits, clubSaveIndex, cancellationToken);

            if (person.SequenceIndex != sample.DatabaseId)
            {
                AddReferenceKind(data, sample, person, "INTERNAL_PERSON_ID", person.SequenceIndex,
                    person.RecordOffset, occurrences, clubHits, clubSaveIndex, cancellationToken);
            }
        }

        PersonReferenceOffsetSummary[] summaries = clubHits
            .GroupBy(x => new { x.ReferenceKind, x.ClubReferenceKind, x.DataType, x.RelativeOffset })
            .Select(g =>
            {
                string[] names = g.Select(x => x.DisplayName).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToArray();
                int coverage = names.Length;
                string assessment = coverage >= 6 ? "CANDIDATO_FORTE"
                    : coverage >= 4 ? "CANDIDATO_MEDIO"
                    : coverage >= 2 ? "CANDIDATO_FRACO"
                    : "ISOLADO";
                return new PersonReferenceOffsetSummary(
                    g.Key.ReferenceKind, g.Key.ClubReferenceKind, g.Key.DataType, g.Key.RelativeOffset,
                    coverage, g.Count(), string.Join(" | ", names), assessment);
            })
            .OrderByDescending(x => x.DistinctPlayers)
            .ThenByDescending(x => x.TotalHits)
            .ThenBy(x => x.ReferenceKind)
            .ThenBy(x => Math.Abs(x.RelativeOffset))
            .ToArray();

        var report = new PersonReferenceDiagnosticReport(
            source, data.LongLength, sha, FlamengoDatabaseId, clubSaveIndex,
            occurrences.OrderBy(x => x.DisplayName).ThenBy(x => x.ReferenceKind).ThenBy(x => x.Offset).ToArray(),
            clubHits.OrderBy(x => x.DisplayName).ThenBy(x => x.ReferenceKind).ThenBy(x => x.ReferenceOffset).ThenBy(x => x.ClubReferenceOffset).ToArray(),
            summaries, missing, output, DateTimeOffset.UtcNow);

        progress?.Report("Gravando relatórios de referências globais...");
        await File.WriteAllTextAsync(Path.Combine(output, "person-reference-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "person-reference-occurrences.csv"), FormatOccurrencesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "person-reference-club-hits.csv"), FormatClubHitsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "person-reference-offset-summaries.csv"), FormatSummariesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "person-reference-contexts.txt"), FormatContexts(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllLinesAsync(Path.Combine(output, "people-not-resolved.txt"), report.MissingPeople, new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        progress?.Report("Diagnóstico de referências concluído.");
        return report;
    }

    private static void AddReferenceKind(
        byte[] data,
        KnownPersonReferenceSample sample,
        PersonIdentity person,
        string referenceKind,
        uint value,
        long identityRecordOffset,
        List<PersonReferenceOccurrence> occurrences,
        List<PersonReferenceClubHit> clubHits,
        uint clubSaveIndex,
        CancellationToken cancellationToken)
    {
        byte[] pattern = new byte[4];
        BinaryPrimitives.WriteUInt32LittleEndian(pattern, value);
        foreach (int offset in FindAll(data, pattern, cancellationToken))
        {
            bool identityOccurrence = IsWithin(offset, identityRecordOffset, 64);
            occurrences.Add(new PersonReferenceOccurrence(
                sample.DisplayName, sample.DatabaseId, person.SequenceIndex, referenceKind,
                offset, offset - identityRecordOffset, identityOccurrence,
                HexContext(data, offset, ContextBefore, ContextAfter)));

            AddClubHits(data, sample, person, referenceKind, offset, identityOccurrence,
                FlamengoDatabaseId, "CLUB_DATABASE_ID", clubHits);
            AddClubHits(data, sample, person, referenceKind, offset, identityOccurrence,
                clubSaveIndex, "CLUB_SAVE_INDEX", clubHits);
        }
    }

    private static void AddClubHits(
        byte[] data,
        KnownPersonReferenceSample sample,
        PersonIdentity person,
        string referenceKind,
        int referenceOffset,
        bool identityOccurrence,
        uint clubValue,
        string clubReferenceKind,
        List<PersonReferenceClubHit> output)
    {
        int start = Math.Max(0, referenceOffset - ClubSearchRadius);
        int end = Math.Min(data.Length, referenceOffset + 4 + ClubSearchRadius);

        for (int offset = start; offset <= end - 2; offset++)
        {
            if (BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(offset, 2)) == clubValue && clubValue <= ushort.MaxValue)
            {
                output.Add(new PersonReferenceClubHit(
                    sample.DisplayName, sample.DatabaseId, person.SequenceIndex, referenceKind,
                    referenceOffset, clubReferenceKind, "UINT16", clubValue, offset,
                    offset - referenceOffset, identityOccurrence));
            }

            if (offset <= end - 4 && BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(offset, 4)) == clubValue)
            {
                output.Add(new PersonReferenceClubHit(
                    sample.DisplayName, sample.DatabaseId, person.SequenceIndex, referenceKind,
                    referenceOffset, clubReferenceKind, "UINT32", clubValue, offset,
                    offset - referenceOffset, identityOccurrence));
            }
        }
    }

    private static IEnumerable<int> FindAll(byte[] data, byte[] pattern, CancellationToken cancellationToken)
    {
        for (int i = 0; i <= data.Length - pattern.Length; i++)
        {
            if ((i & 0xFFFF) == 0) cancellationToken.ThrowIfCancellationRequested();
            if (data[i] == pattern[0] && data[i + 1] == pattern[1] && data[i + 2] == pattern[2] && data[i + 3] == pattern[3])
                yield return i;
        }
    }

    private static bool IsWithin(long value, long center, int radius) => value >= center - radius && value <= center + radius;

    private static string HexContext(byte[] data, int center, int before, int after)
    {
        int start = Math.Max(0, center - before);
        int length = Math.Min(data.Length - start, before + 4 + after);
        return Convert.ToHexString(data.AsSpan(start, length));
    }

    public static string FormatReport(PersonReferenceDiagnosticReport report)
    {
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — PersonReferenceDiagnostic 0.0.23");
        sb.AppendLine(new string('=', 94));
        sb.AppendLine($"Arquivo: {report.SourceFile}");
        sb.AppendLine($"Tamanho: {report.SourceSize:N0} bytes");
        sb.AppendLine($"SHA-256: {report.Sha256}");
        sb.AppendLine($"Flamengo: ClubDatabaseId={report.ClubDatabaseId} | SaveClubIndex={report.ClubSaveIndex}");
        sb.AppendLine($"Ocorrências globais de referências: {report.Occurrences.Count:N0}");
        sb.AppendLine($"Hits de clube em ±{ClubSearchRadius} bytes: {report.ClubHits.Count:N0}");
        sb.AppendLine($"Pessoas não resolvidas: {report.MissingPeople.Count:N0}");
        sb.AppendLine();

        sb.AppendLine("Ocorrências por jogador e tipo de referência:");
        foreach (var g in report.Occurrences.GroupBy(x => new { x.DisplayName, x.ReferenceKind }).OrderBy(x => x.Key.DisplayName).ThenBy(x => x.Key.ReferenceKind))
            sb.AppendLine($"  {g.Key.DisplayName,-24} {g.Key.ReferenceKind,-18} ocorrências={g.Count(),4} fora_identidade={g.Count(x => !x.IsIdentityRecordOccurrence),4}");

        sb.AppendLine();
        sb.AppendLine("Melhores offsets pessoa → clube:");
        foreach (PersonReferenceOffsetSummary x in report.OffsetSummaries.Take(40))
            sb.AppendLine($"  {x.ReferenceKind,-18} {x.ClubReferenceKind,-17} {x.DataType,-6} rel={x.RelativeOffset,5} | jogadores={x.DistinctPlayers} hits={x.TotalHits} | {x.Assessment} | {x.Players}");

        sb.AppendLine();
        sb.AppendLine("Interpretação automática:");
        PersonReferenceOffsetSummary? best = report.OffsetSummaries.FirstOrDefault();
        if (best is null || best.DistinctPlayers < 2)
            sb.AppendLine("  INCONCLUSIVO: não apareceu um vínculo repetido entre referência de pessoa e referência de clube.");
        else if (best.DistinctPlayers >= 6)
            sb.AppendLine($"  EVIDÊNCIA_FORTE: {best.ReferenceKind} possui {best.ClubReferenceKind}/{best.DataType} no offset relativo {best.RelativeOffset:+0;-0;0} para {best.DistinctPlayers} jogadores.");
        else
            sb.AppendLine($"  CANDIDATO: melhor padrão cobre {best.DistinctPlayers} jogadores; precisa de validação em outro clube/save.");

        sb.AppendLine();
        sb.AppendLine("Arquivos gerados: person-reference-report.txt, person-reference-occurrences.csv, person-reference-club-hits.csv, person-reference-offset-summaries.csv, person-reference-contexts.txt e people-not-resolved.txt.");
        sb.AppendLine("O arquivo de origem não foi modificado.");
        return sb.ToString();
    }

    private static string FormatOccurrencesCsv(PersonReferenceDiagnosticReport report)
    {
        var sb = new StringBuilder("display_name,database_id,internal_person_id,reference_kind,offset,relative_to_identity_record,is_identity_record_occurrence,context_hex\r\n");
        foreach (PersonReferenceOccurrence x in report.Occurrences)
            sb.AppendLine(string.Join(',', Csv(x.DisplayName), x.DatabaseId, x.InternalPersonId, x.ReferenceKind,
                $"0x{x.Offset:X8}", x.RelativeToIdentityRecord, x.IsIdentityRecordOccurrence, x.ContextHex));
        return sb.ToString();
    }

    private static string FormatClubHitsCsv(PersonReferenceDiagnosticReport report)
    {
        var sb = new StringBuilder("display_name,database_id,internal_person_id,reference_kind,reference_offset,club_reference_kind,data_type,club_value,club_offset,relative_offset,is_identity_record_occurrence\r\n");
        foreach (PersonReferenceClubHit x in report.ClubHits)
            sb.AppendLine(string.Join(',', Csv(x.DisplayName), x.DatabaseId, x.InternalPersonId, x.ReferenceKind,
                $"0x{x.ReferenceOffset:X8}", x.ClubReferenceKind, x.DataType, x.ClubReferenceValue,
                $"0x{x.ClubReferenceOffset:X8}", x.RelativeOffset, x.IsIdentityRecordOccurrence));
        return sb.ToString();
    }

    private static string FormatSummariesCsv(PersonReferenceDiagnosticReport report)
    {
        var sb = new StringBuilder("reference_kind,club_reference_kind,data_type,relative_offset,distinct_players,total_hits,assessment,players\r\n");
        foreach (PersonReferenceOffsetSummary x in report.OffsetSummaries)
            sb.AppendLine(string.Join(',', x.ReferenceKind, x.ClubReferenceKind, x.DataType, x.RelativeOffset,
                x.DistinctPlayers, x.TotalHits, x.Assessment, Csv(x.Players)));
        return sb.ToString();
    }

    private static string FormatContexts(PersonReferenceDiagnosticReport report)
    {
        var sb = new StringBuilder();
        foreach (PersonReferenceOccurrence x in report.Occurrences.Where(x => !x.IsIdentityRecordOccurrence))
        {
            sb.AppendLine($"[{x.DisplayName}] dbid={x.DatabaseId} internal={x.InternalPersonId} tipo={x.ReferenceKind} offset=0x{x.Offset:X8} rel_identidade={x.RelativeToIdentityRecord:+0;-0;0}");
            sb.AppendLine(x.ContextHex);
            foreach (PersonReferenceClubHit hit in report.ClubHits.Where(h => h.DisplayName == x.DisplayName && h.ReferenceKind == x.ReferenceKind && h.ReferenceOffset == x.Offset).OrderBy(h => Math.Abs(h.RelativeOffset)))
                sb.AppendLine($"  clube={hit.ClubReferenceKind}/{hit.DataType} valor={hit.ClubReferenceValue} rel={hit.RelativeOffset:+0;-0;0} offset=0x{hit.ClubReferenceOffset:X8}");
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string Csv(string value) => '"' + value.Replace("\"", "\"\"") + '"';
}
