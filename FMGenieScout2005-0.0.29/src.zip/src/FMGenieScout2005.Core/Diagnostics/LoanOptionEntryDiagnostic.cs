using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;
using FMGenieScout2005.Core.Domain;
using FMGenieScout2005.Core.Models;
using FMGenieScout2005.Core.Parsing;

namespace FMGenieScout2005.Core.Diagnostics;

/// <summary>
/// Diagnóstico 0.0.28.8: procura todos os contratos ligados a uma mesma pessoa,
/// classifica contrato profissional e contrato de empréstimo e decompõe o payload
/// variável em entradas brutas de oito bytes. O save permanece somente leitura.
/// </summary>
public sealed class LoanOptionEntryDiagnostic
{
    private const int MinimumRecordDistance = 40;
    private const int MaximumRecordDistance = 180;
    private const uint MaximumWeeklyWage = 10_000_000;

    private static readonly KnownMultiContractLoanCase[] KnownCases =
    [
        new("Reginaldo Araújo", 3300780, 104776, "Coritiba", 322, "CR Flamengo", "LOANED_IN"),
        new("Anderson", 3301240, 322, "CR Flamengo", 301266, "Caxias", "LOANED_OUT"),
        new("Édson Araújo", 308345, 319, "SC Corinthians Paulista", 104750, "Fortaleza", "LOANED_OUT"),
        new("Luciano Ratinho", 6900008, 319, "SC Corinthians Paulista", 324, "Grêmio", "LOANED_OUT"),
        new("Marcelo Magalhães", 302580, 319, "SC Corinthians Paulista", 324, "Grêmio", "LOANED_OUT")
    ];

    public async Task<LoanOptionEntryDiagnosticReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source)) throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);
        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();
        Fm2005ClubParseResult clubResult = new Fm2005ClubParser().Parse(data, cancellationToken);
        Dictionary<uint, Club> clubBySaveIndex = clubResult.Clubs.ToDictionary(x => x.SaveIndex);
        Dictionary<uint, Club> clubByDatabaseId = clubResult.Clubs.ToDictionary(x => x.DatabaseId);

        var contracts = new List<LoanContractCandidate>();
        var entries = new List<LoanOptionEntry>();

        foreach (KnownMultiContractLoanCase known in KnownCases)
        {
            cancellationToken.ThrowIfCancellationRequested();
            progress?.Report($"Procurando múltiplos contratos: {known.Player}...");
            List<int> dbidOffsets = FindUInt32(data, known.PersonDatabaseId).ToList();
            var discoveredKeys = new HashSet<uint>();

            foreach (int dbidOffset in dbidOffsets)
            {
                if (dbidOffset < 8 || dbidOffset + 5 > data.Length) continue;
                uint startYear = ReadUInt32(data, dbidOffset - 8);
                uint internalKey = ReadUInt32(data, dbidOffset - 4);
                byte subtype = data[dbidOffset + 4];
                if (startYear is < 1900 or > 2100 || internalKey == 0 || subtype is not (1 or 2)) continue;
                discoveredKeys.Add(internalKey);

                foreach (int recordStart in FindRecordStarts(data, dbidOffset, internalKey, clubBySaveIndex))
                {
                    LoanContractCandidate? candidate = BuildCandidate(
                        data, known, recordStart, dbidOffset, startYear, subtype,
                        "DBID_ANCHORED", clubBySaveIndex);
                    if (candidate is not null) contracts.Add(candidate);
                }
            }

            // Fallback: um contrato profissional pode estar referenciado somente pela chave curta.
            foreach (uint internalKey in discoveredKeys)
            {
                foreach (int recordStart in FindUInt32(data, internalKey))
                {
                    if (recordStart + 17 > data.Length) continue;
                    if (!TryReadContractHeader(data, recordStart, clubBySaveIndex, out ParsedHeader header)) continue;
                    if (header.Club.DatabaseId != known.OwnerClubDatabaseId &&
                        header.Club.DatabaseId != known.ActiveClubDatabaseId) continue;
                    if (contracts.Any(x => x.PersonDatabaseId == known.PersonDatabaseId && x.RecordStartOffset == recordStart)) continue;

                    LoanContractCandidate candidate = BuildKeyOnlyCandidate(known, internalKey, recordStart, header);
                    contracts.Add(candidate);
                }
            }
        }

        LoanContractCandidate[] uniqueContracts = contracts
            .GroupBy(x => new { x.PersonDatabaseId, x.RecordStartOffset, x.ClubDatabaseId })
            .Select(g => g.OrderByDescending(x => x.ConfidenceScore).First())
            .OrderBy(x => x.Player)
            .ThenBy(x => x.RecordStartOffset)
            .ToArray();

        foreach (LoanContractCandidate contract in uniqueContracts)
        {
            int payloadStart = checked((int)contract.RecordStartOffset) + 17;
            int payloadEnd = contract.PersonDatabaseIdOffset.HasValue
                ? checked((int)contract.PersonDatabaseIdOffset.Value) - 8
                : Math.Min(data.Length, payloadStart + 128);
            payloadEnd = Math.Clamp(payloadEnd, payloadStart, data.Length);
            ExtractEntries(data, contract, payloadStart, payloadEnd, clubBySaveIndex, entries);
        }

        LoanMultiContractCaseResult[] caseResults = KnownCases.Select(known =>
        {
            LoanContractCandidate[] rows = uniqueContracts.Where(x => x.PersonDatabaseId == known.PersonDatabaseId).ToArray();
            LoanContractCandidate? professional = rows
                .Where(x => x.ClubDatabaseId == known.OwnerClubDatabaseId)
                .OrderByDescending(x => x.ConfidenceScore).FirstOrDefault();
            LoanContractCandidate? loan = rows
                .Where(x => x.ClubDatabaseId == known.ActiveClubDatabaseId)
                .OrderByDescending(x => x.ConfidenceScore).FirstOrDefault();
            bool ownerConfirmed = professional is not null;
            bool activeConfirmed = loan is not null;
            int optionCount = entries.Count(x => x.PersonDatabaseId == known.PersonDatabaseId);
            string assessment = ownerConfirmed && activeConfirmed
                ? "PROFESSIONAL_AND_LOAN_CONTRACTS_CONFIRMED"
                : activeConfirmed
                    ? "LOAN_CONTRACT_CONFIRMED_OWNER_CONTRACT_NOT_FOUND"
                    : ownerConfirmed
                        ? "PROFESSIONAL_CONTRACT_CONFIRMED_LOAN_NOT_FOUND"
                        : "NO_EXPECTED_CONTRACT_FOUND";
            return new LoanMultiContractCaseResult(
                known.Player, known.PersonDatabaseId, ownerConfirmed, professional?.ClubName,
                activeConfirmed, loan?.ClubName, ownerConfirmed, activeConfirmed,
                rows.Length, optionCount, known.ExpectedDirection, assessment);
        }).ToArray();

        LoanOptionTypeSummary[] summaries = entries
            .Where(x => x.ResolvedClubDatabaseId.HasValue)
            .GroupBy(x => new { x.RelativeOffset, x.EntryIndex })
            .Select(g => new LoanOptionTypeSummary(
                g.Key.RelativeOffset, g.Key.EntryIndex,
                g.Select(x => x.PersonDatabaseId).Distinct().Count(), g.Count(),
                string.Join(" | ", g.Select(x => x.ResolvedClubName).Where(x => x is not null).Distinct()),
                string.Join(" | ", g.Select(x => x.Player).Distinct()),
                g.Select(x => x.PersonDatabaseId).Distinct().Count() >= 3 ? "LOAN_OPTION_ENTRY_STRONG" :
                g.Select(x => x.PersonDatabaseId).Distinct().Count() >= 2 ? "LOAN_OPTION_ENTRY_MEDIUM" : "ISOLATED"))
            .OrderByDescending(x => x.PlayersCovered).ThenBy(x => x.RelativeOffset)
            .ToArray();

        var report = new LoanOptionEntryDiagnosticReport(
            source, data.LongLength, sha, KnownCases, uniqueContracts, entries, caseResults,
            summaries, output, DateTimeOffset.UtcNow);

        progress?.Report("Gravando relatórios de múltiplos contratos...");
        await File.WriteAllTextAsync(Path.Combine(output, "loan-option-entry-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "loan-multiple-contracts.csv"), FormatContractsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "loan-option-entries.csv"), FormatEntriesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "loan-case-results.csv"), FormatCasesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "loan-option-entry-summaries.csv"), FormatSummariesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "loan-multiple-contract-contexts.txt"), FormatContexts(report, data), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "loan-unresolved.txt"), FormatUnresolved(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        progress?.Report("LoanOptionEntryDiagnostic concluído.");
        return report;
    }

    private static IEnumerable<int> FindRecordStarts(byte[] data, int dbidOffset, uint internalKey, IReadOnlyDictionary<uint, Club> clubs)
    {
        int start = Math.Max(0, dbidOffset - MaximumRecordDistance);
        int end = dbidOffset - MinimumRecordDistance;
        for (int offset = start; offset <= end; offset++)
            if (ReadUInt32(data, offset) == internalKey && TryReadContractHeader(data, offset, clubs, out _))
                yield return offset;
    }

    private static LoanContractCandidate? BuildCandidate(byte[] data, KnownMultiContractLoanCase known, int recordStart,
        int dbidOffset, uint startYear, byte subtype, string method, IReadOnlyDictionary<uint, Club> clubs)
    {
        if (!TryReadContractHeader(data, recordStart, clubs, out ParsedHeader header)) return null;
        uint key = ReadUInt32(data, recordStart);
        string kind = ClassifyKind(header.Club.DatabaseId, known);
        int score = 80 + (kind != "OTHER_CONTRACT" ? 15 : 0);
        return new LoanContractCandidate(known.Player, known.PersonDatabaseId, key, recordStart, dbidOffset,
            method, header.Club.SaveIndex, header.Club.DatabaseId, header.Club.FullName,
            header.WeeklyWage, header.EndDay, header.EndYear, header.EndDate, startYear,
            data[recordStart + 4], subtype, dbidOffset - recordStart, kind, score,
            score >= 90 ? "HIGH" : "MEDIUM");
    }

    private static LoanContractCandidate BuildKeyOnlyCandidate(KnownMultiContractLoanCase known, uint key, int recordStart, ParsedHeader header)
    {
        string kind = ClassifyKind(header.Club.DatabaseId, known);
        int score = 68 + (kind != "OTHER_CONTRACT" ? 12 : 0);
        return new LoanContractCandidate(known.Player, known.PersonDatabaseId, key, recordStart, null,
            "INTERNAL_KEY_FALLBACK", header.Club.SaveIndex, header.Club.DatabaseId, header.Club.FullName,
            header.WeeklyWage, header.EndDay, header.EndYear, header.EndDate, null,
            0, null, 0, kind, score, score >= 75 ? "MEDIUM" : "LOW");
    }

    private static string ClassifyKind(uint clubDatabaseId, KnownMultiContractLoanCase known) =>
        clubDatabaseId == known.OwnerClubDatabaseId ? "PROFESSIONAL_CONTRACT" :
        clubDatabaseId == known.ActiveClubDatabaseId ? "LOAN_CONTRACT" : "OTHER_CONTRACT";

    private static bool TryReadContractHeader(byte[] data, int offset, IReadOnlyDictionary<uint, Club> clubs, out ParsedHeader header)
    {
        header = default;
        if (offset < 0 || offset + 17 > data.Length) return false;
        uint clubIndex = ReadUInt32(data, offset + 5);
        if (!clubs.TryGetValue(clubIndex, out Club? club) || club is null) return false;
        uint wage = ReadUInt32(data, offset + 9);
        ushort day = ReadUInt16(data, offset + 13);
        ushort year = ReadUInt16(data, offset + 15);
        if (wage > MaximumWeeklyWage || day > 365 || year is < 1900 or > 2200) return false;
        DateOnly? date = TryDecodeDate(day, year);
        if (!date.HasValue) return false;
        header = new ParsedHeader(club, wage, day, year, date.Value);
        return true;
    }

    private static void ExtractEntries(byte[] data, LoanContractCandidate contract, int start, int end,
        IReadOnlyDictionary<uint, Club> clubs, List<LoanOptionEntry> output)
    {
        int index = 0;
        for (int offset = start; offset + 8 <= end; offset += 8, index++)
        {
            ReadOnlySpan<byte> span = data.AsSpan(offset, 8);
            uint a = BinaryPrimitives.ReadUInt32LittleEndian(span[..4]);
            uint b = BinaryPrimitives.ReadUInt32LittleEndian(span[4..]);
            Club? resolved = null;
            uint? resolvedIndex = null;
            if (clubs.TryGetValue(a, out Club? ca) && ca is not null) { resolved = ca; resolvedIndex = a; }
            else if (clubs.TryGetValue(b, out Club? cb) && cb is not null) { resolved = cb; resolvedIndex = b; }
            string assessment = resolved is null ? "RAW_OPTION_ENTRY" : "OPTION_ENTRY_WITH_CLUB_REFERENCE";
            output.Add(new LoanOptionEntry(contract.Player, contract.PersonDatabaseId, contract.RecordStartOffset,
                contract.ContractKind, index, offset - checked((int)contract.RecordStartOffset), Convert.ToHexString(span),
                span[0], span[1], BinaryPrimitives.ReadUInt16LittleEndian(span[..2]),
                BinaryPrimitives.ReadUInt16LittleEndian(span.Slice(2, 2)), a, b,
                resolvedIndex, resolved?.DatabaseId, resolved?.FullName, assessment));
        }
    }

    private static IEnumerable<int> FindUInt32(byte[] data, uint value)
    {
        byte b0 = (byte)value; byte b1 = (byte)(value >> 8); byte b2 = (byte)(value >> 16); byte b3 = (byte)(value >> 24);
        for (int i = 0; i <= data.Length - 4; i++)
            if (data[i] == b0 && data[i + 1] == b1 && data[i + 2] == b2 && data[i + 3] == b3) yield return i;
    }

    private static DateOnly? TryDecodeDate(ushort day, ushort year)
    {
        try { DateOnly d = new DateOnly(year, 1, 1).AddDays(day); return d.Year == year ? d : null; }
        catch (ArgumentOutOfRangeException) { return null; }
    }

    private static uint ReadUInt32(byte[] data, int offset) => BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(offset, 4));
    private static ushort ReadUInt16(byte[] data, int offset) => BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(offset, 2));
    private readonly record struct ParsedHeader(Club Club, uint WeeklyWage, ushort EndDay, ushort EndYear, DateOnly EndDate);

    public static string FormatReportForUi(LoanOptionEntryDiagnosticReport r) => FormatReport(r);
    public static string FormatReport(LoanOptionEntryDiagnosticReport r)
    {
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — LoanOptionEntryDiagnostic 0.0.28.8");
        sb.AppendLine(new string('=', 96));
        sb.AppendLine($"Arquivo: {r.SourceFile}");
        sb.AppendLine($"SHA-256: {r.Sha256}");
        sb.AppendLine($"Contratos candidatos: {r.Contracts.Count:N0}");
        sb.AppendLine($"Entradas variáveis de 8 bytes: {r.Entries.Count:N0}");
        sb.AppendLine($"Casos com contrato profissional e empréstimo confirmados: {r.Cases.Count(x => x.ProfessionalContractFound && x.LoanContractFound)}/{r.Cases.Count}");
        sb.AppendLine();
        foreach (LoanMultiContractCaseResult x in r.Cases)
            sb.AppendLine($"  {x.Player,-20} profissional={x.ProfessionalClub ?? "-",-24} empréstimo={x.LoanClub ?? "-",-24} contratos={x.ContractCandidates,2} | {x.Assessment}");
        sb.AppendLine();
        sb.AppendLine("Arquivos: loan-multiple-contracts.csv, loan-option-entries.csv, loan-case-results.csv, loan-option-entry-summaries.csv, loan-multiple-contract-contexts.txt e loan-unresolved.txt.");
        return sb.ToString();
    }

    private static string FormatContractsCsv(LoanOptionEntryDiagnosticReport r)
    {
        var sb = new StringBuilder("player,person_database_id,internal_key,record_start,dbid_offset,discovery_method,club_save_index,club_database_id,club,wage,end_day,end_year,end_date,start_year,separator,subtype,record_length,kind,score,assessment\r\n");
        foreach (LoanContractCandidate x in r.Contracts) sb.AppendLine(string.Join(',', Csv(x.Player), x.PersonDatabaseId, x.InternalPlayerKey,
            Hex(x.RecordStartOffset), x.PersonDatabaseIdOffset.HasValue ? Hex(x.PersonDatabaseIdOffset.Value) : "", x.DiscoveryMethod,
            x.ClubSaveIndex, x.ClubDatabaseId, Csv(x.ClubName), x.InternalWeeklyWage, x.EndDayOfYearZeroBased, x.EndYear,
            x.EndDate?.ToString("yyyy-MM-dd") ?? "", x.ContractStartYear?.ToString() ?? "", x.Separator,
            x.PlayerRecordSubtype?.ToString() ?? "", x.RecordLengthToDatabaseId, x.ContractKind, x.ConfidenceScore, x.Assessment));
        return sb.ToString();
    }

    private static string FormatEntriesCsv(LoanOptionEntryDiagnosticReport r)
    {
        var sb = new StringBuilder("player,person_database_id,contract_start,contract_kind,entry_index,relative_offset,raw_hex,byte0,byte1,uint16_0,uint16_2,uint32_0,uint32_4,resolved_club_save_index,resolved_club_database_id,resolved_club,assessment\r\n");
        foreach (LoanOptionEntry x in r.Entries) sb.AppendLine(string.Join(',', Csv(x.Player), x.PersonDatabaseId, Hex(x.ContractRecordStart), x.ContractKind,
            x.EntryIndex, x.RelativeOffset, x.RawHex, x.Byte0, x.Byte1, x.UInt16At0, x.UInt16At2, x.UInt32At0, x.UInt32At4,
            x.ResolvedClubSaveIndex?.ToString() ?? "", x.ResolvedClubDatabaseId?.ToString() ?? "", Csv(x.ResolvedClubName), x.Assessment));
        return sb.ToString();
    }

    private static string FormatCasesCsv(LoanOptionEntryDiagnosticReport r)
    {
        var sb = new StringBuilder("player,person_database_id,professional_found,professional_club,loan_found,loan_club,owner_confirmed,active_confirmed,contract_candidates,option_entries,direction,assessment\r\n");
        foreach (LoanMultiContractCaseResult x in r.Cases) sb.AppendLine(string.Join(',', Csv(x.Player), x.PersonDatabaseId, x.ProfessionalContractFound,
            Csv(x.ProfessionalClub), x.LoanContractFound, Csv(x.LoanClub), x.OwnerConfirmed, x.ActiveConfirmed, x.ContractCandidates, x.OptionEntries,
            x.ExpectedDirection, x.Assessment));
        return sb.ToString();
    }

    private static string FormatSummariesCsv(LoanOptionEntryDiagnosticReport r)
    {
        var sb = new StringBuilder("relative_offset,entry_index,players_covered,hit_count,resolved_clubs,players,assessment\r\n");
        foreach (LoanOptionTypeSummary x in r.Summaries) sb.AppendLine(string.Join(',', x.RelativeOffset, x.EntryIndex, x.PlayersCovered, x.HitCount,
            Csv(x.ResolvedClubs), Csv(x.Players), x.Assessment));
        return sb.ToString();
    }

    private static string FormatContexts(LoanOptionEntryDiagnosticReport r, byte[] data)
    {
        var sb = new StringBuilder();
        foreach (LoanContractCandidate x in r.Contracts)
        {
            int center = checked((int)x.RecordStartOffset); int start = Math.Max(0, center - 32); int length = Math.Min(data.Length - start, 224);
            sb.AppendLine($"[{x.Player}] {x.ContractKind} | {x.ClubName} | start={Hex(x.RecordStartOffset)} | DBID={(x.PersonDatabaseIdOffset.HasValue ? Hex(x.PersonDatabaseIdOffset.Value) : "-")}");
            sb.AppendLine(Convert.ToHexString(data.AsSpan(start, length))); sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string FormatUnresolved(LoanOptionEntryDiagnosticReport r)
    {
        var rows = r.Cases.Where(x => !(x.ProfessionalContractFound && x.LoanContractFound)).ToArray();
        return rows.Length == 0 ? "Todos os casos tiveram contrato profissional e empréstimo confirmados.\r\n" :
            string.Join(Environment.NewLine, rows.Select(x => $"{x.Player}: {x.Assessment}")) + Environment.NewLine;
    }

    private static string Csv(string? value) => '"' + (value ?? string.Empty).Replace("\"", "\"\"") + '"';
    private static string Hex(long value) => $"0x{value:X8}";
}
