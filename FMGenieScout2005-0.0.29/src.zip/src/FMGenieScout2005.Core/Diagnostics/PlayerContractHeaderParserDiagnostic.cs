using System.Globalization;
using System.Text;
using FMGenieScout2005.Core.Domain;
using FMGenieScout2005.Core.Models;
using FMGenieScout2005.Core.Parsing;

namespace FMGenieScout2005.Core.Diagnostics;

public sealed class PlayerContractHeaderParserDiagnostic
{
    public async Task<PlayerContractHeaderParserReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source)) throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);
        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        var parser = new Fm2005PlayerContractHeaderParser();
        Fm2005PlayerContractParseResult parsed = await parser.ParseFileAsync(source, progress, cancellationToken).ConfigureAwait(false);

        progress?.Report("Validando jogadores conhecidos de Flamengo e Corinthians...");
        List<PlayerContractValidationRow> validation = BuildValidation(parsed);
        List<PlayerContractOptionChunk> chunks = BuildOptionChunks(parsed.Contracts);

        var report = new PlayerContractHeaderParserReport(
            parsed.SourceFile,
            parsed.SourceSize,
            parsed.Sha256,
            parsed.Contracts,
            validation,
            chunks,
            parsed.CandidatesExamined,
            parsed.CandidatesRejected,
            output,
            DateTimeOffset.UtcNow);

        await File.WriteAllTextAsync(Path.Combine(output, "player-contract-header-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "player-contract-headers.csv"), FormatContractsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "player-contract-options.csv"), FormatOptionsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "player-current-club-validation.csv"), FormatValidationCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "player-contract-contexts.txt"), FormatContexts(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);

        progress?.Report("Parser de cabeçalho contratual concluído.");
        return report;
    }

    private static List<PlayerContractValidationRow> BuildValidation(Fm2005PlayerContractParseResult parsed)
    {
        var rows = new List<PlayerContractValidationRow>();
        foreach (KnownPlayer expected in KnownPlayers)
        {
            PlayerContractHeader? found = parsed.FindByPersonDatabaseId(expected.DatabaseId);
            bool clubMatches = found?.CurrentClubDatabaseId == expected.ClubDatabaseId;
            string assessment = found is null ? "NAO_ENCONTRADO"
                : clubMatches ? "CURRENT_CLUB_CONFIRMED"
                : "CURRENT_CLUB_MISMATCH";
            rows.Add(new PlayerContractValidationRow(
                expected.Player,
                expected.DatabaseId,
                expected.ClubDatabaseId,
                expected.Club,
                found is not null,
                found?.CurrentClubSaveIndex,
                found?.CurrentClubDatabaseId,
                found?.CurrentClubName,
                found?.InternalWeeklyWage,
                found?.ContractEndDate,
                found?.ContractStartYear,
                found?.PlayerRecordSubtype,
                assessment));
        }
        return rows;
    }

    private static List<PlayerContractOptionChunk> BuildOptionChunks(IReadOnlyList<PlayerContractHeader> contracts)
    {
        var rows = new List<PlayerContractOptionChunk>();
        foreach (PlayerContractHeader contract in contracts)
        {
            byte[] payload = contract.VariablePayload;
            for (int offset = 0, index = 0; offset < payload.Length; offset += 8, index++)
            {
                int length = Math.Min(8, payload.Length - offset);
                ReadOnlySpan<byte> span = payload.AsSpan(offset, length);
                ulong value = 0;
                for (int i = 0; i < length; i++) value |= (ulong)span[i] << (i * 8);
                string assessment = length == 8 ? "RAW_OPTION_CHUNK" : "RAW_OPTION_REMAINDER";
                rows.Add(new PlayerContractOptionChunk(
                    contract.DisplayName,
                    contract.PersonDatabaseId,
                    index,
                    17 + offset,
                    Convert.ToHexString(span),
                    value,
                    length,
                    assessment));
            }
        }
        return rows;
    }

    public static string FormatReportForUi(PlayerContractHeaderParserReport report) => FormatReport(report);

    private static string FormatReport(PlayerContractHeaderParserReport r)
    {
        int confirmed = r.Validation.Count(x => x.Assessment == "CURRENT_CLUB_CONFIRMED");
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — PlayerContractHeaderParser 0.0.28.6.1");
        sb.AppendLine(new string('=', 94));
        sb.AppendLine($"Arquivo: {r.SourceFile}");
        sb.AppendLine($"Tamanho: {r.SourceSize:N0} bytes");
        sb.AppendLine($"SHA-256: {r.Sha256}");
        sb.AppendLine($"Cabeçalhos contratuais únicos: {r.Contracts.Count:N0}");
        sb.AppendLine($"Candidatos examinados: {r.CandidatesExamined:N0}");
        sb.AppendLine($"Candidatos rejeitados: {r.CandidatesRejected:N0}");
        sb.AppendLine($"Validação conhecida: {confirmed}/{r.Validation.Count}");
        sb.AppendLine($"Blocos variáveis exportados em chunks: {r.OptionChunks.Count:N0}");
        sb.AppendLine();
        sb.AppendLine("Layout confirmado (campos após a chave são desalinhados por um byte):");
        sb.AppendLine("  record+0  UInt32 InternalPlayerKey");
        sb.AppendLine("  record+4  Byte separator/flags");
        sb.AppendLine("  record+5  UInt32 CurrentClubSaveIndex");
        sb.AppendLine("  record+9  UInt32 InternalWeeklyWage");
        sb.AppendLine("  record+13 UInt16 ContractEndDayOfYearZeroBased");
        sb.AppendLine("  record+15 UInt16 ContractEndYear");
        sb.AppendLine("  record+17 payload contratual variável");
        sb.AppendLine("  DBID-8    UInt32 ContractStartYear");
        sb.AppendLine("  DBID-4    UInt32 InternalPlayerKey repetida");
        sb.AppendLine("  DBID+0    UInt32 PersonDatabaseId");
        sb.AppendLine("  DBID+4    Byte PlayerRecordSubtype");
        sb.AppendLine();
        sb.AppendLine("Validação dos 19 jogadores:");
        foreach (PlayerContractValidationRow x in r.Validation)
            sb.AppendLine($"  {x.Player,-24} DBID={x.PersonDatabaseId,8} esperado={x.ExpectedClub,-25} encontrado={x.FoundClub ?? "-",-25} salário={x.InternalWeeklyWage?.ToString(CultureInfo.InvariantCulture) ?? "-",8} fim={x.ContractEndDate?.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) ?? "-"} {x.Assessment}");
        sb.AppendLine();
        sb.AppendLine("Os chunks em player-contract-options.csv ainda são dados brutos; sua semântica não foi assumida.");
        sb.AppendLine("O save não foi modificado.");
        return sb.ToString();
    }

    private static string FormatContractsCsv(PlayerContractHeaderParserReport r)
    {
        var sb = new StringBuilder("person_database_id,display_name,internal_player_key,current_club_save_index,current_club_database_id,current_club_name,internal_weekly_wage,end_day_of_year_zero_based,end_year,end_date,start_year,record_subtype,record_start_offset,database_id_offset,record_length,variable_payload_length,confidence_score,confidence\r\n");
        foreach (PlayerContractHeader x in r.Contracts)
            sb.AppendLine(string.Join(',', x.PersonDatabaseId, Csv(x.DisplayName), x.InternalPlayerKey, x.CurrentClubSaveIndex,
                x.CurrentClubDatabaseId?.ToString(CultureInfo.InvariantCulture) ?? string.Empty, Csv(x.CurrentClubName), x.InternalWeeklyWage,
                x.ContractEndDayOfYearZeroBased, x.ContractEndYear,
                x.ContractEndDate?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) ?? string.Empty,
                x.ContractStartYear, x.PlayerRecordSubtype, $"0x{x.RecordStartOffset:X8}", $"0x{x.PersonDatabaseIdOffset:X8}",
                x.RecordLength, x.VariablePayload.Length, x.ConfidenceScore, x.Confidence));
        return sb.ToString();
    }

    private static string FormatValidationCsv(PlayerContractHeaderParserReport r)
    {
        var sb = new StringBuilder("player,person_database_id,expected_club_database_id,expected_club,contract_found,found_club_save_index,found_club_database_id,found_club,internal_weekly_wage,contract_end_date,contract_start_year,record_subtype,assessment\r\n");
        foreach (PlayerContractValidationRow x in r.Validation)
            sb.AppendLine(string.Join(',', Csv(x.Player), x.PersonDatabaseId, x.ExpectedClubDatabaseId, Csv(x.ExpectedClub), x.ContractFound,
                x.FoundClubSaveIndex?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                x.FoundClubDatabaseId?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                Csv(x.FoundClub), x.InternalWeeklyWage?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                x.ContractEndDate?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) ?? string.Empty,
                x.ContractStartYear?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                x.RecordSubtype?.ToString(CultureInfo.InvariantCulture) ?? string.Empty, x.Assessment));
        return sb.ToString();
    }

    private static string FormatOptionsCsv(PlayerContractHeaderParserReport r)
    {
        var sb = new StringBuilder("player,person_database_id,chunk_index,relative_offset_from_record_start,hex,little_endian_value,length,assessment\r\n");
        foreach (PlayerContractOptionChunk x in r.OptionChunks)
            sb.AppendLine(string.Join(',', Csv(x.Player), x.PersonDatabaseId, x.ChunkIndex, x.RelativeOffsetFromRecordStart, x.Hex, x.LittleEndianValue, x.Length, x.Assessment));
        return sb.ToString();
    }

    private static string FormatContexts(PlayerContractHeaderParserReport r)
    {
        var sb = new StringBuilder();
        foreach (PlayerContractHeader x in r.Contracts)
        {
            sb.AppendLine($"[{x.DisplayName}] DBID={x.PersonDatabaseId} club={x.CurrentClubName} start={x.ContractStartYear} end={x.ContractEndDate:dd/MM/yyyy} wage={x.InternalWeeklyWage} subtype={x.PlayerRecordSubtype}");
            sb.AppendLine($"record=0x{x.RecordStartOffset:X8} dbid=0x{x.PersonDatabaseIdOffset:X8} variável={x.VariablePayload.Length} bytes");
            sb.AppendLine(Convert.ToHexString(x.VariablePayload));
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string Csv(string? value)
    {
        string text = value ?? string.Empty;
        return '"' + text.Replace("\"", "\"\"") + '"';
    }

    private sealed record KnownPlayer(string Player, uint DatabaseId, uint ClubDatabaseId, string Club);

    private static readonly KnownPlayer[] KnownPlayers =
    [
        new("Jean",315116,322,"CR Flamengo"),
        new("Athirson",3301535,322,"CR Flamengo"),
        new("Andrezinho",302728,322,"CR Flamengo"),
        new("André Bahia",311169,322,"CR Flamengo"),
        new("Dimba",303048,322,"CR Flamengo"),
        new("Douglas Silva",3300410,322,"CR Flamengo"),
        new("Fabiano Eller",3300219,322,"CR Flamengo"),
        new("Júlio César Moraes",8825041,322,"CR Flamengo"),
        new("Júnior Baiano",6900111,322,"CR Flamengo"),
        new("Reginaldo Araújo",3300780,322,"CR Flamengo"),
        new("Édson Araújo",308345,319,"SC Corinthians Paulista"),
        new("Fábio Baiano",3300471,319,"SC Corinthians Paulista"),
        new("Fábio Costa",6900151,319,"SC Corinthians Paulista"),
        new("Luciano Ratinho",6900008,319,"SC Corinthians Paulista"),
        new("Marcelo Magalhães",302580,319,"SC Corinthians Paulista"),
        new("Bruno Octávio",8832887,319,"SC Corinthians Paulista"),
        new("Alessandro",3902245,319,"SC Corinthians Paulista"),
        new("Rosinei",316596,319,"SC Corinthians Paulista"),
        new("Dinélson",320774,319,"SC Corinthians Paulista")
    ];
}
