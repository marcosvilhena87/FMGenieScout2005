using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using FMGenieScout2005.Core.Models;

namespace FMGenieScout2005.Core.Diagnostics;

public sealed class VariableContractSegmentAlignmentDiagnostic
{
    private const uint JeanDatabaseId = 315116;
    private const uint AthirsonDatabaseId = 3_301_535;
    private const int WindowBefore = 256;
    private const int WindowAfter = 512;

    public async Task<VariableContractSegmentAlignmentReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source)) throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);
        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();

        progress?.Report("Selecionando as ocorrências estruturais de Jean e Athirson...");
        long jeanAnchor = SelectJeanAnchor(data);
        long athirsonAnchor = SelectAthirsonAnchor(data, jeanAnchor);

        progress?.Report("Localizando marcos internos e limites variáveis...");
        List<ContractSegmentLandmark> landmarks = [];
        landmarks.AddRange(BuildLandmarks(data, "Jean", jeanAnchor, 1982, 2001, 2006, 15));
        landmarks.AddRange(BuildLandmarks(data, "Athirson", athirsonAnchor, 1977, 2004, 2006, null));

        progress?.Report("Construindo segmentos e alinhando assinaturas...");
        List<VariableContractSegment> segments = [];
        segments.AddRange(BuildSegments(data, "Jean", jeanAnchor, landmarks.Where(x => x.Player == "Jean").ToArray()));
        segments.AddRange(BuildSegments(data, "Athirson", athirsonAnchor, landmarks.Where(x => x.Player == "Athirson").ToArray()));
        List<ContractSegmentAlignment> alignments = AlignSegments(segments);

        var report = new VariableContractSegmentAlignmentReport(
            source, data.LongLength, sha, jeanAnchor, athirsonAnchor,
            landmarks.OrderBy(x => x.Player).ThenBy(x => x.RelativeOffset).ToArray(),
            segments.OrderBy(x => x.Player).ThenBy(x => x.SegmentIndex).ToArray(),
            alignments, output, DateTimeOffset.UtcNow);

        await File.WriteAllTextAsync(Path.Combine(output, "variable-contract-segment-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "jean-athirson-landmarks.csv"), FormatLandmarksCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "variable-contract-segments.csv"), FormatSegmentsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "segment-alignment.csv"), FormatAlignmentsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "variable-contract-contexts.txt"), FormatContexts(report, data), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "aligned-offset-matrix.csv"), FormatAlignedOffsetMatrix(report, data), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);

        progress?.Report("Mapeamento de segmentos variáveis concluído.");
        return report;
    }

    private static long SelectJeanAnchor(byte[] data)
    {
        List<int> anchors = FindUInt32(data, JeanDatabaseId);
        if (anchors.Count == 0) throw new InvalidOperationException("O PersonDatabaseId 315116 do Jean não foi encontrado.");
        return anchors.OrderByDescending(x => ScoreRichRecord(data, x, 1982, 2001, 2006)).First();
    }

    private static long SelectAthirsonAnchor(byte[] data, long jeanAnchor)
    {
        List<int> anchors = FindUInt32(data, AthirsonDatabaseId);
        if (anchors.Count == 0) throw new InvalidOperationException("O PersonDatabaseId 3301535 do Athirson não foi encontrado.");
        return anchors
            .Where(x => !(TryReadUInt32(data, x - 8, out uint marker) && marker == 189))
            .OrderByDescending(x => ScoreRichRecord(data, x, 1977, 2004, 2006) + LayoutSimilarity(data, jeanAnchor, x) * 100.0)
            .DefaultIfEmpty(anchors[0])
            .First();
    }

    private static double ScoreRichRecord(byte[] data, long anchor, int birthYear, int startYear, int endYear)
    {
        double score = 0;
        if (TryReadUInt32(data, anchor - 8, out uint start) && start == startYear) score += 100;
        if (FindNearestInteger(data, anchor, birthYear, -220, -80).HasValue) score += 20;
        if (FindNearestInteger(data, anchor, endYear, -120, -16).HasValue) score += 20;
        if (CanRead(data, anchor + 4, 1) && data[(int)anchor + 4] == 2) score += 20;
        score += CountUInt32(data, anchor, -64, 192, uint.MaxValue) * 2;
        return score;
    }

    private static List<ContractSegmentLandmark> BuildLandmarks(byte[] data, string player, long anchor, int birthYear, int startYear, int endYear, int? annualRise)
    {
        var result = new List<ContractSegmentLandmark>();
        AddFixed(result, player, "WINDOW_START", anchor, -WindowBefore, 0, "BOUNDARY", "FIXED");
        AddKnown(result, data, player, anchor, "BIRTH_YEAR", birthYear, -220, -80);
        if (annualRise.HasValue) AddKnown(result, data, player, anchor, "ANNUAL_WAGE_RISE", annualRise.Value, -120, -40);
        AddKnown(result, data, player, anchor, "CONTRACT_END_YEAR", endYear, -120, -16);
        AddKnown(result, data, player, anchor, "CONTRACT_START_YEAR", startYear, -16, -1);
        AddFixed(result, player, "PERSON_DATABASE_ID", anchor, 0, ReadUInt32(data, anchor), "UINT32", "CONFIRMED");
        AddFixed(result, player, "POST_ID_TYPE", anchor, 4, CanRead(data, anchor + 4, 1) ? data[(int)anchor + 4] : -1, "BYTE", "STRUCTURAL");

        foreach (int rel in FindFfffffff(data, anchor, 4, 192).Take(3))
            AddFixed(result, player, $"FFFFFFFF_{rel:+0;-0;0}", anchor, rel, uint.MaxValue, "UINT32", "STRUCTURAL");
        foreach ((int Start, int Length) run in FindZeroRuns(data, anchor, 4, 256, 8).Take(4))
        {
            AddFixed(result, player, $"ZERO_RUN_START_{run.Start:+0;-0;0}", anchor, run.Start, run.Length, "ZERO_RUN", "BOUNDARY_CANDIDATE");
            AddFixed(result, player, $"ZERO_RUN_END_{run.Start + run.Length:+0;-0;0}", anchor, run.Start + run.Length, run.Length, "ZERO_RUN", "BOUNDARY_CANDIDATE");
        }
        AddFixed(result, player, "WINDOW_END", anchor, WindowAfter, 0, "BOUNDARY", "FIXED");

        return result.GroupBy(x => x.RelativeOffset).Select(g => g.OrderByDescending(x => LandmarkPriority(x.Landmark)).First())
            .OrderBy(x => x.RelativeOffset).ToList();
    }

    private static int LandmarkPriority(string name) => name switch
    {
        "PERSON_DATABASE_ID" => 100,
        "CONTRACT_START_YEAR" => 90,
        "CONTRACT_END_YEAR" => 80,
        "BIRTH_YEAR" => 70,
        _ when name.StartsWith("ZERO_RUN", StringComparison.Ordinal) => 50,
        _ when name.StartsWith("FFFFFFFF", StringComparison.Ordinal) => 40,
        _ => 10
    };

    private static void AddKnown(List<ContractSegmentLandmark> output, byte[] data, string player, long anchor, string name, int value, int from, int to)
    {
        (int Rel, string Type)? hit = FindNearestInteger(data, anchor, value, from, to);
        if (hit.HasValue) AddFixed(output, player, name, anchor, hit.Value.Rel, value, hit.Value.Type, "KNOWN_VALUE");
    }

    private static void AddFixed(List<ContractSegmentLandmark> output, string player, string name, long anchor, int rel, long value, string type, string confidence) =>
        output.Add(new ContractSegmentLandmark(player, name, anchor, rel, anchor + rel, value, type, confidence));

    private static List<VariableContractSegment> BuildSegments(byte[] data, string player, long anchor, IReadOnlyList<ContractSegmentLandmark> landmarks)
    {
        var result = new List<VariableContractSegment>();
        for (int i = 0; i < landmarks.Count - 1; i++)
        {
            ContractSegmentLandmark start = landmarks[i];
            ContractSegmentLandmark end = landmarks[i + 1];
            int length = end.RelativeOffset - start.RelativeOffset;
            if (length <= 0 || length > 384) continue;
            long absolute = anchor + start.RelativeOffset;
            if (!CanRead(data, absolute, length)) continue;
            byte[] bytes = data.AsSpan((int)absolute, length).ToArray();
            string signature = BuildSignature(bytes);
            int zeroBytes = bytes.Count(x => x == 0);
            int ff = CountUInt32(bytes, 0, 0, bytes.Length, uint.MaxValue);
            string preview = Convert.ToHexString(bytes.AsSpan(0, Math.Min(48, bytes.Length)));
            result.Add(new VariableContractSegment(player, result.Count + 1, start.Landmark, end.Landmark,
                start.RelativeOffset, end.RelativeOffset, length, signature, zeroBytes, ff, preview));
        }
        return result;
    }

    private static List<ContractSegmentAlignment> AlignSegments(IReadOnlyList<VariableContractSegment> all)
    {
        VariableContractSegment[] jean = all.Where(x => x.Player == "Jean").ToArray();
        VariableContractSegment[] athirson = all.Where(x => x.Player == "Athirson").ToArray();
        var candidates = new List<ContractSegmentAlignment>();
        int index = 0;
        foreach (VariableContractSegment j in jean)
        {
            VariableContractSegment? best = athirson
                .Select(a => new { Segment = a, Similarity = SignatureSimilarity(j.Signature, a.Signature) })
                .OrderByDescending(x => x.Similarity)
                .ThenBy(x => Math.Abs(j.Length - x.Segment.Length))
                .Select(x => x.Segment)
                .FirstOrDefault();
            if (best is null) continue;
            double similarity = SignatureSimilarity(j.Signature, best.Signature);
            string assessment = similarity >= 0.80 ? "SEGMENT_ALIGNMENT_STRONG" : similarity >= 0.60 ? "SEGMENT_ALIGNMENT_MEDIUM" : "SEGMENT_ALIGNMENT_WEAK";
            string evidence = $"length_delta={best.Length - j.Length};jean_signature={j.Signature};athirson_signature={best.Signature}";
            candidates.Add(new ContractSegmentAlignment(++index, j.StartLandmark, j.EndLandmark,
                best.StartLandmark, best.EndLandmark, j.Length, best.Length, similarity, assessment, evidence));
        }
        return candidates.OrderByDescending(x => x.CategorySimilarity).ThenBy(x => Math.Abs(x.JeanLength - x.AthirsonLength)).ToList();
    }

    private static string BuildSignature(byte[] bytes)
    {
        var categories = new List<string>();
        for (int offset = 0; offset + 4 <= bytes.Length; offset += 4)
            categories.Add(Category(BinaryPrimitives.ReadUInt32LittleEndian(bytes.AsSpan(offset, 4))));
        if (bytes.Length % 4 != 0) categories.Add($"TAIL{bytes.Length % 4}");
        return string.Join('-', categories);
    }

    private static double SignatureSimilarity(string left, string right)
    {
        string[] a = left.Split('-', StringSplitOptions.RemoveEmptyEntries);
        string[] b = right.Split('-', StringSplitOptions.RemoveEmptyEntries);
        int max = Math.Max(a.Length, b.Length);
        if (max == 0) return 1;
        int min = Math.Min(a.Length, b.Length);
        int matches = 0;
        for (int i = 0; i < min; i++) if (a[i] == b[i]) matches++;
        return matches / (double)max;
    }

    private static double LayoutSimilarity(byte[] data, long first, long second)
    {
        int compared = 0;
        int matches = 0;
        for (int rel = -128; rel < 256; rel += 4)
        {
            if (!CanRead(data, first + rel, 4) || !CanRead(data, second + rel, 4)) continue;
            compared++;
            if (Category(ReadUInt32(data, first + rel)) == Category(ReadUInt32(data, second + rel))) matches++;
        }
        return compared == 0 ? 0 : matches / (double)compared;
    }

    private static string Category(uint value) => value switch
    {
        0 => "ZERO",
        uint.MaxValue => "FFFF",
        <= 1 => "FLAG",
        <= 255 => "BYTE",
        <= 65535 => "U16",
        <= 10_000_000 => "VALUE",
        _ => "LARGE"
    };

    private static (int Rel, string Type)? FindNearestInteger(byte[] data, long anchor, int expected, int from, int to)
    {
        var hits = new List<(int Rel, string Type)>();
        for (int rel = from; rel <= to; rel++)
        {
            long pos = anchor + rel;
            if (expected <= byte.MaxValue && CanRead(data, pos, 1) && data[(int)pos] == expected) hits.Add((rel, "BYTE"));
            if (expected <= ushort.MaxValue && CanRead(data, pos, 2) && BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan((int)pos, 2)) == expected) hits.Add((rel, "UINT16"));
            if (CanRead(data, pos, 4) && BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan((int)pos, 4)) == expected) hits.Add((rel, "INT32"));
        }
        if (hits.Count == 0) return null;
        return hits.OrderBy(x => Math.Abs(x.Rel)).ThenByDescending(x => x.Type == "INT32").First();
    }

    private static IEnumerable<int> FindFfffffff(byte[] data, long anchor, int from, int to)
    {
        for (int rel = from; rel <= to; rel++)
            if (TryReadUInt32(data, anchor + rel, out uint value) && value == uint.MaxValue) yield return rel;
    }

    private static IEnumerable<(int Start, int Length)> FindZeroRuns(byte[] data, long anchor, int from, int to, int minimum)
    {
        int rel = from;
        while (rel <= to)
        {
            long pos = anchor + rel;
            if (!CanRead(data, pos, 1) || data[(int)pos] != 0) { rel++; continue; }
            int start = rel;
            while (rel <= to && CanRead(data, anchor + rel, 1) && data[(int)(anchor + rel)] == 0) rel++;
            int length = rel - start;
            if (length >= minimum) yield return (start, length);
        }
    }

    private static List<int> FindUInt32(byte[] data, uint expected)
    {
        byte b0 = (byte)expected;
        byte b1 = (byte)(expected >> 8);
        byte b2 = (byte)(expected >> 16);
        byte b3 = (byte)(expected >> 24);
        var result = new List<int>();
        for (int i = 0; i <= data.Length - 4; i++)
            if (data[i] == b0 && data[i + 1] == b1 && data[i + 2] == b2 && data[i + 3] == b3) result.Add(i);
        return result;
    }

    private static int CountUInt32(byte[] data, long anchor, int from, int to, uint expected)
    {
        int count = 0;
        for (int rel = from; rel <= to; rel++) if (TryReadUInt32(data, anchor + rel, out uint value) && value == expected) count++;
        return count;
    }

    private static bool TryReadUInt32(byte[] data, long offset, out uint value)
    {
        value = 0;
        if (!CanRead(data, offset, 4)) return false;
        value = BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan((int)offset, 4));
        return true;
    }

    private static uint ReadUInt32(byte[] data, long offset) => BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan((int)offset, 4));
    private static bool CanRead(byte[] data, long offset, int width) => offset >= 0 && offset + width <= data.LongLength;

    public static string FormatReportForUi(VariableContractSegmentAlignmentReport report) => FormatReport(report);

    private static string FormatReport(VariableContractSegmentAlignmentReport report)
    {
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — VariableContractSegmentAlignmentDiagnostic 0.0.28.3");
        sb.AppendLine(new string('=', 94));
        sb.AppendLine($"Arquivo: {report.SourceFile}");
        sb.AppendLine($"Jean:     0x{report.JeanAnchor:X8}");
        sb.AppendLine($"Athirson: 0x{report.AthirsonAnchor:X8}");
        sb.AppendLine($"Marcos: {report.Landmarks.Count:N0} | Segmentos: {report.Segments.Count:N0} | Alinhamentos: {report.Alignments.Count:N0}");
        sb.AppendLine();
        sb.AppendLine("Alinhamentos mais fortes:");
        foreach (ContractSegmentAlignment x in report.Alignments.Take(20))
            sb.AppendLine($"  {x.Assessment,-26} sim={x.CategorySimilarity:P1} | Jean {x.JeanStartLandmark}->{x.JeanEndLandmark} ({x.JeanLength}) | Athirson {x.AthirsonStartLandmark}->{x.AthirsonEndLandmark} ({x.AthirsonLength})");
        sb.AppendLine();
        sb.AppendLine("Arquivos: jean-athirson-landmarks.csv, variable-contract-segments.csv, segment-alignment.csv, variable-contract-contexts.txt e aligned-offset-matrix.csv.");
        sb.AppendLine("O payload não foi alterado.");
        return sb.ToString();
    }

    private static string FormatLandmarksCsv(VariableContractSegmentAlignmentReport report)
    {
        var sb = new StringBuilder("player,landmark,anchor_offset,relative_offset,absolute_offset,value,data_type,confidence\r\n");
        foreach (ContractSegmentLandmark x in report.Landmarks)
            sb.AppendLine($"{Csv(x.Player)},{Csv(x.Landmark)},0x{x.AnchorOffset:X8},{x.RelativeOffset},0x{x.AbsoluteOffset:X8},{x.Value},{x.DataType},{x.Confidence}");
        return sb.ToString();
    }

    private static string FormatSegmentsCsv(VariableContractSegmentAlignmentReport report)
    {
        var sb = new StringBuilder("player,segment_index,start_landmark,end_landmark,start_relative_offset,end_relative_offset,length,signature,zero_bytes,ffffffff_count,hex_preview\r\n");
        foreach (VariableContractSegment x in report.Segments)
            sb.AppendLine($"{Csv(x.Player)},{x.SegmentIndex},{Csv(x.StartLandmark)},{Csv(x.EndLandmark)},{x.StartRelativeOffset},{x.EndRelativeOffset},{x.Length},{Csv(x.Signature)},{x.ZeroBytes},{x.FfffffffCount},{x.HexPreview}");
        return sb.ToString();
    }

    private static string FormatAlignmentsCsv(VariableContractSegmentAlignmentReport report)
    {
        var sb = new StringBuilder("alignment_index,jean_start,jean_end,athirson_start,athirson_end,jean_length,athirson_length,category_similarity,assessment,evidence\r\n");
        foreach (ContractSegmentAlignment x in report.Alignments)
            sb.AppendLine($"{x.AlignmentIndex},{Csv(x.JeanStartLandmark)},{Csv(x.JeanEndLandmark)},{Csv(x.AthirsonStartLandmark)},{Csv(x.AthirsonEndLandmark)},{x.JeanLength},{x.AthirsonLength},{x.CategorySimilarity.ToString("F6", CultureInfo.InvariantCulture)},{x.Assessment},{Csv(x.Evidence)}");
        return sb.ToString();
    }

    private static string FormatContexts(VariableContractSegmentAlignmentReport report, byte[] data)
    {
        var sb = new StringBuilder();
        foreach ((string Player, long Anchor) item in new[] { ("Jean", report.JeanAnchor), ("Athirson", report.AthirsonAnchor) })
        {
            sb.AppendLine($"[{item.Player}] anchor=0x{item.Anchor:X8}");
            int start = checked((int)(item.Anchor - WindowBefore));
            int length = WindowBefore + WindowAfter;
            if (start < 0) { length += start; start = 0; }
            length = Math.Min(length, data.Length - start);
            sb.AppendLine(Convert.ToHexString(data.AsSpan(start, length)));
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string FormatAlignedOffsetMatrix(VariableContractSegmentAlignmentReport report, byte[] data)
    {
        var sb = new StringBuilder("relative_offset,jean_u8,athirson_u8,jean_u16,athirson_u16,jean_u32,athirson_u32,jean_category,athirson_category\r\n");
        for (int rel = -WindowBefore; rel < WindowAfter; rel++)
        {
            long jp = report.JeanAnchor + rel;
            long ap = report.AthirsonAnchor + rel;
            if (!CanRead(data, jp, 1) || !CanRead(data, ap, 1)) continue;
            string ju16 = CanRead(data, jp, 2) ? BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan((int)jp, 2)).ToString(CultureInfo.InvariantCulture) : string.Empty;
            string au16 = CanRead(data, ap, 2) ? BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan((int)ap, 2)).ToString(CultureInfo.InvariantCulture) : string.Empty;
            string ju32 = CanRead(data, jp, 4) ? ReadUInt32(data, jp).ToString(CultureInfo.InvariantCulture) : string.Empty;
            string au32 = CanRead(data, ap, 4) ? ReadUInt32(data, ap).ToString(CultureInfo.InvariantCulture) : string.Empty;
            string jc = CanRead(data, jp, 4) ? Category(ReadUInt32(data, jp)) : string.Empty;
            string ac = CanRead(data, ap, 4) ? Category(ReadUInt32(data, ap)) : string.Empty;
            sb.AppendLine($"{rel},{data[(int)jp]},{data[(int)ap]},{ju16},{au16},{ju32},{au32},{jc},{ac}");
        }
        return sb.ToString();
    }

    private static string Csv(string value) => '"' + value.Replace("\"", "\"\"") + '"';
}
