using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using FMGenieScout2005.Core.Models;

namespace FMGenieScout2005.Core.Diagnostics;

public sealed class JeanContractRecordFieldDiagnostic
{
    private const uint JeanDatabaseId = 315116;
    private const int WindowBefore = 256;
    private const int WindowAfter = 512;

    private static readonly (string Name, double Value)[] KnownMoney =
    [
        ("MonthlyWage", 2700),
        ("AppearanceBonus", 240),
        ("GoalBonus", 65),
        ("AssistBonus", 35),
        ("ReleaseClause", 11000000),
        ("DisplayedValue", 3000000)
    ];

    public async Task<JeanContractRecordFieldReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source)) throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);
        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();

        progress?.Report("Localizando PersonDatabaseId 315116...");
        List<long> anchors = FindUInt32(data, JeanDatabaseId).Select(x => (long)x).ToList();
        if (anchors.Count == 0) throw new InvalidOperationException("O PersonDatabaseId 315116 do Jean não foi encontrado.");

        var fields = new List<JeanContractFieldValue>();
        var known = new List<JeanKnownValueCandidate>();
        foreach (long anchor in anchors)
        {
            cancellationToken.ThrowIfCancellationRequested();
            progress?.Report($"Decompondo registro em torno de 0x{anchor:X8}...");
            AddFields(data, anchor, fields);
            AddKnownValueCandidates(data, anchor, known);
        }

        List<JeanDuplicateField> duplicates = BuildDuplicates(fields);
        var report = new JeanContractRecordFieldReport(source, data.LongLength, sha, JeanDatabaseId, anchors, fields, duplicates, known, output, DateTimeOffset.UtcNow);

        progress?.Report("Gravando relatórios da decomposição...");
        await File.WriteAllTextAsync(Path.Combine(output, "jean-contract-record-field-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "jean-contract-fields.csv"), FormatFieldsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "jean-contract-duplicate-fields.csv"), FormatDuplicatesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "jean-contract-known-value-candidates.csv"), FormatKnownCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "jean-contract-record-contexts.txt"), FormatContexts(report, data), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "jean-contract-offset-matrix.csv"), FormatOffsetMatrix(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        progress?.Report("Decomposição do registro do Jean concluída.");
        return report;
    }

    private static void AddFields(byte[] data, long anchor, List<JeanContractFieldValue> output)
    {
        int start = Math.Max(0, checked((int)anchor) - WindowBefore);
        int end = Math.Min(data.Length, checked((int)anchor) + WindowAfter);
        for (int pos = start; pos < end; pos++)
        {
            int rel = pos - checked((int)anchor);
            output.Add(new JeanContractFieldValue(rel, pos, "BYTE", data[pos].ToString("X2", CultureInfo.InvariantCulture), data[pos].ToString(CultureInfo.InvariantCulture), InterpretInteger(data[pos]), ScoreInteger(data[pos])));
            if (pos + 2 <= end)
            {
                ushort u16 = BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(pos, 2));
                short i16 = BinaryPrimitives.ReadInt16LittleEndian(data.AsSpan(pos, 2));
                output.Add(new JeanContractFieldValue(rel, pos, "UINT16", Convert.ToHexString(data.AsSpan(pos, 2)), u16.ToString(CultureInfo.InvariantCulture), InterpretInteger(u16), ScoreInteger(u16)));
                output.Add(new JeanContractFieldValue(rel, pos, "INT16", Convert.ToHexString(data.AsSpan(pos, 2)), i16.ToString(CultureInfo.InvariantCulture), InterpretInteger(i16), ScoreInteger(i16)));
            }
            if (pos + 4 <= end)
            {
                uint u32 = BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(pos, 4));
                int i32 = BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(pos, 4));
                float f32 = BitConverter.Int32BitsToSingle(i32);
                output.Add(new JeanContractFieldValue(rel, pos, "UINT32", Convert.ToHexString(data.AsSpan(pos, 4)), u32.ToString(CultureInfo.InvariantCulture), InterpretInteger(u32), ScoreInteger(u32)));
                output.Add(new JeanContractFieldValue(rel, pos, "INT32", Convert.ToHexString(data.AsSpan(pos, 4)), i32.ToString(CultureInfo.InvariantCulture), InterpretInteger(i32), ScoreInteger(i32)));
                if (float.IsFinite(f32))
                    output.Add(new JeanContractFieldValue(rel, pos, "FLOAT32", Convert.ToHexString(data.AsSpan(pos, 4)), f32.ToString("R", CultureInfo.InvariantCulture), InterpretFloat(f32), ScoreFloat(f32)));
            }
        }
    }

    private static void AddKnownValueCandidates(byte[] data, long anchor, List<JeanKnownValueCandidate> output)
    {
        int start = Math.Max(0, checked((int)anchor) - WindowBefore);
        int end = Math.Min(data.Length - 4, checked((int)anchor) + WindowAfter);
        foreach ((string name, double target) in KnownMoney)
        {
            foreach ((string representation, double expected) in MoneyRepresentations(target))
            {
                for (int pos = start; pos <= end; pos++)
                {
                    uint raw = BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(pos, 4));
                    double error = expected == 0 ? Math.Abs(raw) : Math.Abs(raw - expected) / expected;
                    if (error <= 0.20)
                        output.Add(new JeanKnownValueCandidate(name, representation, expected.ToString("0.###", CultureInfo.InvariantCulture), pos - checked((int)anchor), pos, raw.ToString(CultureInfo.InvariantCulture), error, error == 0 ? "EXACT" : error <= 0.02 ? "VERY_CLOSE" : error <= 0.08 ? "CLOSE" : "LOOSE"));
                }
            }
        }

        // Datas: componentes e anos conhecidos próximos da âncora.
        AddExactUInt32(data, anchor, output, "ContractStartYear", "YEAR", 2001);
        AddExactUInt32(data, anchor, output, "ContractEndYear", "YEAR", 2006);
        AddExactUInt32(data, anchor, output, "BirthYear", "YEAR", 1982);
        AddExactUInt32(data, anchor, output, "AnnualRise", "PERCENT", 15);
    }

    private static IEnumerable<(string Name, double Value)> MoneyRepresentations(double monthly)
    {
        yield return ("DISPLAYED", monthly);
        yield return ("ANNUAL", monthly * 12.0);
        yield return ("WEEKLY_52", Math.Round(monthly * 12.0 / 52.0));
        yield return ("DAILY_365", Math.Round(monthly * 12.0 / 365.0));
        yield return ("X100", monthly * 100.0);
        yield return ("DIV100", Math.Round(monthly / 100.0));
        yield return ("X256", monthly * 256.0);
    }

    private static void AddExactUInt32(byte[] data, long anchor, List<JeanKnownValueCandidate> output, string target, string representation, uint expected)
    {
        int start = Math.Max(0, checked((int)anchor) - WindowBefore);
        int end = Math.Min(data.Length - 4, checked((int)anchor) + WindowAfter);
        for (int pos = start; pos <= end; pos++)
        {
            uint value = BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(pos, 4));
            if (value == expected)
                output.Add(new JeanKnownValueCandidate(target, representation, expected.ToString(CultureInfo.InvariantCulture), pos - checked((int)anchor), pos, value.ToString(CultureInfo.InvariantCulture), 0, "EXACT"));
        }
    }

    private static List<JeanDuplicateField> BuildDuplicates(IReadOnlyList<JeanContractFieldValue> fields)
    {
        var result = new List<JeanDuplicateField>();
        foreach (var group in fields.Where(x => x.DataType is "UINT16" or "UINT32" or "INT32")
                     .GroupBy(x => (x.DataType, x.Value))
                     .Where(g => g.Count() >= 2))
        {
            JeanContractFieldValue[] items = group.OrderBy(x => x.RelativeOffset).ToArray();
            for (int i = 0; i < items.Length - 1; i++)
            {
                int distance = items[i + 1].RelativeOffset - items[i].RelativeOffset;
                if (distance is > 0 and <= 64)
                    result.Add(new JeanDuplicateField(group.Key.DataType, group.Key.Value, items[i].RelativeOffset, items[i + 1].RelativeOffset, distance, items.Length));
            }
        }
        return result.OrderBy(x => x.Distance).ThenBy(x => Math.Abs(x.FirstRelativeOffset)).Take(5000).ToList();
    }

    private static IEnumerable<int> FindUInt32(byte[] data, uint value)
    {
        byte b0 = (byte)value; byte b1 = (byte)(value >> 8); byte b2 = (byte)(value >> 16); byte b3 = (byte)(value >> 24);
        for (int i = 0; i <= data.Length - 4; i++)
            if (data[i] == b0 && data[i + 1] == b1 && data[i + 2] == b2 && data[i + 3] == b3)
                yield return i;
    }

    private static string InterpretInteger(long value)
    {
        if (value == JeanDatabaseId) return "PERSON_DATABASE_ID";
        if (value is 1982 or 2001 or 2006) return "KNOWN_YEAR";
        if (value is 15) return "KNOWN_PERCENT";
        if (value is 35 or 65 or 240 or 2700) return "KNOWN_CONTRACT_VALUE";
        if (value is 2560000 or 3000000 or 11000000) return "FINANCIAL_RANGE";
        if (value == -1 || value == uint.MaxValue) return "SENTINEL_MINUS_ONE";
        if (value == 0) return "ZERO";
        if (value > 0 && value < 100) return "SMALL_ENUM_OR_FLAG";
        if (value > 0 && value < 100000) return "SMALL_INDEX_OR_AMOUNT";
        if (value >= 100000 && value <= 50000000) return "ID_OR_FINANCIAL";
        return string.Empty;
    }

    private static string InterpretFloat(float value)
    {
        if (Math.Abs(value) < 0.000001f) return "ZERO_FLOAT";
        if (value is >= 0 and <= 100) return "PERCENT_OR_RATING_FLOAT";
        if (value is >= 100 and <= 50000000) return "AMOUNT_FLOAT";
        return string.Empty;
    }

    private static double ScoreInteger(long value)
    {
        if (value == JeanDatabaseId) return 100;
        if (value is 1982 or 2001 or 2006) return 80;
        if (value is 35 or 65 or 240 or 2700 or 15) return 75;
        if (value is 2560000 or 3000000 or 11000000) return 70;
        if (value == -1 || value == uint.MaxValue) return 25;
        if (value > 0 && value < 100) return 20;
        if (value > 0 && value < 100000) return 10;
        return 0;
    }

    private static double ScoreFloat(float value) => value is >= 0 and <= 100 ? 10 : value is >= 100 and <= 50000000 ? 5 : 0;

    public static string FormatReport(JeanContractRecordFieldReport report)
    {
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — JeanContractRecordFieldDiagnostic 0.0.28");
        sb.AppendLine(new string('=', 92));
        sb.AppendLine($"Arquivo: {report.SourceFile}");
        sb.AppendLine($"Tamanho: {report.SourceSize:N0} bytes");
        sb.AppendLine($"SHA-256: {report.Sha256}");
        sb.AppendLine($"PersonDatabaseId: {report.PersonDatabaseId}");
        sb.AppendLine($"Âncoras encontradas: {report.AnchorOffsets.Count}");
        foreach (long anchor in report.AnchorOffsets) sb.AppendLine($"  0x{anchor:X8}");
        sb.AppendLine($"Leituras produzidas: {report.Fields.Count:N0}");
        sb.AppendLine($"Campos duplicados próximos: {report.Duplicates.Count:N0}");
        sb.AppendLine($"Candidatos a valores conhecidos: {report.KnownValueCandidates.Count:N0}");
        sb.AppendLine();
        sb.AppendLine("Candidatos exatos ou muito próximos:");
        foreach (JeanKnownValueCandidate x in report.KnownValueCandidates.Where(x => x.Assessment is "EXACT" or "VERY_CLOSE").OrderBy(x => Math.Abs(x.RelativeOffset)).Take(80))
            sb.AppendLine($"  {x.Target,-22} {x.Representation,-12} rel={x.RelativeOffset,5} esperado={x.ExpectedValue,12} atual={x.ActualValue,12} erro={x.ErrorRatio:P2} {x.Assessment}");
        sb.AppendLine();
        sb.AppendLine("Campos de maior pontuação:");
        foreach (JeanContractFieldValue x in report.Fields.Where(x => x.Score > 0).OrderByDescending(x => x.Score).ThenBy(x => Math.Abs(x.RelativeOffset)).Take(80))
            sb.AppendLine($"  rel={x.RelativeOffset,5} {x.DataType,-7} valor={x.Value,-16} {x.Interpretation}");
        sb.AppendLine();
        sb.AppendLine("Arquivos gerados: jean-contract-record-field-report.txt, jean-contract-fields.csv, jean-contract-duplicate-fields.csv, jean-contract-known-value-candidates.csv, jean-contract-record-contexts.txt e jean-contract-offset-matrix.csv.");
        sb.AppendLine("O arquivo de origem não foi modificado.");
        return sb.ToString();
    }

    private static string FormatFieldsCsv(JeanContractRecordFieldReport report)
    {
        var sb = new StringBuilder("relative_offset,absolute_offset,data_type,raw_hex,value,interpretation,score\r\n");
        foreach (JeanContractFieldValue x in report.Fields)
            sb.AppendLine(string.Join(',', x.RelativeOffset, $"0x{x.AbsoluteOffset:X8}", x.DataType, x.RawHex, Csv(x.Value), Csv(x.Interpretation), x.Score.ToString("F2", CultureInfo.InvariantCulture)));
        return sb.ToString();
    }

    private static string FormatDuplicatesCsv(JeanContractRecordFieldReport report)
    {
        var sb = new StringBuilder("data_type,value,first_relative_offset,second_relative_offset,distance,occurrences\r\n");
        foreach (JeanDuplicateField x in report.Duplicates)
            sb.AppendLine(string.Join(',', x.DataType, Csv(x.Value), x.FirstRelativeOffset, x.SecondRelativeOffset, x.Distance, x.Occurrences));
        return sb.ToString();
    }

    private static string FormatKnownCsv(JeanContractRecordFieldReport report)
    {
        var sb = new StringBuilder("target,representation,expected_value,relative_offset,absolute_offset,actual_value,error_ratio,assessment\r\n");
        foreach (JeanKnownValueCandidate x in report.KnownValueCandidates.OrderBy(x => x.ErrorRatio).ThenBy(x => Math.Abs(x.RelativeOffset)))
            sb.AppendLine(string.Join(',', Csv(x.Target), Csv(x.Representation), Csv(x.ExpectedValue), x.RelativeOffset, $"0x{x.AbsoluteOffset:X8}", Csv(x.ActualValue), x.ErrorRatio.ToString("F8", CultureInfo.InvariantCulture), x.Assessment));
        return sb.ToString();
    }

    private static string FormatContexts(JeanContractRecordFieldReport report, byte[] data)
    {
        var sb = new StringBuilder();
        foreach (long anchor in report.AnchorOffsets)
        {
            int start = Math.Max(0, checked((int)anchor) - WindowBefore);
            int length = Math.Min(WindowBefore + WindowAfter, data.Length - start);
            sb.AppendLine($"[Jean DBID {JeanDatabaseId} @ 0x{anchor:X8}] janela −{WindowBefore}/+{WindowAfter}");
            for (int offset = 0; offset < length; offset += 16)
            {
                int count = Math.Min(16, length - offset);
                long absolute = start + offset;
                int relative = checked((int)(absolute - anchor));
                sb.Append($"{relative,6:+0;-0;0} 0x{absolute:X8}  ");
                sb.AppendLine(Convert.ToHexString(data.AsSpan(start + offset, count)));
            }
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string FormatOffsetMatrix(JeanContractRecordFieldReport report)
    {
        var byOffset = report.Fields.GroupBy(x => x.RelativeOffset).OrderBy(x => x.Key);
        var sb = new StringBuilder("relative_offset,byte,uint16,int16,uint32,int32,float32\r\n");
        foreach (var group in byOffset)
        {
            string Value(string type) => group.FirstOrDefault(x => x.DataType == type)?.Value ?? string.Empty;
            sb.AppendLine(string.Join(',', group.Key, Csv(Value("BYTE")), Csv(Value("UINT16")), Csv(Value("INT16")), Csv(Value("UINT32")), Csv(Value("INT32")), Csv(Value("FLOAT32"))));
        }
        return sb.ToString();
    }

    private static string Csv(string? value)
    {
        string text = value ?? string.Empty;
        return '"' + text.Replace("\"", "\"\"") + '"';
    }
}
