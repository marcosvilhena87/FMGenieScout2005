﻿using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using FMGenieScout2005.Core.Domain;
using FMGenieScout2005.Core.Models;
using FMGenieScout2005.Core.Parsing;

namespace FMGenieScout2005.Core.Diagnostics;

/// <summary>
/// Correlaciona referências de pessoa com salário, expiração e clube atual conhecidos.
/// Não presume layout nem unidade salarial; testa representações alternativas e produz evidência comparável.
/// </summary>
public sealed class ContractFieldCorrelationDiagnostic
{
    private const int SearchRadius = 8192;
    private const int ContextRadius = 160;
    private const int HighInformationRadius = 2048;

    private static readonly KnownContractSample[] Contracts =
    [
        new("Jean", 315116, 322, "CR Flamengo", 2700, new DateOnly(2006, 1, 31), "Jogador importante da equipe principal", "HIGH_INFORMATION"),
        new("Andrezinho", 302728, 322, "CR Flamengo", 8250, new DateOnly(2005, 12, 31), "Rotação", "NORMAL"),
        new("Dimba", 303048, 322, "CR Flamengo", 12500, new DateOnly(2006, 6, 30), "Jogador Chave", "NORMAL"),
        new("André Bahia", 311169, 322, "CR Flamengo", 1500, new DateOnly(2005, 12, 31), "Rotação", "NORMAL"),
        new("Júnior Baiano", 6900111, 322, "CR Flamengo", 10000, new DateOnly(2004, 12, 31), "Rotação", "NORMAL"),
        new("Fábio Costa", 6900151, 319, "SC Corinthians Paulista", 18000, new DateOnly(2006, 12, 31), "Plantel Principal", "NORMAL"),
        new("Fábio Baiano", 3300471, 319, "SC Corinthians Paulista", 12750, new DateOnly(2004, 12, 31), "Rotação", "PRT"),
        new("Luciano Ratinho", 6900008, 319, "SC Corinthians Paulista", 1800, new DateOnly(2005, 7, 21), "Dispensável", "LST"),
        new("Dinélson", 320774, 319, "SC Corinthians Paulista", 775, new DateOnly(2007, 1, 4), "Reserva", "NORMAL")
    ];

    private static readonly RosterIdentitySample[] Roster =
    [
        new("Jean",315116,322,"CR Flamengo"),new("Felipe",3300005,322,"CR Flamengo"),new("Athirson",3301535,322,"CR Flamengo"),new("Andrezinho",302728,322,"CR Flamengo"),new("Dimba",303048,322,"CR Flamengo"),new("Júlio César",3301242,322,"CR Flamengo"),new("André Bahia",311169,322,"CR Flamengo"),new("Bruno Santos",8832815,322,"CR Flamengo"),new("Ibson",315111,322,"CR Flamengo"),new("Reginaldo Araújo",3300780,322,"CR Flamengo"),new("Anderson",3301240,322,"CR Flamengo"),new("Fabinho",3300169,322,"CR Flamengo"),new("Jonatas",315107,322,"CR Flamengo"),new("Juliano",120919,322,"CR Flamengo"),new("Fabiano Eller",3300219,322,"CR Flamengo"),new("Douglas Silva",3300410,322,"CR Flamengo"),new("Da Silva",8830358,322,"CR Flamengo"),new("Saraiva",8833586,322,"CR Flamengo"),new("Nélio",311154,322,"CR Flamengo"),new("Valentim",306484,322,"CR Flamengo"),new("Diego",315094,322,"CR Flamengo"),new("Júlio César Moraes",8825041,322,"CR Flamengo"),new("Dill",3301274,322,"CR Flamengo"),new("Júnior Baiano",6900111,322,"CR Flamengo"),new("Roger",319213,322,"CR Flamengo"),new("Zinho",3300188,322,"CR Flamengo"),
        new("Gil",3301214,319,"SC Corinthians Paulista"),new("Fabrício",308972,319,"SC Corinthians Paulista"),new("Adrianinho",14525,319,"SC Corinthians Paulista"),new("Édson Araújo",308345,319,"SC Corinthians Paulista"),new("Renato",304568,319,"SC Corinthians Paulista"),new("Régis",3300175,319,"SC Corinthians Paulista"),new("Fabinho",310743,319,"SC Corinthians Paulista"),new("Wilson",8827744,319,"SC Corinthians Paulista"),new("Coelho",319212,319,"SC Corinthians Paulista"),new("Rubinho",302583,319,"SC Corinthians Paulista"),new("Fábio Baiano",3300471,319,"SC Corinthians Paulista"),new("Zé Carlos",3301279,319,"SC Corinthians Paulista"),new("Fábio Costa",6900151,319,"SC Corinthians Paulista"),new("Anderson",302581,319,"SC Corinthians Paulista"),new("Luciano Ratinho",6900008,319,"SC Corinthians Paulista"),new("Doni",3300874,319,"SC Corinthians Paulista"),new("Alessandro",3902245,319,"SC Corinthians Paulista"),new("Wendell",311144,319,"SC Corinthians Paulista"),new("Váldson",3300852,319,"SC Corinthians Paulista"),new("Bebeto",310449,319,"SC Corinthians Paulista"),new("Marcelo Magalhães",302580,319,"SC Corinthians Paulista"),new("Bruno Octávio",8832887,319,"SC Corinthians Paulista"),new("Abuda",320763,319,"SC Corinthians Paulista"),new("Rodrigo",3301506,319,"SC Corinthians Paulista"),new("Rosinei",316596,319,"SC Corinthians Paulista"),new("Dinélson",320774,319,"SC Corinthians Paulista")
    ];

    public async Task<ContractFieldCorrelationReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source)) throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);
        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();

        progress?.Report("Resolvendo pessoas e clubes...");
        Fm2005PersonIdentityParseResult people = new Fm2005PersonIdentityParser().Parse(data, source, sha, progress, cancellationToken);
        Fm2005ClubParseResult clubs = new Fm2005ClubParser().Parse(data, cancellationToken);
        Club flamengo = clubs.FindByDatabaseId(322) ?? throw new InvalidOperationException("Flamengo (DatabaseId 322) não encontrado.");
        Club corinthians = clubs.FindByDatabaseId(319) ?? throw new InvalidOperationException("Corinthians (DatabaseId 319) não encontrado.");

        var references = new List<ContractPersonReference>();
        var salaryHits = new List<ContractSalaryHit>();
        var dateHits = new List<ContractDateHit>();
        var clubHits = new List<ContractClubHit>();
        var candidates = new List<ContractCorrelationCandidate>();
        var missing = new List<string>();

        foreach (KnownContractSample sample in Contracts)
        {
            cancellationToken.ThrowIfCancellationRequested();
            PersonIdentity? identity = people.FindByDatabaseId(sample.PersonDatabaseId);
            if (identity is null) { missing.Add($"{sample.DisplayName} ({sample.PersonDatabaseId})"); continue; }

            var localReferences = new List<ContractPersonReference>();
            AddReferences(localReferences, data, sample, identity, "PERSON_DATABASE_ID", sample.PersonDatabaseId);
            AddReferences(localReferences, data, sample, identity, "INTERNAL_PERSON_ID", identity.SequenceIndex);
            references.AddRange(localReferences);

            foreach (ContractPersonReference reference in localReferences)
            {
                int start = Math.Max(0, checked((int)reference.ReferenceOffset) - SearchRadius);
                int end = Math.Min(data.Length, checked((int)reference.ReferenceOffset) + SearchRadius + 4);

                ContractSalaryHit[] localSalary = FindSalaryHits(data, start, end, sample, reference).ToArray();
                ContractDateHit[] localDates = FindDateHits(data, start, end, sample, reference).ToArray();
                ContractClubHit[] localClubs = FindClubHits(data, start, end, sample, reference, clubs, flamengo.SaveIndex, corinthians.SaveIndex).ToArray();
                salaryHits.AddRange(localSalary);
                dateHits.AddRange(localDates);
                clubHits.AddRange(localClubs);

                BuildCandidates(candidates, data, sample, reference, localSalary, localDates, localClubs);
            }
        }

        ContractFieldOffsetSummary[] summaries = BuildOffsetSummaries(salaryHits, dateHits, clubHits);
        ContractCorrelationCandidate[] orderedCandidates = candidates
            .OrderByDescending(x => x.EvidenceScore)
            .ThenBy(x => x.DisplayName, StringComparer.CurrentCultureIgnoreCase)
            .ThenBy(x => x.ReferenceOffset)
            .Take(5000)
            .ToArray();

        var report = new ContractFieldCorrelationReport(source, data.LongLength, sha, flamengo.SaveIndex, corinthians.SaveIndex,
            Contracts, Roster, references, salaryHits, dateHits, clubHits, orderedCandidates, summaries, missing, output, DateTimeOffset.UtcNow);

        progress?.Report("Gravando relatórios de correlação contratual...");
        await WriteOutputsAsync(report, cancellationToken).ConfigureAwait(false);
        progress?.Report("Executando análise contratual de alta informação do Jean...");
        JeanHighInformationSummary jeanSummary = await WriteJeanHighInformationOutputsAsync(data, people, output, cancellationToken).ConfigureAwait(false);
        progress?.Report($"Análise do Jean concluída: referências={jeanSummary.ReferenceCount}, marcadores={jeanSummary.MarkerHitCount}, candidatos={jeanSummary.CandidateCount}.");
        progress?.Report("Correlação contratual concluída.");
        return report;
    }


    private sealed record JeanHighInformationSummary(
        bool IdentityResolved,
        int ReferenceCount,
        int MarkerHitCount,
        int CandidateCount,
        int StrongCount,
        int MediumCount);

    private sealed record JeanEvidenceCandidate(
        string ReferenceKind,
        long ReferenceOffset,
        bool IsIdentityOccurrence,
        int Score,
        int DistinctMarkerKinds,
        int SpanBytes,
        string Assessment,
        string MarkerSummary,
        string ContextHex);

    private sealed record JeanFallbackIdentityCandidate(
        int DatabaseIdOffset,
        uint InternalPersonId,
        uint StructureMarker,
        string NearbyName,
        int Score,
        string Assessment);

    private static async Task<JeanHighInformationSummary> WriteJeanHighInformationOutputsAsync(
        byte[] data,
        Fm2005PersonIdentityParseResult people,
        string outputDirectory,
        CancellationToken cancellationToken)
    {
        const uint jeanDatabaseId = 315116;
        var utf8 = new UTF8Encoding(true);
        string detailHeader = "reference_kind,reference_offset,is_identity,marker_kind,representation,value,marker_offset,relative_offset,weight\r\n";
        string candidateHeader = "reference_kind,reference_offset,is_identity,score,distinct_marker_kinds,span_bytes,assessment,marker_summary\r\n";
        string occurrenceHeader = "database_id_offset,internal_person_id,structure_marker,nearby_name,score,assessment\r\n";

        PersonIdentity? parsedIdentity = people.FindByDatabaseId(jeanDatabaseId);
        int[] databaseIdOccurrences = FindUInt32(data, jeanDatabaseId).Distinct().OrderBy(x => x).ToArray();
        JeanFallbackIdentityCandidate[] fallbackCandidates = databaseIdOccurrences
            .Select(offset => BuildJeanFallbackIdentityCandidate(data, offset))
            .OrderByDescending(x => x.Score)
            .ThenBy(x => x.DatabaseIdOffset)
            .ToArray();

        var occurrenceCsv = new StringBuilder(occurrenceHeader);
        foreach (JeanFallbackIdentityCandidate x in fallbackCandidates)
            occurrenceCsv.AppendLine($"0x{x.DatabaseIdOffset:X8},{x.InternalPersonId},{x.StructureMarker},{Csv(x.NearbyName)},{x.Score},{x.Assessment}");
        await File.WriteAllTextAsync(Path.Combine(outputDirectory, "jean-database-id-occurrences.csv"), occurrenceCsv.ToString(), utf8, cancellationToken).ConfigureAwait(false);

        uint? fallbackInternalPersonId = fallbackCandidates
            .Where(x => x.Assessment is "IDENTITY_LAYOUT_STRONG" or "IDENTITY_LAYOUT_MEDIUM")
            .Select(x => (uint?)x.InternalPersonId)
            .FirstOrDefault();

        var references = new List<(string Kind, int Offset, bool Identity)>();
        long? parsedIdentityOffset = parsedIdentity is null
            ? null
            : parsedIdentity.NameOffset + (long)parsedIdentity.NameLength * 2L + 12L;

        foreach (int offset in databaseIdOccurrences)
        {
            bool isIdentity = parsedIdentityOffset.HasValue && Math.Abs(offset - parsedIdentityOffset.Value) <= 4;
            if (!isIdentity)
                isIdentity = fallbackCandidates.Any(x => x.DatabaseIdOffset == offset && x.Assessment == "IDENTITY_LAYOUT_STRONG");
            references.Add(("PERSON_DATABASE_ID", offset, isIdentity));
        }

        uint? internalPersonId = parsedIdentity?.SequenceIndex ?? fallbackInternalPersonId;
        if (internalPersonId.HasValue && internalPersonId.Value != 0)
            references.AddRange(FindUInt32(data, internalPersonId.Value).Select(x => ("INTERNAL_PERSON_ID", x, false)));

        references = references.Distinct().OrderBy(x => x.Offset).ToList();

        var markerDefinitions = new List<(string Kind, string Representation, long Value, int Width, int Weight)>
        {
            ("MONTHLY_WAGE", "U16", 2700, 2, 7), ("MONTHLY_WAGE", "U32", 2700, 4, 7),
            ("APPEARANCE_BONUS", "U16", 240, 2, 5), ("APPEARANCE_BONUS", "U32", 240, 4, 5),
            ("GOAL_BONUS", "U16", 65, 2, 5), ("GOAL_BONUS", "U32", 65, 4, 5),
            ("ASSIST_BONUS", "U16", 35, 2, 5), ("ASSIST_BONUS", "U32", 35, 4, 5),
            ("RELEASE_CLAUSE", "U32", 11000000, 4, 8),
            ("MARKET_VALUE", "U32", 3000000, 4, 4),
            ("ANNUAL_RAISE_PERCENT", "U16", 15, 2, 1), ("ANNUAL_RAISE_PERCENT", "U32", 15, 4, 1)
        };

        var candidates = new List<JeanEvidenceCandidate>();
        var detail = new StringBuilder(detailHeader);

        foreach ((string kind, int referenceOffset, bool isIdentity) in references)
        {
            cancellationToken.ThrowIfCancellationRequested();
            int start = Math.Max(0, referenceOffset - HighInformationRadius);
            int end = Math.Min(data.Length, referenceOffset + HighInformationRadius + 4);
            var hits = new List<(string Kind, string Representation, long Value, int Offset, int Relative, int Weight)>();

            foreach (var marker in markerDefinitions)
            {
                foreach (int offset in FindInteger(data, start, end, marker.Value, marker.Width))
                    hits.Add((marker.Kind, marker.Representation, marker.Value, offset, offset - referenceOffset, marker.Weight));
            }

            AddDateMarkerHits(hits, data, start, end, referenceOffset, "CONTRACT_START", new DateOnly(2001, 1, 1), 6);
            AddDateMarkerHits(hits, data, start, end, referenceOffset, "CONTRACT_END", new DateOnly(2006, 1, 31), 7);

            foreach (var hit in hits.OrderBy(x => Math.Abs(x.Relative)))
                detail.AppendLine($"{kind},0x{referenceOffset:X8},{isIdentity},{hit.Kind},{hit.Representation},{hit.Value},0x{hit.Offset:X8},{hit.Relative},{hit.Weight}");

            var nearestByKind = hits
                .GroupBy(x => x.Kind)
                .Select(g => g.OrderBy(x => Math.Abs(x.Relative)).First())
                .ToArray();
            if (nearestByKind.Length == 0) continue;

            int minOffset = nearestByKind.Min(x => x.Offset);
            int maxOffset = nearestByKind.Max(x => x.Offset);
            int span = maxOffset - minOffset;
            int score = nearestByKind.Sum(x => x.Weight);
            if (!isIdentity) score += 5;
            if (nearestByKind.Any(x => x.Kind == "MONTHLY_WAGE")) score += 5;
            if (nearestByKind.Any(x => x.Kind == "RELEASE_CLAUSE")) score += 7;
            if (nearestByKind.Count(x => x.Kind.EndsWith("BONUS", StringComparison.Ordinal)) >= 2) score += 8;
            if (nearestByKind.Any(x => x.Kind == "CONTRACT_START") && nearestByKind.Any(x => x.Kind == "CONTRACT_END")) score += 8;
            if (span <= 256) score += 15; else if (span <= 512) score += 8; else if (span > 1536) score -= 8;

            string assessment = score >= 60 && nearestByKind.Length >= 5 && span <= 768 ? "HIGH_INFORMATION_STRONG"
                : score >= 42 && nearestByKind.Length >= 4 && span <= 1024 ? "HIGH_INFORMATION_MEDIUM"
                : score >= 25 ? "HIGH_INFORMATION_WEAK" : "ISOLATED";
            string summary = string.Join(" | ", nearestByKind.OrderBy(x => x.Offset).Select(x => $"{x.Kind}:{x.Representation}@{x.Relative}"));
            candidates.Add(new JeanEvidenceCandidate(kind, referenceOffset, isIdentity, score, nearestByKind.Length, span, assessment, summary, HexContext(data, referenceOffset, 256)));
        }

        candidates = candidates.OrderByDescending(x => x.Score).ThenBy(x => x.SpanBytes).ThenBy(x => x.ReferenceOffset).ToList();
        var csv = new StringBuilder(candidateHeader);
        foreach (JeanEvidenceCandidate x in candidates)
            csv.AppendLine($"{x.ReferenceKind},0x{x.ReferenceOffset:X8},{x.IsIdentityOccurrence},{x.Score},{x.DistinctMarkerKinds},{x.SpanBytes},{x.Assessment},{Csv(x.MarkerSummary)}");

        var contexts = new StringBuilder();
        foreach (JeanEvidenceCandidate x in candidates.Take(100))
        {
            contexts.AppendLine($"[{x.Assessment}] score={x.Score} {x.ReferenceKind}@0x{x.ReferenceOffset:X8} identity={x.IsIdentityOccurrence} markers={x.DistinctMarkerKinds} span={x.SpanBytes}");
            contexts.AppendLine(x.MarkerSummary);
            contexts.AppendLine(x.ContextHex);
            contexts.AppendLine();
        }

        await File.WriteAllTextAsync(Path.Combine(outputDirectory, "jean-high-information-marker-hits.csv"), detail.ToString(), utf8, cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(outputDirectory, "high-information-contract-candidates.csv"), csv.ToString(), utf8, cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(outputDirectory, "high-information-contract-contexts.txt"), contexts.ToString(), utf8, cancellationToken).ConfigureAwait(false);

        int strongCount = candidates.Count(x => x.Assessment == "HIGH_INFORMATION_STRONG");
        int mediumCount = candidates.Count(x => x.Assessment == "HIGH_INFORMATION_MEDIUM");
        int markerHitCount = Math.Max(0, detail.ToString().Count(c => c == '\n') - 1);
        var report = new StringBuilder();
        report.AppendLine("FM Genie Scout 2005 — JeanIdentityFallbackDiagnostic 0.0.27.2");
        report.AppendLine(new string('=', 82));
        report.AppendLine($"ParserIdentityResolved: {parsedIdentity is not null}");
        report.AppendLine($"FallbackIdentityResolved: {fallbackInternalPersonId.HasValue}");
        report.AppendLine($"PersonDatabaseId: {jeanDatabaseId}");
        report.AppendLine($"InternalPersonId: {(internalPersonId.HasValue ? internalPersonId.Value.ToString(CultureInfo.InvariantCulture) : "NAO_RESOLVIDO")}");
        report.AppendLine($"Ocorrências globais do DatabaseId: {databaseIdOccurrences.Length:N0}");
        report.AppendLine($"Candidatos de identidade por layout: {fallbackCandidates.Length:N0}");
        report.AppendLine($"Referências globais avaliadas: {references.Count:N0}");
        report.AppendLine($"Hits de marcadores gravados: {markerHitCount:N0}");
        report.AppendLine($"Candidatos contratuais: {candidates.Count:N0}");
        report.AppendLine($"Fortes: {strongCount:N0}");
        report.AppendLine($"Médios: {mediumCount:N0}");
        report.AppendLine();
        report.AppendLine("Melhores candidatos de identidade:");
        foreach (JeanFallbackIdentityCandidate x in fallbackCandidates.Take(20))
            report.AppendLine($"  {x.Assessment,-24} dbid@0x{x.DatabaseIdOffset:X8} internal={x.InternalPersonId,8} marker={x.StructureMarker,5} score={x.Score,3} nome={x.NearbyName}");
        report.AppendLine();
        report.AppendLine("Arquivos gerados:");
        report.AppendLine("  jean-database-id-occurrences.csv");
        report.AppendLine("  jean-high-information-marker-hits.csv");
        report.AppendLine("  high-information-contract-candidates.csv");
        report.AppendLine("  high-information-contract-contexts.txt");
        await File.WriteAllTextAsync(Path.Combine(outputDirectory, "jean-high-information-report.txt"), report.ToString(), utf8, cancellationToken).ConfigureAwait(false);

        bool identityResolved = parsedIdentity is not null || fallbackInternalPersonId.HasValue;
        return new JeanHighInformationSummary(identityResolved, references.Count, markerHitCount, candidates.Count, strongCount, mediumCount);
    }

    private static JeanFallbackIdentityCandidate BuildJeanFallbackIdentityCandidate(byte[] data, int databaseIdOffset)
    {
        uint marker = databaseIdOffset >= 8 ? ReadUInt32Safe(data, databaseIdOffset - 8) : 0;
        uint internalId = databaseIdOffset >= 4 ? ReadUInt32Safe(data, databaseIdOffset - 4) : 0;
        string nearbyName = FindNearestUtf16NameBefore(data, databaseIdOffset, 512);
        int score = 0;
        if (marker == 189) score += 55;
        if (internalId is > 0 and <= 2_000_000) score += 20;
        if (!string.IsNullOrWhiteSpace(nearbyName)) score += 15;
        if (nearbyName.Contains("Jean", StringComparison.OrdinalIgnoreCase)) score += 20;
        string assessment = score >= 85 ? "IDENTITY_LAYOUT_STRONG" : score >= 60 ? "IDENTITY_LAYOUT_MEDIUM" : "REFERENCE_ONLY";
        return new JeanFallbackIdentityCandidate(databaseIdOffset, internalId, marker, nearbyName, score, assessment);
    }

    private static uint ReadUInt32Safe(byte[] data, int offset)
    {
        if (offset < 0 || offset + 4 > data.Length) return 0;
        return BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(offset, 4));
    }

    private static string FindNearestUtf16NameBefore(byte[] data, int endOffset, int maxDistance)
    {
        int start = Math.Max(0, endOffset - maxDistance);
        string best = string.Empty;
        int bestEnd = -1;
        for (int offset = start; offset <= endOffset - 8; offset++)
        {
            int length = BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(offset, 4));
            if (length < 2 || length > 80) continue;
            int byteLength = length * 2;
            int textOffset = offset + 4;
            int terminatorOffset = textOffset + byteLength;
            if (terminatorOffset + 2 > endOffset || terminatorOffset + 2 > data.Length) continue;
            if (data[terminatorOffset] != 0 || data[terminatorOffset + 1] != 0) continue;
            string text = Encoding.Unicode.GetString(data, textOffset, byteLength);
            if (!IsPlausibleFallbackName(text)) continue;
            if (terminatorOffset > bestEnd)
            {
                best = text;
                bestEnd = terminatorOffset;
            }
        }
        return best;
    }

    private static bool IsPlausibleFallbackName(string value)
    {
        if (string.IsNullOrWhiteSpace(value) || value.Length is < 2 or > 80) return false;
        int letters = value.Count(char.IsLetter);
        return letters >= 2 && letters * 2 >= value.Length;
    }

    private static void AddDateMarkerHits(
        List<(string Kind, string Representation, long Value, int Offset, int Relative, int Weight)> hits,
        byte[] data, int start, int end, int referenceOffset, string kind, DateOnly date, int weight)
    {
        foreach ((string representation, byte[] pattern, string encoded) in DateRepresentations(date))
        {
            foreach (int offset in FindPattern(data, start, end, pattern))
            {
                long numeric = long.TryParse(encoded.Replace(",", string.Empty, StringComparison.Ordinal), NumberStyles.Integer, CultureInfo.InvariantCulture, out long parsed) ? parsed : 0L;
                hits.Add((kind, representation, numeric, offset, offset - referenceOffset, weight));
            }
        }
    }

    private static void AddReferences(List<ContractPersonReference> output, byte[] data, KnownContractSample sample, PersonIdentity identity, string kind, uint value)
    {
        long identityIdOffset = identity.NameOffset + (long)identity.NameLength * 2L + 12L;
        foreach (int offset in FindUInt32(data, value))
        {
            bool isIdentity = kind == "PERSON_DATABASE_ID" && Math.Abs(offset - identityIdOffset) <= 4;
            output.Add(new ContractPersonReference(sample.DisplayName, sample.PersonDatabaseId, identity.SequenceIndex,
                sample.ExpectedClubDatabaseId, kind, offset, isIdentity));
        }
    }

    private static IEnumerable<ContractSalaryHit> FindSalaryHits(byte[] data, int start, int end, KnownContractSample sample, ContractPersonReference reference)
    {
        foreach ((string name, long value, int width) in SalaryRepresentations(sample.MonthlyWage))
        {
            foreach (int offset in FindInteger(data, start, end, value, width))
                yield return new ContractSalaryHit(sample.DisplayName, sample.PersonDatabaseId, reference.ReferenceKind,
                    reference.ReferenceOffset, name, value, offset, checked((int)(offset - reference.ReferenceOffset)), sample.MonthlyWage);
        }
    }

    private static IEnumerable<(string Name, long Value, int Width)> SalaryRepresentations(int monthly)
    {
        var seen = new HashSet<(long, int)>();
        long annual = checked((long)monthly * 12L);
        double weeklyExact = monthly * 12.0 / 52.0;
        long[] weekly = [(long)Math.Floor(weeklyExact), (long)Math.Round(weeklyExact), (long)Math.Ceiling(weeklyExact)];
        long daily = (long)Math.Round(monthly * 12.0 / 365.0);
        var raw = new List<(string, long)>{("MONTHLY",monthly),("ANNUAL",annual),("MONTHLY_X100",(long)monthly*100L),("DAILY_APPROX",daily)};
        raw.AddRange(weekly.Distinct().Select((x, i) => ($"WEEKLY_APPROX_{i + 1}", x)));
        foreach ((string name, long value) in raw.Where(x => x.Item2 >= 0))
        {
            if (value <= ushort.MaxValue && seen.Add((value,2))) yield return ($"{name}_U16", value, 2);
            if (value <= uint.MaxValue && seen.Add((value,4))) yield return ($"{name}_U32", value, 4);
        }
    }

    private static IEnumerable<ContractDateHit> FindDateHits(byte[] data, int start, int end, KnownContractSample sample, ContractPersonReference reference)
    {
        foreach ((string name, byte[] pattern, string encoded) in DateRepresentations(sample.ExpirationDate))
        {
            foreach (int offset in FindPattern(data, start, end, pattern))
                yield return new ContractDateHit(sample.DisplayName, sample.PersonDatabaseId, reference.ReferenceKind,
                    reference.ReferenceOffset, name, encoded, offset, checked((int)(offset - reference.ReferenceOffset)), sample.ExpirationDate);
        }
    }

    private static IEnumerable<(string Name, byte[] Pattern, string Encoded)> DateRepresentations(DateOnly date)
    {
        static byte[] U16(params int[] values)
        {
            byte[] b = new byte[values.Length * 2];
            for (int i = 0; i < values.Length; i++) BinaryPrimitives.WriteUInt16LittleEndian(b.AsSpan(i * 2, 2), checked((ushort)values[i]));
            return b;
        }
        static byte[] U32(params int[] values)
        {
            byte[] b = new byte[values.Length * 4];
            for (int i = 0; i < values.Length; i++) BinaryPrimitives.WriteInt32LittleEndian(b.AsSpan(i * 4, 4), values[i]);
            return b;
        }
        static byte[] I32(int value) { byte[] b = new byte[4]; BinaryPrimitives.WriteInt32LittleEndian(b, value); return b; }

        int ymd = checked(date.Year * 10000 + date.Month * 100 + date.Day);
        int dmy = checked(date.Day * 1000000 + date.Month * 10000 + date.Year);
        int dos = ((date.Year - 1980) << 9) | (date.Month << 5) | date.Day;
        int days1900 = date.DayNumber - new DateOnly(1900, 1, 1).DayNumber;
        int days1970 = date.DayNumber - new DateOnly(1970, 1, 1).DayNumber;
        yield return ("YMD_U16", U16(date.Year,date.Month,date.Day), $"{date.Year},{date.Month},{date.Day}");
        yield return ("DMY_U16", U16(date.Day,date.Month,date.Year), $"{date.Day},{date.Month},{date.Year}");
        yield return ("YMD_U32", U32(date.Year,date.Month,date.Day), $"{date.Year},{date.Month},{date.Day}");
        yield return ("DMY_U32", U32(date.Day,date.Month,date.Year), $"{date.Day},{date.Month},{date.Year}");
        if (date.Year >= 1980 && date.Year <= 2107) yield return ("DOS_DATE_U16", U16(dos), dos.ToString(CultureInfo.InvariantCulture));
        yield return ("YYYYMMDD_I32", I32(ymd), ymd.ToString(CultureInfo.InvariantCulture));
        yield return ("DDMMYYYY_I32", I32(dmy), dmy.ToString(CultureInfo.InvariantCulture));
        yield return ("DAYS_SINCE_1900_I32", I32(days1900), days1900.ToString(CultureInfo.InvariantCulture));
        yield return ("DAYS_SINCE_1970_I32", I32(days1970), days1970.ToString(CultureInfo.InvariantCulture));
    }

    private static IEnumerable<ContractClubHit> FindClubHits(byte[] data, int start, int end, KnownContractSample sample,
        ContractPersonReference reference, Fm2005ClubParseResult clubs, uint flamengoIndex, uint corinthiansIndex)
    {
        uint expectedIndex = sample.ExpectedClubDatabaseId == 322 ? flamengoIndex : corinthiansIndex;
        foreach (int offset in FindInteger(data, start, end, expectedIndex, 4))
        {
            Club? club = clubs.FindBySaveIndex(expectedIndex);
            if (club is not null)
                yield return new ContractClubHit(sample.DisplayName, sample.PersonDatabaseId, reference.ReferenceKind,
                    reference.ReferenceOffset, "UINT32", expectedIndex, offset, checked((int)(offset-reference.ReferenceOffset)),
                    club.DatabaseId, club.FullName, club.DatabaseId == sample.ExpectedClubDatabaseId);
        }
        if (expectedIndex <= ushort.MaxValue)
        {
            foreach (int offset in FindInteger(data, start, end, expectedIndex, 2))
            {
                Club? club = clubs.FindBySaveIndex(expectedIndex);
                if (club is not null)
                    yield return new ContractClubHit(sample.DisplayName, sample.PersonDatabaseId, reference.ReferenceKind,
                        reference.ReferenceOffset, "UINT16", expectedIndex, offset, checked((int)(offset-reference.ReferenceOffset)),
                        club.DatabaseId, club.FullName, club.DatabaseId == sample.ExpectedClubDatabaseId);
            }
        }
    }

    private static void BuildCandidates(List<ContractCorrelationCandidate> output, byte[] data, KnownContractSample sample,
        ContractPersonReference reference, IReadOnlyList<ContractSalaryHit> salaries, IReadOnlyList<ContractDateHit> dates,
        IReadOnlyList<ContractClubHit> clubs)
    {
        ContractSalaryHit? salary = salaries.OrderBy(x => Math.Abs(x.RelativeOffset)).FirstOrDefault();
        ContractDateHit? date = dates.OrderBy(x => Math.Abs(x.RelativeOffset)).FirstOrDefault();
        ContractClubHit? club = clubs.Where(x => x.ExpectedClub).OrderBy(x => Math.Abs(x.RelativeOffset)).FirstOrDefault();
        int score = 0;
        if (salary is not null) score += salary.Representation.StartsWith("MONTHLY_", StringComparison.Ordinal) ? 35 : 22;
        if (date is not null) score += date.Representation is "YMD_U16" or "DMY_U16" or "YMD_U32" or "DMY_U32" ? 35 : 24;
        if (club is not null) score += 20;
        if (!reference.IsIdentityOccurrence) score += 10;
        if (salary is not null && date is not null && Math.Abs(salary.ValueOffset - date.ValueOffset) <= 512) score += 15;
        if (score == 0) return;
        string assessment = score >= 90 ? "CONTRACT_CANDIDATE_STRONG" : score >= 65 ? "CONTRACT_CANDIDATE_MEDIUM" : score >= 40 ? "CONTRACT_CANDIDATE_WEAK" : "EVIDENCE_ISOLATED";
        output.Add(new ContractCorrelationCandidate(sample.DisplayName, sample.PersonDatabaseId, reference.ReferenceKind,
            reference.ReferenceOffset, reference.IsIdentityOccurrence, sample.MonthlyWage, sample.ExpirationDate,
            sample.ExpectedClubDatabaseId, sample.ExpectedClubName, salary?.Representation ?? string.Empty,
            salary?.RelativeOffset, date?.Representation ?? string.Empty, date?.RelativeOffset,
            club?.Width ?? string.Empty, club?.RelativeOffset, club?.ResolvedClubDatabaseId, club?.ResolvedClubName,
            score, assessment, HexContext(data, checked((int)reference.ReferenceOffset), ContextRadius)));
    }

    private static ContractFieldOffsetSummary[] BuildOffsetSummaries(IReadOnlyList<ContractSalaryHit> salaryHits,
        IReadOnlyList<ContractDateHit> dateHits, IReadOnlyList<ContractClubHit> clubHits)
    {
        var rows = new List<(string Kind,string Reference,string Representation,int Offset,string Player,uint ClubId)>();
        rows.AddRange(salaryHits.Select(x => ("SALARY",x.ReferenceKind,x.Representation,x.RelativeOffset,x.DisplayName,
            Contracts.First(c=>c.PersonDatabaseId==x.PersonDatabaseId).ExpectedClubDatabaseId)));
        rows.AddRange(dateHits.Select(x => ("DATE",x.ReferenceKind,x.Representation,x.RelativeOffset,x.DisplayName,
            Contracts.First(c=>c.PersonDatabaseId==x.PersonDatabaseId).ExpectedClubDatabaseId)));
        rows.AddRange(clubHits.Where(x=>x.ExpectedClub).Select(x => ("CLUB",x.ReferenceKind,x.Width,x.RelativeOffset,x.DisplayName,
            Contracts.First(c=>c.PersonDatabaseId==x.PersonDatabaseId).ExpectedClubDatabaseId)));
        return rows.GroupBy(x => new { x.Kind, x.Reference, x.Representation, x.Offset })
            .Select(g =>
            {
                string[] players = g.Select(x=>x.Player).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x=>x).ToArray();
                int fla = g.Where(x=>x.ClubId==322).Select(x=>x.Player).Distinct(StringComparer.OrdinalIgnoreCase).Count();
                int cor = g.Where(x=>x.ClubId==319).Select(x=>x.Player).Distinct(StringComparer.OrdinalIgnoreCase).Count();
                string assessment = players.Length >= 6 && fla >= 2 && cor >= 2 ? "SHARED_FIELD_STRONG" : players.Length >= 4 ? "SHARED_FIELD_MEDIUM" : players.Length >= 2 ? "SHARED_FIELD_WEAK" : "ISOLATED";
                return new ContractFieldOffsetSummary(g.Key.Kind,g.Key.Reference,g.Key.Representation,g.Key.Offset,players.Length,fla,cor,string.Join(" | ",players),assessment);
            })
            .OrderByDescending(x=>x.DistinctPlayers).ThenBy(x=>x.EvidenceKind).ThenBy(x=>Math.Abs(x.RelativeOffset)).ToArray();
    }

    private static IEnumerable<int> FindUInt32(byte[] data, uint value) => FindInteger(data, 0, data.Length, value, 4);

    private static IEnumerable<int> FindInteger(byte[] data, int start, int end, long value, int width)
    {
        if (width == 2)
        {
            if (value < 0 || value > ushort.MaxValue) yield break;
            ushort v = (ushort)value; byte b0=(byte)v,b1=(byte)(v>>8);
            for(int i=start;i<=end-2;i++) if(data[i]==b0&&data[i+1]==b1) yield return i;
        }
        else
        {
            if (value < 0 || value > uint.MaxValue) yield break;
            uint v=(uint)value; byte b0=(byte)v,b1=(byte)(v>>8),b2=(byte)(v>>16),b3=(byte)(v>>24);
            for(int i=start;i<=end-4;i++) if(data[i]==b0&&data[i+1]==b1&&data[i+2]==b2&&data[i+3]==b3) yield return i;
        }
    }

    private static IEnumerable<int> FindPattern(byte[] data, int start, int end, byte[] pattern)
    {
        if (pattern.Length == 0) yield break;
        for (int i=start;i<=end-pattern.Length;i++)
        {
            bool match=true;
            for(int j=0;j<pattern.Length;j++) if(data[i+j]!=pattern[j]) { match=false; break; }
            if(match) yield return i;
        }
    }

    private static string HexContext(byte[] data, int center, int radius)
    {
        int start=Math.Max(0,center-radius); int length=Math.Min(data.Length-start,radius*2);
        return Convert.ToHexString(data.AsSpan(start,length));
    }

    public static string FormatReport(ContractFieldCorrelationReport r)
    {
        int strong=r.Candidates.Count(x=>x.Assessment=="CONTRACT_CANDIDATE_STRONG");
        int medium=r.Candidates.Count(x=>x.Assessment=="CONTRACT_CANDIDATE_MEDIUM");
        var sb=new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — ContractFieldCorrelationDiagnostic 0.0.27.1");
        sb.AppendLine(new string('=',96));
        sb.AppendLine($"Arquivo: {r.SourceFile}"); sb.AppendLine($"Tamanho: {r.SourceSize:N0} bytes"); sb.AppendLine($"SHA-256: {r.Sha256}");
        sb.AppendLine($"Flamengo SaveIndex: {r.FlamengoSaveIndex} | Corinthians SaveIndex: {r.CorinthiansSaveIndex}");
        sb.AppendLine($"Contratos conhecidos: {r.KnownContracts.Count} | IDs de elenco para validação: {r.RosterSamples.Count}");
        sb.AppendLine($"Referências de pessoa: {r.PersonReferences.Count:N0}"); sb.AppendLine($"Hits salariais: {r.SalaryHits.Count:N0} | hits de data: {r.DateHits.Count:N0} | hits de clube: {r.ClubHits.Count:N0}");
        sb.AppendLine($"Candidatos fortes: {strong:N0} | médios: {medium:N0}");
        sb.AppendLine(); sb.AppendLine("Melhores candidatos:");
        foreach(var x in r.Candidates.Take(40)) sb.AppendLine($"  {x.Assessment,-26} score={x.EvidenceScore,3} {x.DisplayName,-20} {x.ReferenceKind,-20} ref=0x{x.ReferenceOffset:X8} salário={x.SalaryRepresentation}@{x.SalaryRelativeOffset} data={x.DateRepresentation}@{x.DateRelativeOffset} clube={x.ResolvedClubName}@{x.ClubRelativeOffset}");
        sb.AppendLine(); sb.AppendLine("Melhores offsets compartilhados:");
        foreach(var x in r.OffsetSummaries.Take(40)) sb.AppendLine($"  {x.Assessment,-22} {x.EvidenceKind,-7} {x.ReferenceKind,-20} {x.Representation,-22} rel={x.RelativeOffset,6} jogadores={x.DistinctPlayers} FLA={x.FlamengoPlayers} COR={x.CorinthiansPlayers}");
        if(r.MissingPeople.Count>0){sb.AppendLine();sb.AppendLine("Pessoas não resolvidas:");foreach(string x in r.MissingPeople)sb.AppendLine("  "+x);} 
        sb.AppendLine(); sb.AppendLine("Arquivos: contract-field-correlation-report.txt, known-contracts.csv, full-roster-validation.csv, contract-reference-occurrences.csv, contract-salary-hits.csv, contract-date-hits.csv, contract-club-hits.csv, contract-correlation-candidates.csv, contract-field-offset-summaries.csv, contract-correlation-contexts.txt, jean-high-information-marker-hits.csv, high-information-contract-candidates.csv e high-information-contract-contexts.txt e jean-high-information-report.txt.");
        sb.AppendLine("O save não foi modificado."); return sb.ToString();
    }

    private static async Task WriteOutputsAsync(ContractFieldCorrelationReport r, CancellationToken ct)
    {
        var utf8=new UTF8Encoding(true);
        await File.WriteAllTextAsync(Path.Combine(r.OutputDirectory,"contract-field-correlation-report.txt"),FormatReport(r),utf8,ct).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(r.OutputDirectory,"known-contracts.csv"),KnownContractsCsv(r),utf8,ct).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(r.OutputDirectory,"full-roster-validation.csv"),RosterCsv(r),utf8,ct).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(r.OutputDirectory,"contract-reference-occurrences.csv"),ReferencesCsv(r),utf8,ct).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(r.OutputDirectory,"contract-salary-hits.csv"),SalaryCsv(r),utf8,ct).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(r.OutputDirectory,"contract-date-hits.csv"),DateCsv(r),utf8,ct).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(r.OutputDirectory,"contract-club-hits.csv"),ClubCsv(r),utf8,ct).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(r.OutputDirectory,"contract-correlation-candidates.csv"),CandidatesCsv(r),utf8,ct).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(r.OutputDirectory,"contract-field-offset-summaries.csv"),SummariesCsv(r),utf8,ct).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(r.OutputDirectory,"contract-correlation-contexts.txt"),Contexts(r),utf8,ct).ConfigureAwait(false);
    }

    private static string KnownContractsCsv(ContractFieldCorrelationReport r){var b=new StringBuilder("player,person_database_id,club_database_id,club,monthly_wage,expiration,squad_status,sample_status\r\n");foreach(var x in r.KnownContracts)b.AppendLine($"{Csv(x.DisplayName)},{x.PersonDatabaseId},{x.ExpectedClubDatabaseId},{Csv(x.ExpectedClubName)},{x.MonthlyWage},{x.ExpirationDate:yyyy-MM-dd},{Csv(x.SquadStatus)},{x.SampleStatus}");return b.ToString();}
    private static string RosterCsv(ContractFieldCorrelationReport r){var b=new StringBuilder("player,person_database_id,club_database_id,club\r\n");foreach(var x in r.RosterSamples)b.AppendLine($"{Csv(x.DisplayName)},{x.PersonDatabaseId},{x.ExpectedClubDatabaseId},{Csv(x.ExpectedClubName)}");return b.ToString();}
    private static string ReferencesCsv(ContractFieldCorrelationReport r){var b=new StringBuilder("player,person_database_id,internal_person_id,club_database_id,reference_kind,reference_offset,is_identity\r\n");foreach(var x in r.PersonReferences)b.AppendLine($"{Csv(x.DisplayName)},{x.PersonDatabaseId},{x.InternalPersonId},{x.ExpectedClubDatabaseId},{x.ReferenceKind},0x{x.ReferenceOffset:X8},{x.IsIdentityOccurrence}");return b.ToString();}
    private static string SalaryCsv(ContractFieldCorrelationReport r){var b=new StringBuilder("player,person_database_id,reference_kind,reference_offset,representation,encoded_value,value_offset,relative_offset,monthly_wage\r\n");foreach(var x in r.SalaryHits)b.AppendLine($"{Csv(x.DisplayName)},{x.PersonDatabaseId},{x.ReferenceKind},0x{x.ReferenceOffset:X8},{x.Representation},{x.EncodedValue},0x{x.ValueOffset:X8},{x.RelativeOffset},{x.MonthlyWage}");return b.ToString();}
    private static string DateCsv(ContractFieldCorrelationReport r){var b=new StringBuilder("player,person_database_id,reference_kind,reference_offset,representation,encoded_value,value_offset,relative_offset,expiration\r\n");foreach(var x in r.DateHits)b.AppendLine($"{Csv(x.DisplayName)},{x.PersonDatabaseId},{x.ReferenceKind},0x{x.ReferenceOffset:X8},{x.Representation},{Csv(x.EncodedValue)},0x{x.ValueOffset:X8},{x.RelativeOffset},{x.ExpirationDate:yyyy-MM-dd}");return b.ToString();}
    private static string ClubCsv(ContractFieldCorrelationReport r){var b=new StringBuilder("player,person_database_id,reference_kind,reference_offset,width,club_save_index,value_offset,relative_offset,resolved_club_database_id,resolved_club,expected\r\n");foreach(var x in r.ClubHits)b.AppendLine($"{Csv(x.DisplayName)},{x.PersonDatabaseId},{x.ReferenceKind},0x{x.ReferenceOffset:X8},{x.Width},{x.ClubSaveIndex},0x{x.ValueOffset:X8},{x.RelativeOffset},{x.ResolvedClubDatabaseId},{Csv(x.ResolvedClubName)},{x.ExpectedClub}");return b.ToString();}
    private static string CandidatesCsv(ContractFieldCorrelationReport r){var b=new StringBuilder("player,person_database_id,reference_kind,reference_offset,is_identity,monthly_wage,expiration,expected_club_database_id,expected_club,salary_representation,salary_relative_offset,date_representation,date_relative_offset,club_width,club_relative_offset,resolved_club_database_id,resolved_club,evidence_score,assessment\r\n");foreach(var x in r.Candidates)b.AppendLine($"{Csv(x.DisplayName)},{x.PersonDatabaseId},{x.ReferenceKind},0x{x.ReferenceOffset:X8},{x.IsIdentityOccurrence},{x.MonthlyWage},{x.ExpirationDate:yyyy-MM-dd},{x.ExpectedClubDatabaseId},{Csv(x.ExpectedClubName)},{x.SalaryRepresentation},{x.SalaryRelativeOffset},{x.DateRepresentation},{x.DateRelativeOffset},{x.ClubWidth},{x.ClubRelativeOffset},{x.ResolvedClubDatabaseId},{Csv(x.ResolvedClubName)},{x.EvidenceScore},{x.Assessment}");return b.ToString();}
    private static string SummariesCsv(ContractFieldCorrelationReport r){var b=new StringBuilder("evidence_kind,reference_kind,representation,relative_offset,distinct_players,flamengo_players,corinthians_players,players,assessment\r\n");foreach(var x in r.OffsetSummaries)b.AppendLine($"{x.EvidenceKind},{x.ReferenceKind},{x.Representation},{x.RelativeOffset},{x.DistinctPlayers},{x.FlamengoPlayers},{x.CorinthiansPlayers},{Csv(x.PlayerNames)},{x.Assessment}");return b.ToString();}
    private static string Contexts(ContractFieldCorrelationReport r){var b=new StringBuilder();foreach(var x in r.Candidates.Take(200)){b.AppendLine($"[{x.Assessment}] {x.DisplayName} id={x.PersonDatabaseId} score={x.EvidenceScore} ref={x.ReferenceKind}@0x{x.ReferenceOffset:X8}");b.AppendLine($"salário={x.SalaryRepresentation}@{x.SalaryRelativeOffset} data={x.DateRepresentation}@{x.DateRelativeOffset} clube={x.ResolvedClubName}@{x.ClubRelativeOffset}");b.AppendLine(x.ContextHex);b.AppendLine();}return b.ToString();}
    private static string Csv(string? value){string s=value??string.Empty;return '"'+s.Replace("\"","\"\"")+'"';}
}
