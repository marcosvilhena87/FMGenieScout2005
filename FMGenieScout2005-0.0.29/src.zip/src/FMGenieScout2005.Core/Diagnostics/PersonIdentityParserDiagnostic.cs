using System.Globalization;
using System.Text;
using FMGenieScout2005.Core.Domain;
using FMGenieScout2005.Core.Models;
using FMGenieScout2005.Core.Parsing;

namespace FMGenieScout2005.Core.Diagnostics;

public sealed class PersonIdentityParserDiagnostic
{
    private static readonly KnownPersonValidation[] KnownPeople =
    [
        new("Andrezinho", 302728, ["Andre Luiz Tavares", "André Luiz Tavares"]),
        new("André Bahia", 311169, ["André Bahia", "Andre Bahia"]),
        new("Bruno Santos", 8832815, ["Bruno Santos"]),
        new("Dimba", 303048, ["Dimba"]),
        new("Douglas Silva", 3300410, ["Douglas Silva"]),
        new("Fabiano Eller", 3300219, ["Fabiano Eller"]),
        new("Júlio César Moraes", 8825041, ["Júlio César Moraes", "Julio Cesar Moraes"]),
        new("Júnior Baiano", 6900111, ["Júnior Baiano", "Junior Baiano"]),
        new("Reginaldo Araújo", 3300780, ["Reginaldo Araújo", "Reginaldo Araujo"])
    ];

    private readonly Fm2005PersonIdentityParser _parser = new();

    public async Task<PersonIdentityParserReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        Fm2005PersonIdentityParseResult parsed = await _parser
            .ParseFileAsync(inputFile, progress, cancellationToken)
            .ConfigureAwait(false);

        progress?.Report("Validando os nove jogadores conhecidos...");
        PersonIdentityValidation[] validations = KnownPeople.Select(expected =>
        {
            PersonIdentity? person = parsed.FindByDatabaseId(expected.DatabaseId);
            if (person is null)
                return new PersonIdentityValidation(expected.DisplayName, expected.DatabaseId, false, null, null, null, null, null, false, "ID_NAO_ENCONTRADO");

            bool nameMatches = expected.ExpectedIdentityNames.Any(name => Equivalent(name, person.IdentityName));
            string status = nameMatches ? "ID_E_NOME_CONFIRMADOS" : "ID_CONFIRMADO_NOME_DIVERGENTE";
            return new PersonIdentityValidation(expected.DisplayName, expected.DatabaseId, true, person.IdentityName,
                person.SequenceIndex, person.RecordType, person.RecordOffset, person.NameOffset, nameMatches, status);
        }).ToArray();

        var report = new PersonIdentityParserReport(
            parsed.SourceFile,
            parsed.SourceSize,
            parsed.Sha256,
            parsed.People,
            parsed.RejectedCandidateCount,
            validations,
            output,
            DateTimeOffset.UtcNow);

        progress?.Report("Gravando relatórios do parser de pessoas...");
        await File.WriteAllTextAsync(Path.Combine(output, "person-identity-parser-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "all-person-identities.csv"), FormatPeopleCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "known-player-validation.csv"), FormatValidationCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "person-identity-structure.txt"), FormatStructure(), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        progress?.Report("Parser de identidades 0.0.22 concluído.");
        return report;
    }

    public static string FormatReport(PersonIdentityParserReport report)
    {
        int found = report.Validations.Count(x => x.Found);
        int confirmed = report.Validations.Count(x => x.Status == "ID_E_NOME_CONFIRMADOS");
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — PersonIdentityParserDiagnostic 0.0.22");
        sb.AppendLine(new string('=', 94));
        sb.AppendLine($"Arquivo: {report.SourceFile}");
        sb.AppendLine($"Tamanho: {report.SourceSize:N0} bytes");
        sb.AppendLine($"SHA-256: {report.Sha256}");
        sb.AppendLine($"Identidades únicas extraídas: {report.People.Count:N0}");
        sb.AppendLine($"Candidatos estruturais rejeitados: {report.RejectedCandidateCount:N0}");
        sb.AppendLine($"IDs conhecidos encontrados: {found}/{report.Validations.Count}");
        sb.AppendLine($"IDs e nomes confirmados: {confirmed}/{report.Validations.Count}");
        sb.AppendLine();
        sb.AppendLine("Estrutura utilizada:");
        sb.AppendLine("  Int32 NameLength | UTF-16LE Name | UInt16 0 | UInt16 RecordType | UInt32 189 | UInt32 SequenceIndex | UInt32 DatabaseId");
        sb.AppendLine("  DatabaseId fica 12 bytes após o fim dos caracteres UTF-16LE do nome de identidade.");
        sb.AppendLine();
        sb.AppendLine("Validação conhecida:");
        foreach (PersonIdentityValidation x in report.Validations)
            sb.AppendLine($"  {x.DisplayName,-24} id={x.ExpectedDatabaseId,8} seq={Format(x.SequenceIndex),8} tipo={Format(x.RecordType),4} | {x.ParsedIdentityName ?? "-"} | {x.Status}");
        sb.AppendLine();
        sb.AppendLine("Primeiras identidades por índice sequencial:");
        foreach (PersonIdentity x in report.People.Take(60))
            sb.AppendLine($"  seq={x.SequenceIndex,7} id={x.DatabaseId,9} tipo={x.RecordType,3} offset=0x{x.RecordOffset:X8} | {x.IdentityName}");
        sb.AppendLine();
        sb.AppendLine("Arquivos gerados: person-identity-parser-report.txt, all-person-identities.csv, known-player-validation.csv e person-identity-structure.txt.");
        sb.AppendLine("O save não foi modificado.");
        return sb.ToString();
    }

    private static string FormatPeopleCsv(PersonIdentityParserReport report)
    {
        var sb = new StringBuilder("sequence_index,database_id,identity_name,record_type,structure_marker,record_offset,name_offset,name_length,confidence_score\r\n");
        foreach (PersonIdentity x in report.People)
            sb.AppendLine(string.Join(',', x.SequenceIndex, x.DatabaseId, Csv(x.IdentityName), x.RecordType, x.StructureMarker,
                $"0x{x.RecordOffset:X8}", $"0x{x.NameOffset:X8}", x.NameLength, x.ConfidenceScore));
        return sb.ToString();
    }

    private static string FormatValidationCsv(PersonIdentityParserReport report)
    {
        var sb = new StringBuilder("display_name,expected_database_id,found,parsed_identity_name,sequence_index,record_type,record_offset,name_offset,name_matches,status\r\n");
        foreach (PersonIdentityValidation x in report.Validations)
            sb.AppendLine(string.Join(',', Csv(x.DisplayName), x.ExpectedDatabaseId, x.Found, Csv(x.ParsedIdentityName),
                x.SequenceIndex?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                x.RecordType?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                x.RecordOffset.HasValue ? $"0x{x.RecordOffset.Value:X8}" : string.Empty,
                x.NameOffset.HasValue ? $"0x{x.NameOffset.Value:X8}" : string.Empty,
                x.NameMatches, x.Status));
        return sb.ToString();
    }

    private static string FormatStructure() =>
        "FM 2005 — estrutura validada de identidade de pessoa\r\n" +
        "==================================================\r\n" +
        "Int32  NameLength\r\n" +
        "char[] Name (UTF-16LE, NameLength caracteres)\r\n" +
        "UInt16 Terminator = 0\r\n" +
        "UInt16 RecordType\r\n" +
        "UInt32 StructureMarker = 189\r\n" +
        "UInt32 SequenceIndex\r\n" +
        "UInt32 DatabaseId\r\n\r\n" +
        "DatabaseIdOffset = NameOffset + NameLength * 2 + 12\r\n";

    private static bool Equivalent(string left, string right) => Normalize(left) == Normalize(right);

    private static string Normalize(string value)
    {
        string decomposed = value.Trim().Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder(decomposed.Length);
        foreach (char c in decomposed)
            if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark && char.IsLetterOrDigit(c))
                sb.Append(char.ToUpperInvariant(c));
        return sb.ToString();
    }

    private static string Format(uint? value) => value?.ToString(CultureInfo.InvariantCulture) ?? "-";
    private static string Format(ushort? value) => value?.ToString(CultureInfo.InvariantCulture) ?? "-";
    private static string Csv(string? value) => '"' + (value ?? string.Empty).Replace("\"", "\"\"") + '"';
}
