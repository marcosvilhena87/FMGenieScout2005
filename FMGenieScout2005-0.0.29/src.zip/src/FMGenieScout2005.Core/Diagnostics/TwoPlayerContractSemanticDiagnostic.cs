using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using FMGenieScout2005.Core.Models;

namespace FMGenieScout2005.Core.Diagnostics;

public sealed class TwoPlayerContractSemanticDiagnostic
{
    private const int WindowBefore = 256;
    private const int WindowAfter = 512;

    private static readonly TwoPlayerKnownContract Jean = new(
        "Jean", 315116, 1982, 2001, 2006, 675, 240, 65, 35, 3_000_000, 11_000_000, 15);

    private static readonly TwoPlayerKnownContract Athirson = new(
        "Athirson", 3_301_535, 1977, 2004, 2006, 5_000, 0, 0, 240, 2_600_000, 12_750_000, 0);

    public async Task<TwoPlayerContractSemanticReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source)) throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);
        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();

        progress?.Report("Localizando Jean e Athirson pelo PersonDatabaseId...");
        List<long> jeanAnchors = FindUInt32(data, Jean.PersonDatabaseId).Select(x => (long)x).ToList();
        List<long> athirsonAnchors = FindUInt32(data, Athirson.PersonDatabaseId).Select(x => (long)x).ToList();
        if (jeanAnchors.Count == 0) throw new InvalidOperationException("O PersonDatabaseId 315116 do Jean não foi encontrado.");
        if (athirsonAnchors.Count == 0) throw new InvalidOperationException("O PersonDatabaseId 3301535 do Athirson não foi encontrado.");

        long jeanAnchor = jeanAnchors[0];
        long athirsonAnchor = athirsonAnchors[0];

        progress?.Report("Comparando os mesmos offsets relativos...");
        List<TwoPlayerFieldComparison> comparisons = BuildComparisons(data, jeanAnchor, athirsonAnchor);

        progress?.Report("Procurando valores contratuais conhecidos...");
        List<TwoPlayerKnownValueHit> hits = [];
        AddKnownValueHits(data, jeanAnchor, Jean, hits);
        AddKnownValueHits(data, athirsonAnchor, Athirson, hits);

        progress?.Report("Avaliando candidatos semânticos compartilhados...");
        List<TwoPlayerSharedSemanticCandidate> shared = BuildSharedCandidates(data, jeanAnchor, athirsonAnchor);

        var report = new TwoPlayerContractSemanticReport(
            source, data.LongLength, sha, Jean, Athirson, jeanAnchors, athirsonAnchors,
            comparisons, hits, shared, output, DateTimeOffset.UtcNow);

        await File.WriteAllTextAsync(Path.Combine(output, "two-player-contract-semantic-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "jean-athirson-offset-matrix.csv"), FormatMatrixCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "jean-athirson-known-value-hits.csv"), FormatHitsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "jean-athirson-shared-semantic-candidates.csv"), FormatSharedCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "jean-athirson-record-contexts.txt"), FormatContexts(report, data), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "jean-athirson-known-contracts.csv"), FormatKnownContractsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);

        progress?.Report("Comparação Jean × Athirson concluída.");
        return report;
    }

    private static List<TwoPlayerFieldComparison> BuildComparisons(byte[] data, long jeanAnchor, long athirsonAnchor)
    {
        var result = new List<TwoPlayerFieldComparison>();
        for (int rel = -WindowBefore; rel < WindowAfter; rel++)
        {
            AddComparison(data, jeanAnchor, athirsonAnchor, rel, "BYTE", 1, result);
            if ((rel & 1) == 0) AddComparison(data, jeanAnchor, athirsonAnchor, rel, "UINT16", 2, result);
            if ((rel & 3) == 0)
            {
                AddComparison(data, jeanAnchor, athirsonAnchor, rel, "UINT32", 4, result);
                AddComparison(data, jeanAnchor, athirsonAnchor, rel, "INT32", 4, result);
                AddComparison(data, jeanAnchor, athirsonAnchor, rel, "FLOAT32", 4, result);
            }
        }
        return result;
    }

    private static void AddComparison(byte[] data, long jeanAnchor, long athirsonAnchor, int rel, string type, int width, List<TwoPlayerFieldComparison> output)
    {
        long j = jeanAnchor + rel;
        long a = athirsonAnchor + rel;
        if (!CanRead(data, j, width) || !CanRead(data, a, width)) return;

        string jHex = Convert.ToHexString(data.AsSpan((int)j, width));
        string aHex = Convert.ToHexString(data.AsSpan((int)a, width));
        string jValue = ReadAsString(data, (int)j, type);
        string aValue = ReadAsString(data, (int)a, type);
        bool equal = jHex == aHex;
        (string assessment, double score) = AssessPair(rel, type, jValue, aValue, equal);
        output.Add(new TwoPlayerFieldComparison(rel, j, a, type, jHex, aHex, jValue, aValue, equal, assessment, score));
    }

    private static (string Assessment, double Score) AssessPair(int rel, string type, string jeanValue, string athirsonValue, bool equal)
    {
        if (type is not ("BYTE" or "UINT16" or "UINT32" or "INT32")) return (string.Empty, 0);
        if (!long.TryParse(jeanValue, NumberStyles.Integer, CultureInfo.InvariantCulture, out long j)) return (string.Empty, 0);
        if (!long.TryParse(athirsonValue, NumberStyles.Integer, CultureInfo.InvariantCulture, out long a)) return (string.Empty, 0);

        if (j == Jean.PersonDatabaseId && a == Athirson.PersonDatabaseId) return ("PERSON_DATABASE_ID_PAIR", 100);
        if (j == Jean.BirthYear && a == Athirson.BirthYear) return ("BIRTH_YEAR_PAIR", 95);
        if (j == Jean.ContractStartYear && a == Athirson.ContractStartYear) return ("CONTRACT_START_YEAR_PAIR", 95);
        if (j == Jean.ContractEndYear && a == Athirson.ContractEndYear) return ("CONTRACT_END_YEAR_PAIR", 95);
        if (j == Jean.WeeklyWage && a == Athirson.WeeklyWage) return ("WEEKLY_WAGE_PAIR", 100);
        if (j == Jean.DisplayedValue && a == Athirson.DisplayedValue) return ("DISPLAYED_VALUE_PAIR", 90);
        if (j == Jean.ReleaseClause && a == Athirson.ReleaseClause) return ("RELEASE_CLAUSE_PAIR", 90);
        if (j == Jean.AssistBonus && a == Athirson.AssistBonus) return ("ASSIST_BONUS_PAIR", 90);
        if (equal && j == 2006) return ("SHARED_CONTRACT_END_YEAR", 85);
        if (equal && j == 240) return ("SHARED_BONUS_VALUE", 80);
        if (equal && j is > 0 and < 100_000) return ("SHARED_SMALL_FIELD", 15);
        if (!equal && j is > 1900 and < 2100 && a is > 1900 and < 2100) return ("YEAR_LIKE_PAIR", 25);
        if (!equal && j is > 0 and < 100_000 && a is > 0 and < 100_000) return ("VARIABLE_SMALL_FIELD", 5);
        return (string.Empty, 0);
    }

    private static void AddKnownValueHits(byte[] data, long anchor, TwoPlayerKnownContract contract, List<TwoPlayerKnownValueHit> output)
    {
        var targets = new List<(string Name, int Value)>
        {
            ("PersonDatabaseId", checked((int)contract.PersonDatabaseId)),
            ("BirthYear", contract.BirthYear),
            ("ContractStartYear", contract.ContractStartYear),
            ("ContractEndYear", contract.ContractEndYear),
            ("WeeklyWage", contract.WeeklyWage),
            ("DisplayedValue", contract.DisplayedValue),
            ("ReleaseClause", contract.ReleaseClause)
        };
        if (contract.AppearanceBonus > 0) targets.Add(("AppearanceBonus", contract.AppearanceBonus));
        if (contract.GoalBonus > 0) targets.Add(("GoalBonus", contract.GoalBonus));
        if (contract.AssistBonus > 0) targets.Add(("AssistBonus", contract.AssistBonus));
        if (contract.AnnualRisePercent > 0) targets.Add(("AnnualRisePercent", contract.AnnualRisePercent));

        foreach ((string name, int expected) in targets)
        {
            AddExactHits(data, anchor, contract.Player, name, expected, "BYTE", 1, output);
            AddExactHits(data, anchor, contract.Player, name, expected, "UINT16", 2, output);
            AddExactHits(data, anchor, contract.Player, name, expected, "UINT32", 4, output);
            AddExactHits(data, anchor, contract.Player, name, expected, "INT32", 4, output);
        }
    }

    private static void AddExactHits(byte[] data, long anchor, string player, string target, int expected, string type, int width, List<TwoPlayerKnownValueHit> output)
    {
        int start = Math.Max(0, checked((int)anchor) - WindowBefore);
        int end = Math.Min(data.Length - width, checked((int)anchor) + WindowAfter - width);
        for (int pos = start; pos <= end; pos++)
        {
            long actual = type switch
            {
                "BYTE" => data[pos],
                "UINT16" => BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(pos, 2)),
                "UINT32" => BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(pos, 4)),
                "INT32" => BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(pos, 4)),
                _ => long.MinValue
            };
            if (actual != expected) continue;
            string assessment = target is "PersonDatabaseId" ? "ANCHOR" : type == "UINT32" ? "EXACT_ALIGNED_OR_UNALIGNED" : "EXACT_COMPACT";
            output.Add(new TwoPlayerKnownValueHit(player, target, type, expected, pos - checked((int)anchor), pos, Convert.ToHexString(data.AsSpan(pos, width)), actual, assessment));
        }
    }

    private static List<TwoPlayerSharedSemanticCandidate> BuildSharedCandidates(byte[] data, long jeanAnchor, long athirsonAnchor)
    {
        var targets = new (string Name, int JeanValue, int AthirsonValue)[]
        {
            ("BirthYear", Jean.BirthYear, Athirson.BirthYear),
            ("ContractStartYear", Jean.ContractStartYear, Athirson.ContractStartYear),
            ("ContractEndYear", Jean.ContractEndYear, Athirson.ContractEndYear),
            ("WeeklyWage", Jean.WeeklyWage, Athirson.WeeklyWage),
            ("AssistBonus", Jean.AssistBonus, Athirson.AssistBonus),
            ("DisplayedValue", Jean.DisplayedValue, Athirson.DisplayedValue),
            ("ReleaseClause", Jean.ReleaseClause, Athirson.ReleaseClause)
        };

        var result = new List<TwoPlayerSharedSemanticCandidate>();
        foreach (var target in targets)
        {
            foreach (string type in new[] { "BYTE", "UINT16", "UINT32", "INT32" })
            {
                int width = type == "BYTE" ? 1 : type == "UINT16" ? 2 : 4;
                for (int rel = -WindowBefore; rel < WindowAfter; rel++)
                {
                    long jPos = jeanAnchor + rel;
                    long aPos = athirsonAnchor + rel;
                    if (!CanRead(data, jPos, width) || !CanRead(data, aPos, width)) continue;
                    long j = ReadInteger(data, (int)jPos, type);
                    long a = ReadInteger(data, (int)aPos, type);
                    bool jm = j == target.JeanValue;
                    bool am = a == target.AthirsonValue;
                    if (!jm && !am) continue;
                    double score = jm && am ? 100 : 35;
                    string assessment = jm && am ? "SEMANTIC_PAIR_CONFIRMED" : jm ? "JEAN_ONLY" : "ATHIRSON_ONLY";
                    result.Add(new TwoPlayerSharedSemanticCandidate(target.Name, type, rel, target.JeanValue, j, target.AthirsonValue, a, jm, am, assessment, score));
                }
            }
        }
        return result.OrderByDescending(x => x.Score).ThenBy(x => Math.Abs(x.RelativeOffset)).ToList();
    }

    private static bool CanRead(byte[] data, long offset, int width) => offset >= 0 && offset + width <= data.LongLength;

    private static long ReadInteger(byte[] data, int pos, string type) => type switch
    {
        "BYTE" => data[pos],
        "UINT16" => BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(pos, 2)),
        "UINT32" => BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(pos, 4)),
        "INT32" => BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(pos, 4)),
        _ => long.MinValue
    };

    private static string ReadAsString(byte[] data, int pos, string type) => type switch
    {
        "BYTE" => data[pos].ToString(CultureInfo.InvariantCulture),
        "UINT16" => BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(pos, 2)).ToString(CultureInfo.InvariantCulture),
        "UINT32" => BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(pos, 4)).ToString(CultureInfo.InvariantCulture),
        "INT32" => BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(pos, 4)).ToString(CultureInfo.InvariantCulture),
        "FLOAT32" => BitConverter.Int32BitsToSingle(BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(pos, 4))).ToString("R", CultureInfo.InvariantCulture),
        _ => string.Empty
    };

    private static IEnumerable<int> FindUInt32(byte[] data, uint value)
    {
        byte b0 = (byte)value; byte b1 = (byte)(value >> 8); byte b2 = (byte)(value >> 16); byte b3 = (byte)(value >> 24);
        for (int i = 0; i <= data.Length - 4; i++)
            if (data[i] == b0 && data[i + 1] == b1 && data[i + 2] == b2 && data[i + 3] == b3)
                yield return i;
    }

    public static string FormatReport(TwoPlayerContractSemanticReport report)
    {
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — TwoPlayerContractSemanticDiagnostic 0.0.28.1");
        sb.AppendLine(new string('=', 94));
        sb.AppendLine($"Arquivo: {report.SourceFile}");
        sb.AppendLine($"Tamanho: {report.SourceSize:N0} bytes");
        sb.AppendLine($"SHA-256: {report.Sha256}");
        sb.AppendLine($"Jean DBID {report.Jean.PersonDatabaseId}: {report.JeanAnchors.Count} ocorrência(s)");
        sb.AppendLine($"Athirson DBID {report.Athirson.PersonDatabaseId}: {report.AthirsonAnchors.Count} ocorrência(s)");
        sb.AppendLine($"Comparações de campo: {report.FieldComparisons.Count:N0}");
        sb.AppendLine($"Hits de valores conhecidos: {report.KnownValueHits.Count:N0}");
        sb.AppendLine($"Candidatos semânticos compartilhados: {report.SharedCandidates.Count:N0}");
        sb.AppendLine();
        sb.AppendLine("Candidatos confirmados nos dois jogadores:");
        foreach (TwoPlayerSharedSemanticCandidate x in report.SharedCandidates.Where(x => x.Assessment == "SEMANTIC_PAIR_CONFIRMED").Take(80))
            sb.AppendLine($"  {x.Target,-22} {x.DataType,-6} rel={x.RelativeOffset,5} | Jean={x.JeanActual} | Athirson={x.AthirsonActual} | {x.Assessment}");
        sb.AppendLine();
        sb.AppendLine("Comparações de maior pontuação:");
        foreach (TwoPlayerFieldComparison x in report.FieldComparisons.Where(x => x.Score > 0).OrderByDescending(x => x.Score).ThenBy(x => Math.Abs(x.RelativeOffset)).Take(80))
            sb.AppendLine($"  rel={x.RelativeOffset,5} {x.DataType,-7} Jean={x.JeanValue,-12} Athirson={x.AthirsonValue,-12} {x.SemanticAssessment}");
        sb.AppendLine();
        sb.AppendLine("Arquivos gerados: two-player-contract-semantic-report.txt, jean-athirson-offset-matrix.csv, jean-athirson-known-value-hits.csv, jean-athirson-shared-semantic-candidates.csv, jean-athirson-record-contexts.txt e jean-athirson-known-contracts.csv.");
        sb.AppendLine("O arquivo de origem não foi modificado.");
        return sb.ToString();
    }

    private static string FormatMatrixCsv(TwoPlayerContractSemanticReport report)
    {
        var sb = new StringBuilder("relative_offset,data_type,jean_absolute_offset,athirson_absolute_offset,jean_raw_hex,athirson_raw_hex,jean_value,athirson_value,equal,semantic_assessment,score\r\n");
        foreach (TwoPlayerFieldComparison x in report.FieldComparisons)
            sb.AppendLine(string.Join(',', x.RelativeOffset, x.DataType, $"0x{x.JeanAbsoluteOffset:X8}", $"0x{x.AthirsonAbsoluteOffset:X8}", x.JeanRawHex, x.AthirsonRawHex, Csv(x.JeanValue), Csv(x.AthirsonValue), x.Equal, Csv(x.SemanticAssessment), x.Score.ToString("F2", CultureInfo.InvariantCulture)));
        return sb.ToString();
    }

    private static string FormatHitsCsv(TwoPlayerContractSemanticReport report)
    {
        var sb = new StringBuilder("player,target,data_type,expected_value,relative_offset,absolute_offset,raw_hex,actual_value,assessment\r\n");
        foreach (TwoPlayerKnownValueHit x in report.KnownValueHits.OrderBy(x => x.Player).ThenBy(x => x.Target).ThenBy(x => Math.Abs(x.RelativeOffset)))
            sb.AppendLine(string.Join(',', Csv(x.Player), Csv(x.Target), x.DataType, x.ExpectedValue, x.RelativeOffset, $"0x{x.AbsoluteOffset:X8}", x.RawHex, x.ActualValue, Csv(x.Assessment)));
        return sb.ToString();
    }

    private static string FormatSharedCsv(TwoPlayerContractSemanticReport report)
    {
        var sb = new StringBuilder("target,data_type,relative_offset,jean_expected,jean_actual,athirson_expected,athirson_actual,jean_match,athirson_match,assessment,score\r\n");
        foreach (TwoPlayerSharedSemanticCandidate x in report.SharedCandidates)
            sb.AppendLine(string.Join(',', Csv(x.Target), x.DataType, x.RelativeOffset, x.JeanExpected, x.JeanActual, x.AthirsonExpected, x.AthirsonActual, x.JeanMatch, x.AthirsonMatch, Csv(x.Assessment), x.Score.ToString("F2", CultureInfo.InvariantCulture)));
        return sb.ToString();
    }

    private static string FormatKnownContractsCsv(TwoPlayerContractSemanticReport report)
    {
        var sb = new StringBuilder("player,person_database_id,birth_year,contract_start_year,contract_end_year,weekly_wage,appearance_bonus,goal_bonus,assist_bonus,displayed_value,release_clause,annual_rise_percent\r\n");
        foreach (TwoPlayerKnownContract x in new[] { report.Jean, report.Athirson })
            sb.AppendLine(string.Join(',', Csv(x.Player), x.PersonDatabaseId, x.BirthYear, x.ContractStartYear, x.ContractEndYear, x.WeeklyWage, x.AppearanceBonus, x.GoalBonus, x.AssistBonus, x.DisplayedValue, x.ReleaseClause, x.AnnualRisePercent));
        return sb.ToString();
    }

    private static string FormatContexts(TwoPlayerContractSemanticReport report, byte[] data)
    {
        var sb = new StringBuilder();
        AppendContext(sb, data, "Jean", report.Jean.PersonDatabaseId, report.JeanAnchors[0]);
        AppendContext(sb, data, "Athirson", report.Athirson.PersonDatabaseId, report.AthirsonAnchors[0]);
        return sb.ToString();
    }

    private static void AppendContext(StringBuilder sb, byte[] data, string player, uint id, long anchor)
    {
        int start = Math.Max(0, checked((int)anchor) - WindowBefore);
        int length = Math.Min(WindowBefore + WindowAfter, data.Length - start);
        sb.AppendLine($"[{player} DBID {id} @ 0x{anchor:X8}] janela −{WindowBefore}/+{WindowAfter}");
        for (int offset = 0; offset < length; offset += 16)
        {
            int count = Math.Min(16, length - offset);
            long absolute = start + offset;
            int relative = checked((int)(absolute - anchor));
            sb.Append($"{relative,6:+0;-0;0} 0x{absolute:X8}  ");
            sb.AppendLine(Convert.ToHexString(data.AsSpan(start + offset, count)));
        }
        sb.AppendLine();
    }

    private static string Csv(string? value)
    {
        string text = value ?? string.Empty;
        return '"' + text.Replace("\"", "\"\"") + '"';
    }
}
