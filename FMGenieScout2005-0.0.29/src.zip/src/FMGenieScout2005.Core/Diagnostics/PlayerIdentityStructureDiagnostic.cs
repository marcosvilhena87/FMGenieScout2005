using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using FMGenieScout2005.Core.Models;

namespace FMGenieScout2005.Core.Diagnostics;

public sealed class PlayerIdentityStructureDiagnostic
{
    private const int SearchBefore = 512;
    private const int SearchAfter = 1024;
    private const int LayoutBefore = 128;
    private const int LayoutAfter = 256;

    private static readonly KnownPlayerIdentity[] Players =
    [
        new("Andrezinho", 302728),
        new("André Bahia", 311169),
        new("Bruno Santos", 8832815),
        new("Dimba", 303048),
        new("Douglas Silva", 3300410),
        new("Fabiano Eller", 3300219),
        new("Júlio César Moraes", 8825041),
        new("Júnior Baiano", 6900111),
        new("Reginaldo Araújo", 3300780)
    ];

    public async Task<PlayerIdentityStructureReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source)) throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);
        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();

        progress?.Report("Localizando nomes conhecidos em UTF-16LE...");
        List<PlayerIdentityNameHit> nameHits = [];
        foreach (KnownPlayerIdentity player in Players)
        {
            byte[] pattern = Encoding.Unicode.GetBytes(player.Name);
            int occurrence = 0;
            foreach (int offset in FindAll(data, pattern))
            {
                occurrence++;
                nameHits.Add(new(player.Name, player.DatabaseId, offset, pattern.Length, occurrence));
            }
        }

        progress?.Report("Procurando os IDs conhecidos ao redor dos nomes...");
        List<PlayerIdentityIdHit> idHits = [];
        foreach (PlayerIdentityNameHit name in nameHits)
        {
            int start = Math.Max(0, checked((int)name.NameOffset) - SearchBefore);
            int end = Math.Min(data.Length - 2, checked((int)name.NameOffset) + name.EncodedByteLength + SearchAfter);
            for (int p = start; p <= end; p++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (p <= data.Length - 4 && BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(p, 4)) == name.ExpectedDatabaseId)
                    idHits.Add(CreateIdHit(data, name, p, 4, "UINT32"));
                if (name.ExpectedDatabaseId <= ushort.MaxValue && p <= data.Length - 2 && BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(p, 2)) == (ushort)name.ExpectedDatabaseId)
                    idHits.Add(CreateIdHit(data, name, p, 2, "UINT16"));
            }
        }

        List<PlayerIdentityOffsetSummary> idSummaries = idHits
            .GroupBy(x => new { x.DataType, x.RelativeToNameStart })
            .Select(g =>
            {
                string[] players = g.Select(x => x.PlayerName).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToArray();
                double coverage = players.Length / (double)Players.Length;
                string assessment = players.Length >= 7 ? "CANDIDATO_FORTE" : players.Length >= 4 ? "CANDIDATO_MEDIO" : players.Length >= 2 ? "CANDIDATO_FRACO" : "ISOLADO";
                return new PlayerIdentityOffsetSummary(g.Key.DataType, g.Key.RelativeToNameStart, players.Length, g.Count(), coverage, string.Join(" | ", players), assessment);
            })
            .OrderByDescending(x => x.PlayerCount)
            .ThenByDescending(x => x.HitCount)
            .ThenBy(x => Math.Abs(x.RelativeToNameStart))
            .ToList();

        progress?.Report("Comparando campos estruturais em offsets relativos...");
        List<PlayerIdentityFieldSample> samples = [];
        foreach (PlayerIdentityNameHit hit in nameHits.Where(x => nameHits.Count(y => y.PlayerName == x.PlayerName) == 1))
        {
            int nameOffset = checked((int)hit.NameOffset);
            for (int rel = -LayoutBefore; rel <= LayoutAfter; rel++)
            {
                int p = nameOffset + rel;
                if (p < 0) continue;
                if (p <= data.Length - 4 && (rel & 3) == 0)
                {
                    uint value = BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(p, 4));
                    samples.Add(new(hit.PlayerName, hit.ExpectedDatabaseId, hit.NameOffset, rel, "UINT32", value, value == hit.ExpectedDatabaseId));
                }
                if (p <= data.Length - 2 && (rel & 1) == 0)
                {
                    ushort value = BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(p, 2));
                    samples.Add(new(hit.PlayerName, hit.ExpectedDatabaseId, hit.NameOffset, rel, "UINT16", value, value == hit.ExpectedDatabaseId));
                }
                if (p < data.Length)
                {
                    byte value = data[p];
                    samples.Add(new(hit.PlayerName, hit.ExpectedDatabaseId, hit.NameOffset, rel, "BYTE", value, value == hit.ExpectedDatabaseId));
                }
            }
        }

        int uniquePlayerCount = nameHits.GroupBy(x => x.PlayerName).Count(g => g.Count() == 1);
        List<PlayerIdentityFieldSummary> fieldSummaries = samples
            .GroupBy(x => new { x.RelativeOffset, x.DataType })
            .Select(g =>
            {
                int playerCount = g.Select(x => x.PlayerName).Distinct().Count();
                int matches = g.Count(x => x.EqualsExpectedId);
                double rate = playerCount == 0 ? 0 : matches / (double)playerCount;
                ulong[] values = g.Select(x => x.Value).Distinct().OrderBy(x => x).Take(16).ToArray();
                string assessment = matches >= Math.Max(2, uniquePlayerCount - 1) ? "ID_PROVAVEL" :
                    playerCount == uniquePlayerCount && g.Select(x => x.Value).Distinct().Count() == playerCount ? "CAMPO_VARIAVEL" :
                    playerCount == uniquePlayerCount && g.Select(x => x.Value).Distinct().Count() <= 3 ? "CAMPO_CONSTANTE" : "SEM_PADRAO";
                return new PlayerIdentityFieldSummary(g.Key.RelativeOffset, g.Key.DataType, playerCount, g.Select(x => x.Value).Distinct().Count(), matches, rate, string.Join(" | ", values), assessment);
            })
            .Where(x => x.PlayerCount >= Math.Max(2, uniquePlayerCount - 1))
            .OrderByDescending(x => x.ExpectedIdMatchCount)
            .ThenByDescending(x => x.PlayerCount)
            .ThenBy(x => Math.Abs(x.RelativeOffset))
            .ToList();

        var report = new PlayerIdentityStructureReport(source, data.LongLength, sha, Players, nameHits, idHits, idSummaries, samples, fieldSummaries, output, DateTimeOffset.UtcNow);
        progress?.Report("Gravando relatórios da identidade estrutural...");
        await File.WriteAllTextAsync(Path.Combine(output, "player-identity-layout-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken);
        await File.WriteAllTextAsync(Path.Combine(output, "player-identity-name-hits.csv"), FormatNameHits(report), new UTF8Encoding(true), cancellationToken);
        await File.WriteAllTextAsync(Path.Combine(output, "player-identity-id-hits.csv"), FormatIdHits(report), new UTF8Encoding(true), cancellationToken);
        await File.WriteAllTextAsync(Path.Combine(output, "player-identity-offset-summaries.csv"), FormatIdSummaries(report), new UTF8Encoding(true), cancellationToken);
        await File.WriteAllTextAsync(Path.Combine(output, "player-identity-field-candidates.csv"), FormatFieldSummaries(report), new UTF8Encoding(true), cancellationToken);
        await File.WriteAllTextAsync(Path.Combine(output, "player-name-structure-contexts.txt"), FormatContexts(report, data), new UTF8Encoding(true), cancellationToken);
        progress?.Report("Diagnóstico 0.0.21 concluído.");
        return report;
    }

    private static PlayerIdentityIdHit CreateIdHit(byte[] data, PlayerIdentityNameHit name, int idOffset, int width, string type)
    {
        long relStart = idOffset - name.NameOffset;
        long relEnd = idOffset - (name.NameOffset + name.EncodedByteLength);
        int start = Math.Max(0, idOffset - 32);
        int len = Math.Min(68, data.Length - start);
        return new(name.PlayerName, name.ExpectedDatabaseId, name.NameOffset, idOffset, relStart, relEnd, width, type, Convert.ToHexString(data.AsSpan(start, len)));
    }

    private static IEnumerable<int> FindAll(byte[] data, byte[] pattern)
    {
        for (int i = 0; i <= data.Length - pattern.Length; i++)
            if (data.AsSpan(i, pattern.Length).SequenceEqual(pattern)) yield return i;
    }

    public static string FormatReport(PlayerIdentityStructureReport r)
    {
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — PlayerIdentityStructureDiagnostic 0.0.21");
        sb.AppendLine(new string('=', 94));
        sb.AppendLine($"Arquivo: {r.SourceFile}");
        sb.AppendLine($"Tamanho: {r.SourceSize:N0} bytes");
        sb.AppendLine($"SHA-256: {r.Sha256}");
        sb.AppendLine($"Jogadores conhecidos: {r.ExpectedPlayers.Count}");
        sb.AppendLine($"Nomes encontrados: {r.NameHits.Select(x => x.PlayerName).Distinct().Count()}/{r.ExpectedPlayers.Count}");
        sb.AppendLine($"Ocorrências de nomes: {r.NameHits.Count:N0}");
        sb.AppendLine($"Hits dos IDs conhecidos: {r.IdHits.Count:N0}");
        sb.AppendLine();
        sb.AppendLine("Ocorrências por jogador:");
        foreach (KnownPlayerIdentity p in r.ExpectedPlayers)
            sb.AppendLine($"  {p.Name,-24} id={p.DatabaseId,8} ocorrências={r.NameHits.Count(x => x.PlayerName == p.Name),3} hits-id={r.IdHits.Count(x => x.PlayerName == p.Name),3}");
        sb.AppendLine();
        sb.AppendLine("Melhores offsets do ID em relação ao início do nome:");
        foreach (PlayerIdentityOffsetSummary x in r.IdOffsetSummaries.Take(30))
            sb.AppendLine($"  {x.DataType,-6} rel={x.RelativeToNameStart,6:+0;-0;0} jogadores={x.PlayerCount}/{r.ExpectedPlayers.Count} hits={x.HitCount,3} cobertura={x.Coverage:P1} {x.Assessment} | {x.Players}");
        sb.AppendLine();
        sb.AppendLine("Melhores campos estruturais:");
        foreach (PlayerIdentityFieldSummary x in r.FieldSummaries.Where(x => x.Assessment != "SEM_PADRAO").Take(50))
            sb.AppendLine($"  {x.DataType,-6} rel={x.RelativeOffset,5:+0;-0;0} jogadores={x.PlayerCount} distintos={x.DistinctValueCount} matches-id={x.ExpectedIdMatchCount} taxa={x.ExpectedIdMatchRate:P1} {x.Assessment} | {x.Values}");
        sb.AppendLine();
        sb.AppendLine("Arquivos gerados: player-identity-layout-report.txt, player-identity-name-hits.csv, player-identity-id-hits.csv, player-identity-offset-summaries.csv, player-identity-field-candidates.csv e player-name-structure-contexts.txt.");
        sb.AppendLine("O save não foi modificado.");
        return sb.ToString();
    }

    private static string FormatNameHits(PlayerIdentityStructureReport r)
    {
        var sb = new StringBuilder("player,expected_database_id,name_offset,encoded_bytes,occurrence\r\n");
        foreach (var x in r.NameHits) sb.AppendLine($"{Csv(x.PlayerName)},{x.ExpectedDatabaseId},0x{x.NameOffset:X8},{x.EncodedByteLength},{x.OccurrenceNumber}");
        return sb.ToString();
    }
    private static string FormatIdHits(PlayerIdentityStructureReport r)
    {
        var sb = new StringBuilder("player,expected_database_id,name_offset,id_offset,relative_to_name_start,relative_to_name_end,width,data_type,context_hex\r\n");
        foreach (var x in r.IdHits) sb.AppendLine($"{Csv(x.PlayerName)},{x.ExpectedDatabaseId},0x{x.NameOffset:X8},0x{x.IdOffset:X8},{x.RelativeToNameStart},{x.RelativeToNameEnd},{x.Width},{x.DataType},{x.ContextHex}");
        return sb.ToString();
    }
    private static string FormatIdSummaries(PlayerIdentityStructureReport r)
    {
        var sb = new StringBuilder("data_type,relative_to_name_start,player_count,hit_count,coverage,assessment,players\r\n");
        foreach (var x in r.IdOffsetSummaries) sb.AppendLine($"{x.DataType},{x.RelativeToNameStart},{x.PlayerCount},{x.HitCount},{x.Coverage.ToString("F6", CultureInfo.InvariantCulture)},{x.Assessment},{Csv(x.Players)}");
        return sb.ToString();
    }
    private static string FormatFieldSummaries(PlayerIdentityStructureReport r)
    {
        var sb = new StringBuilder("relative_offset,data_type,player_count,distinct_value_count,expected_id_match_count,expected_id_match_rate,assessment,values\r\n");
        foreach (var x in r.FieldSummaries) sb.AppendLine($"{x.RelativeOffset},{x.DataType},{x.PlayerCount},{x.DistinctValueCount},{x.ExpectedIdMatchCount},{x.ExpectedIdMatchRate.ToString("F6", CultureInfo.InvariantCulture)},{x.Assessment},{Csv(x.Values)}");
        return sb.ToString();
    }
    private static string FormatContexts(PlayerIdentityStructureReport r, byte[] data)
    {
        var sb = new StringBuilder();
        foreach (var x in r.NameHits)
        {
            int p = checked((int)x.NameOffset); int start = Math.Max(0, p - LayoutBefore); int len = Math.Min(LayoutBefore + x.EncodedByteLength + LayoutAfter, data.Length - start);
            sb.AppendLine($"[{x.PlayerName}] id={x.ExpectedDatabaseId} ocorrência={x.OccurrenceNumber} nome=0x{x.NameOffset:X8}");
            sb.AppendLine(Convert.ToHexString(data.AsSpan(start, len))); sb.AppendLine();
        }
        return sb.ToString();
    }
    private static string Csv(string value) => '"' + value.Replace("\"", "\"\"") + '"';
}
