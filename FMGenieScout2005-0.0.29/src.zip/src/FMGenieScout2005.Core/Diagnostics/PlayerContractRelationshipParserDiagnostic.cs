using System.Globalization;
using System.Text;
using FMGenieScout2005.Core.Domain;
using FMGenieScout2005.Core.Models;
using FMGenieScout2005.Core.Parsing;

namespace FMGenieScout2005.Core.Diagnostics;

public sealed class PlayerContractRelationshipParserDiagnostic
{
    private static readonly KnownRelationshipValidation[] KnownValidations =
    [
        new("Reginaldo Araújo", 3300780, 104776, "Coritiba", 322, "CR Flamengo", true),
        new("Anderson", 3301240, 322, "CR Flamengo", 301266, "Caxias", true),
        new("Édson Araújo", 308345, 319, "SC Corinthians Paulista", 104750, "Fortaleza", true),
        new("Luciano Ratinho", 6900008, 319, "SC Corinthians Paulista", 324, "Grêmio", true),
        new("Marcelo Magalhães", 302580, 319, "SC Corinthians Paulista", 324, "Grêmio", true),
        new("Jean", 315116, 322, "CR Flamengo", 322, "CR Flamengo", false),
        new("Athirson", 3301535, 322, "CR Flamengo", 322, "CR Flamengo", false)
    ];

    public async Task<PlayerContractRelationshipParserReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        var parser = new Fm2005PlayerContractRelationshipParser();
        Fm2005PlayerContractRelationshipParseResult parsed = await parser
            .ParseFileAsync(inputFile, progress, cancellationToken)
            .ConfigureAwait(false);

        RelationshipValidationResult[] validation = KnownValidations.Select(expected =>
        {
            PlayerContractRelationship? actual = parsed.FindByPersonDatabaseId(expected.PersonDatabaseId);
            bool found = actual is not null;
            bool ownerMatches = actual?.OwnerClubDatabaseId == expected.ExpectedOwnerClubDatabaseId;
            bool activeMatches = actual?.ActiveClubDatabaseId == expected.ExpectedActiveClubDatabaseId;
            bool loanMatches = actual?.IsOnLoan == expected.ExpectedLoan;
            string assessment = found && ownerMatches && activeMatches && loanMatches
                ? "VALIDATED"
                : !found ? "NOT_FOUND"
                : "REVIEW";
            return new RelationshipValidationResult(
                expected.Player, expected.PersonDatabaseId, found,
                actual?.OwnerClubName, actual?.ActiveClubName, actual?.IsOnLoan,
                ownerMatches, activeMatches, loanMatches, assessment);
        }).ToArray();

        var report = new PlayerContractRelationshipParserReport(
            parsed.SourceFile, parsed.SourceSize, parsed.Sha256,
            parsed.Relationships, parsed.Contracts, KnownValidations, validation,
            parsed.PersonAnchorsExamined, parsed.ContractCandidatesRejected,
            output, DateTimeOffset.UtcNow);

        progress?.Report("Gravando relacionamentos contratuais...");
        await File.WriteAllTextAsync(Path.Combine(output, "player-contract-relationship-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "player-contract-relationships.csv"), FormatRelationshipsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "player-professional-contracts.csv"), FormatContractsCsv(report.Relationships.Select(x => x.ProfessionalContract)), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "player-loan-contracts.csv"), FormatContractsCsv(report.Relationships.Where(x => x.LoanContract is not null).Select(x => x.LoanContract!)), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "player-loan-validation.csv"), FormatValidationCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "player-contract-relationship-contexts.txt"), FormatContexts(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        progress?.Report("PlayerContractRelationshipParser concluído.");
        return report;
    }

    public static string FormatReportForUi(PlayerContractRelationshipParserReport report) => FormatReport(report);

    public static string FormatReport(PlayerContractRelationshipParserReport report)
    {
        int loans = report.Relationships.Count(x => x.IsOnLoan);
        int validated = report.ValidationResults.Count(x => x.Assessment == "VALIDATED");
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — PlayerContractRelationshipParser 0.0.28.9");
        sb.AppendLine(new string('=', 96));
        sb.AppendLine($"Arquivo: {report.SourceFile}");
        sb.AppendLine($"Tamanho: {report.SourceSize:N0} bytes");
        sb.AppendLine($"SHA-256: {report.Sha256}");
        sb.AppendLine($"Relacionamentos consolidados: {report.Relationships.Count:N0}");
        sb.AppendLine($"Contratos individuais: {report.Contracts.Count:N0}");
        sb.AppendLine($"Jogadores emprestados: {loans:N0}");
        sb.AppendLine($"Validação conhecida: {validated}/{report.ValidationResults.Count}");
        sb.AppendLine($"Âncoras examinadas: {report.PersonAnchorsExamined:N0}");
        sb.AppendLine($"Candidatos rejeitados: {report.ContractCandidatesRejected:N0}");
        sb.AppendLine();
        sb.AppendLine("Casos conhecidos:");
        foreach (RelationshipValidationResult row in report.ValidationResults)
            sb.AppendLine($"  {row.Player,-22} owner={row.OwnerClub ?? "-",-28} active={row.ActiveClub ?? "-",-28} loan={row.IsOnLoan?.ToString() ?? "-",-5} {row.Assessment}");
        sb.AppendLine();
        sb.AppendLine("Arquivos gerados: player-contract-relationships.csv, player-professional-contracts.csv, player-loan-contracts.csv, player-loan-validation.csv e player-contract-relationship-contexts.txt.");
        sb.AppendLine("O arquivo de save não foi modificado.");
        return sb.ToString();
    }

    private static string FormatRelationshipsCsv(PlayerContractRelationshipParserReport report)
    {
        var sb = new StringBuilder("person_database_id,display_name,is_on_loan,owner_club_save_index,owner_club_database_id,owner_club,active_club_save_index,active_club_database_id,active_club,professional_record_start,loan_record_start,professional_start_year,professional_end_date,loan_end_date,professional_wage,loan_wage,contracts_count,score,confidence\r\n");
        foreach (PlayerContractRelationship x in report.Relationships)
        {
            sb.AppendLine(string.Join(',',
                x.PersonDatabaseId,
                Csv(x.DisplayName),
                x.IsOnLoan,
                x.OwnerClubSaveIndex,
                x.OwnerClubDatabaseId?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                Csv(x.OwnerClubName),
                x.ActiveClubSaveIndex,
                x.ActiveClubDatabaseId?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                Csv(x.ActiveClubName),
                $"0x{x.ProfessionalContract.RecordStartOffset:X8}",
                x.LoanContract is null ? string.Empty : $"0x{x.LoanContract.RecordStartOffset:X8}",
                x.ProfessionalContract.ContractStartYear,
                x.ProfessionalContract.ContractEndDate?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) ?? string.Empty,
                x.LoanContract?.ContractEndDate?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) ?? string.Empty,
                x.ProfessionalContract.InternalWeeklyWage,
                x.LoanContract?.InternalWeeklyWage.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                x.AllContracts.Count,
                x.ConfidenceScore,
                x.Confidence));
        }
        return sb.ToString();
    }

    private static string FormatContractsCsv(IEnumerable<PlayerContractHeader> contracts)
    {
        IEnumerable<PlayerContractHeader> rows = contracts;
        var sb = new StringBuilder("person_database_id,display_name,internal_key,club_save_index,club_database_id,club,wage,start_year,end_date,subtype,record_start,dbid_offset,record_length,score,confidence\r\n");
        foreach (PlayerContractHeader x in rows.OrderBy(x => x.PersonDatabaseId).ThenBy(x => x.RecordStartOffset))
        {
            sb.AppendLine(string.Join(',', x.PersonDatabaseId, Csv(x.DisplayName), x.InternalPlayerKey,
                x.CurrentClubSaveIndex, x.CurrentClubDatabaseId?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                Csv(x.CurrentClubName), x.InternalWeeklyWage, x.ContractStartYear,
                x.ContractEndDate?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) ?? string.Empty,
                x.PlayerRecordSubtype, $"0x{x.RecordStartOffset:X8}", $"0x{x.PersonDatabaseIdOffset:X8}",
                x.RecordLength, x.ConfidenceScore, x.Confidence));
        }
        return sb.ToString();
    }

    private static string FormatValidationCsv(PlayerContractRelationshipParserReport report)
    {
        var sb = new StringBuilder("player,person_database_id,found,owner_club,active_club,is_on_loan,owner_matches,active_matches,loan_matches,assessment\r\n");
        foreach (RelationshipValidationResult x in report.ValidationResults)
            sb.AppendLine(string.Join(',', Csv(x.Player), x.PersonDatabaseId, x.Found, Csv(x.OwnerClub), Csv(x.ActiveClub), x.IsOnLoan?.ToString() ?? string.Empty, x.OwnerMatches, x.ActiveMatches, x.LoanMatches, x.Assessment));
        return sb.ToString();
    }

    private static string FormatContexts(PlayerContractRelationshipParserReport report)
    {
        var sb = new StringBuilder();
        foreach (PlayerContractRelationship x in report.Relationships.Where(x => x.IsOnLoan).Take(200))
        {
            sb.AppendLine($"[{x.DisplayName}] DBID={x.PersonDatabaseId}");
            sb.AppendLine($"  PROFESSIONAL: {x.OwnerClubName} | start=0x{x.ProfessionalContract.RecordStartOffset:X8} | wage={x.ProfessionalContract.InternalWeeklyWage} | end={x.ProfessionalContract.ContractEndDate:yyyy-MM-dd}");
            if (x.LoanContract is not null)
                sb.AppendLine($"  LOAN:         {x.ActiveClubName} | start=0x{x.LoanContract.RecordStartOffset:X8} | wage={x.LoanContract.InternalWeeklyWage} | end={x.LoanContract.ContractEndDate:yyyy-MM-dd}");
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string Csv(string? value)
    {
        string text = value ?? string.Empty;
        return '"' + text.Replace("\"", "\"\"") + '"';
    }
}
