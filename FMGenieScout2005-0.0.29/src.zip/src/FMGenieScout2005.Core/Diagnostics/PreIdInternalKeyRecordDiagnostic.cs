using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using FMGenieScout2005.Core.Models;

namespace FMGenieScout2005.Core.Diagnostics;

public sealed class PreIdInternalKeyRecordDiagnostic
{
    private const int SearchBefore = 256;
    private const int ContextBeforeKey = 32;
    private const int ContextAfterDbid = 16;

    public async Task<PreIdInternalKeyRecordReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source)) throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);
        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();

        progress?.Report("Reutilizando as âncoras estruturais da 0.0.28.4...");
        var postId = new PostIdPlayerRecordFieldDiagnostic();
        PostIdPlayerRecordFieldReport sourceReport = await postId.AnalyzeAsync(
            source,
            Path.Combine(output, "post-id-source"),
            progress,
            cancellationToken).ConfigureAwait(false);

        progress?.Report("Localizando a ocorrência anterior mais próxima da InternalKey...");
        var anchors = new List<PreIdInternalKeyAnchor>();
        foreach (PostIdPlayerAnchor sourceAnchor in sourceReport.Anchors)
        {
            cancellationToken.ThrowIfCancellationRequested();
            int dbidOffset = checked((int)sourceAnchor.AnchorOffset);
            int start = Math.Max(0, dbidOffset - SearchBefore);
            int endExclusive = dbidOffset - 8;
            List<int> candidates = FindUInt32(data, sourceAnchor.InternalKey, start, endExclusive)
                .Where(x => x != dbidOffset - 4)
                .ToList();

            int previous = candidates.Count == 0 ? -1 : candidates.Max();
            if (previous < 0) continue;
            int distance = dbidOffset - previous;
            int segmentLength = distance + 4;
            string assessment = distance is >= 40 and <= 160
                ? "PRE_ID_SEGMENT_STRONG"
                : distance <= SearchBefore ? "PRE_ID_SEGMENT_MEDIUM" : "PRE_ID_SEGMENT_WEAK";

            anchors.Add(new PreIdInternalKeyAnchor(
                sourceAnchor.Player,
                sourceAnchor.DatabaseId,
                sourceAnchor.RecordSubtype,
                sourceAnchor.AnchorOffset,
                sourceAnchor.ContractStartYear,
                sourceAnchor.InternalKey,
                previous,
                distance,
                segmentLength,
                candidates.Count,
                assessment));
        }

        progress?.Report("Decompondo os subregistros por duas origens de alinhamento...");
        var fields = new List<PreIdInternalKeyField>();
        foreach (PreIdInternalKeyAnchor anchor in anchors)
        {
            cancellationToken.ThrowIfCancellationRequested();
            int keyOffset = checked((int)anchor.PreviousKeyOffset);
            int dbidOffset = checked((int)anchor.DatabaseIdOffset);
            int rangeStart = Math.Max(0, keyOffset - ContextBeforeKey);
            int rangeEnd = Math.Min(data.Length, dbidOffset + ContextAfterDbid);

            AddFields(fields, anchor, data, rangeStart, rangeEnd, keyOffset, "PREVIOUS_KEY");
            AddFields(fields, anchor, data, rangeStart, rangeEnd, dbidOffset, "DATABASE_ID");
        }

        progress?.Report("Agrupando comprimentos, assinaturas e campos alinhados...");
        List<PreIdSegmentSignature> signatures = BuildSignatures(anchors, data);
        List<PreIdAlignedFieldSummary> summaries = BuildSummaries(fields);

        var report = new PreIdInternalKeyRecordReport(
            source, data.LongLength, sha, anchors, fields, signatures, summaries, output, DateTimeOffset.UtcNow);

        await File.WriteAllTextAsync(Path.Combine(output, "pre-id-internal-key-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "pre-id-segment-anchors.csv"), FormatAnchorsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "pre-id-segment-fields.csv"), FormatFieldsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "pre-id-segment-signatures.csv"), FormatSignaturesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "pre-id-aligned-field-summaries.csv"), FormatSummariesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "pre-id-segment-contexts.txt"), FormatContexts(report, data), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "pre-id-segment-matrix.csv"), FormatMatrix(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);

        progress?.Report("Mapeamento do subregistro pré-ID concluído.");
        return report;
    }

    private static void AddFields(List<PreIdInternalKeyField> output, PreIdInternalKeyAnchor anchor, byte[] data, int start, int end, int origin, string originName)
    {
        for (int offset = start; offset < end; offset++)
        {
            int rel = offset - origin;
            byte b = data[offset];
            output.Add(new(anchor.Player, anchor.DatabaseId, anchor.RecordSubtype, anchor.SegmentLength, originName, rel, "BYTE", b, b, b.ToString("X2"), Category(b)));

            if (offset + 2 <= end && (rel & 1) == 0)
            {
                ushort u16 = BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(offset, 2));
                short i16 = unchecked((short)u16);
                output.Add(new(anchor.Player, anchor.DatabaseId, anchor.RecordSubtype, anchor.SegmentLength, originName, rel, "UINT16", i16, u16, u16.ToString("X4"), Category(u16)));
            }
            if (offset + 4 <= end && (rel & 3) == 0)
            {
                uint u32 = BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(offset, 4));
                int i32 = unchecked((int)u32);
                output.Add(new(anchor.Player, anchor.DatabaseId, anchor.RecordSubtype, anchor.SegmentLength, originName, rel, "UINT32", i32, u32, u32.ToString("X8"), Category(u32)));
            }
        }
    }

    private static List<PreIdSegmentSignature> BuildSignatures(IReadOnlyList<PreIdInternalKeyAnchor> anchors, byte[] data)
    {
        return anchors
            .GroupBy(x => new { x.RecordSubtype, Bucket = BucketLength(x.PreviousKeyDistance) })
            .Select(g =>
            {
                string signature = string.Join('|', g.Select(x => SegmentSignature(data, checked((int)x.PreviousKeyOffset), checked((int)x.DatabaseIdOffset))).Distinct().Take(8));
                int count = g.Count();
                string assessment = count >= 5 ? "SEGMENT_FAMILY_STRONG" : count >= 3 ? "SEGMENT_FAMILY_MEDIUM" : "SEGMENT_FAMILY_WEAK";
                return new PreIdSegmentSignature(g.Key.RecordSubtype, g.Key.Bucket, count, string.Join(" | ", g.Select(x => x.Player)), signature, assessment);
            })
            .OrderByDescending(x => x.PlayerCount)
            .ThenBy(x => x.RecordSubtype)
            .ThenBy(x => x.SegmentLength)
            .ToList();
    }

    private static int BucketLength(int length) => (int)Math.Round(length / 8.0, MidpointRounding.AwayFromZero) * 8;

    private static string SegmentSignature(byte[] data, int keyOffset, int dbidOffset)
    {
        int start = Math.Max(0, keyOffset);
        int end = Math.Min(data.Length, dbidOffset + 4);
        var tokens = new List<string>();
        for (int i = start; i < end; i += 4)
        {
            int width = Math.Min(4, end - i);
            ReadOnlySpan<byte> span = data.AsSpan(i, width);
            string token;
            if (span.ToArray().All(x => x == 0)) token = "Z";
            else if (width == 4 && span.ToArray().All(x => x == 0xFF)) token = "F";
            else if (width == 4)
            {
                uint value = BinaryPrimitives.ReadUInt32LittleEndian(span);
                token = value switch
                {
                    <= 255 => "S",
                    <= 10_000 => "M",
                    <= 10_000_000 => "L",
                    _ => "X"
                };
            }
            else token = "T";
            tokens.Add(token);
        }
        return string.Join('-', tokens);
    }

    private static List<PreIdAlignedFieldSummary> BuildSummaries(IReadOnlyList<PreIdInternalKeyField> fields)
    {
        return fields
            .GroupBy(x => new { x.RecordSubtype, x.AlignmentOrigin, x.RelativeOffset, x.DataType })
            .Select(g =>
            {
                PreIdInternalKeyField[] rows = g.ToArray();
                int distinct = rows.Select(x => x.UnsignedValue).Distinct().Count();
                int zero = rows.Count(x => x.UnsignedValue == 0);
                int ff = rows.Count(x => x.DataType == "UINT32" && x.UnsignedValue == uint.MaxValue);
                string assessment = rows.Length >= 5 && distinct == 1 ? "FIELD_CONSTANT_STRONG"
                    : rows.Length >= 5 && distinct <= Math.Max(2, rows.Length / 3) ? "FIELD_LOW_VARIANCE"
                    : rows.Length >= 5 ? "FIELD_STRUCTURALLY_SHARED"
                    : "FIELD_WEAK";
                string values = string.Join(" | ", rows.Select(x => $"{x.Player}:{x.UnsignedValue}").Take(30));
                return new PreIdAlignedFieldSummary(g.Key.RecordSubtype, g.Key.AlignmentOrigin, g.Key.RelativeOffset, g.Key.DataType, rows.Length, distinct, zero, ff, values, assessment);
            })
            .OrderByDescending(x => x.PlayerCount)
            .ThenBy(x => x.RecordSubtype)
            .ThenBy(x => x.AlignmentOrigin)
            .ThenBy(x => x.RelativeOffset)
            .ToList();
    }

    private static List<int> FindUInt32(byte[] data, uint value, int start, int endExclusive)
    {
        byte b0 = (byte)value; byte b1 = (byte)(value >> 8); byte b2 = (byte)(value >> 16); byte b3 = (byte)(value >> 24);
        start = Math.Max(0, start); endExclusive = Math.Min(data.Length - 3, endExclusive);
        var result = new List<int>();
        for (int i = start; i < endExclusive; i++)
            if (data[i] == b0 && data[i + 1] == b1 && data[i + 2] == b2 && data[i + 3] == b3) result.Add(i);
        return result;
    }

    private static string Category(ulong value) => value switch
    {
        0 => "ZERO",
        uint.MaxValue => "FFFFFFFF",
        <= 255 => "SMALL",
        <= 10_000 => "MEDIUM",
        <= 10_000_000 => "ID_OR_VALUE",
        _ => "LARGE"
    };

    public static string FormatReportForUi(PreIdInternalKeyRecordReport report) => FormatReport(report);

    private static string FormatReport(PreIdInternalKeyRecordReport r)
    {
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — PreIdInternalKeyRecordDiagnostic 0.0.28.5");
        sb.AppendLine(new string('=', 94));
        sb.AppendLine($"Arquivo: {r.SourceFile}");
        sb.AppendLine($"Tamanho: {r.SourceSize:N0} bytes");
        sb.AppendLine($"SHA-256: {r.Sha256}");
        sb.AppendLine($"Subregistros delimitados: {r.Anchors.Count:N0}");
        sb.AppendLine($"Campos decompostos: {r.Fields.Count:N0}");
        sb.AppendLine($"Famílias de segmento: {r.Signatures.Count:N0}");
        sb.AppendLine($"Resumos alinhados: {r.Summaries.Count:N0}");
        sb.AppendLine();
        sb.AppendLine("Âncoras pré-ID:");
        foreach (PreIdInternalKeyAnchor x in r.Anchors)
            sb.AppendLine($"  {x.Player,-24} subtype={x.RecordSubtype} key=0x{x.PreviousKeyOffset:X8} dbid=0x{x.DatabaseIdOffset:X8} distância={x.PreviousKeyDistance,4} bytes candidatos={x.PreviousKeyCandidateCount,2} {x.Assessment}");
        sb.AppendLine();
        sb.AppendLine("Famílias mais cobertas:");
        foreach (PreIdSegmentSignature x in r.Signatures.Take(20))
            sb.AppendLine($"  subtype={x.RecordSubtype} tamanho≈{x.SegmentLength,3} n={x.PlayerCount,2} {x.Assessment} | {x.Players}");
        sb.AppendLine();
        sb.AppendLine("Arquivos: pre-id-segment-anchors.csv, pre-id-segment-fields.csv, pre-id-segment-signatures.csv, pre-id-aligned-field-summaries.csv, pre-id-segment-contexts.txt e pre-id-segment-matrix.csv.");
        sb.AppendLine("A pasta post-id-source preserva os relatórios usados para selecionar as âncoras. O save não foi modificado.");
        return sb.ToString();
    }

    private static string FormatAnchorsCsv(PreIdInternalKeyRecordReport r)
    {
        var sb = new StringBuilder("player,database_id,record_subtype,database_id_offset,contract_start_year,internal_key,previous_key_offset,previous_key_distance,segment_length,previous_key_candidate_count,assessment\r\n");
        foreach (PreIdInternalKeyAnchor x in r.Anchors) sb.AppendLine($"{Csv(x.Player)},{x.DatabaseId},{x.RecordSubtype},0x{x.DatabaseIdOffset:X8},{x.ContractStartYear},{x.InternalKey},0x{x.PreviousKeyOffset:X8},{x.PreviousKeyDistance},{x.SegmentLength},{x.PreviousKeyCandidateCount},{x.Assessment}");
        return sb.ToString();
    }

    private static string FormatFieldsCsv(PreIdInternalKeyRecordReport r)
    {
        var sb = new StringBuilder("player,database_id,record_subtype,segment_length,alignment_origin,relative_offset,data_type,signed_value,unsigned_value,hex,category\r\n");
        foreach (PreIdInternalKeyField x in r.Fields) sb.AppendLine($"{Csv(x.Player)},{x.DatabaseId},{x.RecordSubtype},{x.SegmentLength},{x.AlignmentOrigin},{x.RelativeOffset},{x.DataType},{x.SignedValue},{x.UnsignedValue},{x.Hex},{x.Category}");
        return sb.ToString();
    }

    private static string FormatSignaturesCsv(PreIdInternalKeyRecordReport r)
    {
        var sb = new StringBuilder("record_subtype,segment_length_bucket,player_count,players,signature,assessment\r\n");
        foreach (PreIdSegmentSignature x in r.Signatures) sb.AppendLine($"{x.RecordSubtype},{x.SegmentLength},{x.PlayerCount},{Csv(x.Players)},{Csv(x.Signature)},{x.Assessment}");
        return sb.ToString();
    }

    private static string FormatSummariesCsv(PreIdInternalKeyRecordReport r)
    {
        var sb = new StringBuilder("record_subtype,alignment_origin,relative_offset,data_type,player_count,distinct_value_count,zero_count,ffffffff_count,values,assessment\r\n");
        foreach (PreIdAlignedFieldSummary x in r.Summaries) sb.AppendLine($"{x.RecordSubtype},{x.AlignmentOrigin},{x.RelativeOffset},{x.DataType},{x.PlayerCount},{x.DistinctValueCount},{x.ZeroCount},{x.FfffffffCount},{Csv(x.Values)},{x.Assessment}");
        return sb.ToString();
    }

    private static string FormatContexts(PreIdInternalKeyRecordReport r, byte[] data)
    {
        var sb = new StringBuilder();
        foreach (PreIdInternalKeyAnchor x in r.Anchors)
        {
            int start = Math.Max(0, checked((int)x.PreviousKeyOffset) - ContextBeforeKey);
            int end = Math.Min(data.Length, checked((int)x.DatabaseIdOffset) + ContextAfterDbid);
            sb.AppendLine($"[{x.Player}] subtype={x.RecordSubtype} distância={x.PreviousKeyDistance} key=0x{x.PreviousKeyOffset:X8} dbid=0x{x.DatabaseIdOffset:X8}");
            sb.AppendLine(Convert.ToHexString(data.AsSpan(start, end - start)));
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string FormatMatrix(PreIdInternalKeyRecordReport r)
    {
        var selected = r.Fields.Where(x => x.AlignmentOrigin == "DATABASE_ID" && x.DataType == "UINT32").ToArray();
        int[] offsets = selected.Select(x => x.RelativeOffset).Distinct().OrderBy(x => x).ToArray();
        var sb = new StringBuilder("player,database_id,record_subtype,segment_length");
        foreach (int offset in offsets) sb.Append($",rel_{offset}");
        sb.AppendLine();
        foreach (PreIdInternalKeyAnchor anchor in r.Anchors)
        {
            sb.Append($"{Csv(anchor.Player)},{anchor.DatabaseId},{anchor.RecordSubtype},{anchor.SegmentLength}");
            foreach (int offset in offsets)
            {
                PreIdInternalKeyField? value = selected.FirstOrDefault(x => x.DatabaseId == anchor.DatabaseId && x.RelativeOffset == offset);
                sb.Append(',').Append(value?.UnsignedValue.ToString(CultureInfo.InvariantCulture) ?? string.Empty);
            }
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string Csv(string? value) => '"' + (value ?? string.Empty).Replace("\"", "\"\"") + '"';
}
