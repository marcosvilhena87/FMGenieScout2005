using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using FMGenieScout2005.Core.Models;

namespace FMGenieScout2005.Core.Diagnostics;

public sealed class AthirsonOccurrenceClassifierDiagnostic
{
    private const uint JeanDatabaseId = 315116;
    private const uint AthirsonDatabaseId = 3_301_535;
    private const int WindowBefore = 256;
    private const int WindowAfter = 512;

    private static readonly (string Target, int JeanValue, int AthirsonValue)[] SemanticTargets =
    [
        ("BirthYear", 1982, 1977),
        ("ContractStartYear", 2001, 2004),
        ("ContractEndYear", 2006, 2006),
        ("WeeklyWage", 675, 5000),
        ("AssistBonus", 35, 240),
        ("DisplayedValue", 3_000_000, 2_600_000),
        ("ReleaseClause", 11_000_000, 12_750_000)
    ];

    public async Task<AthirsonOccurrenceClassifierReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source)) throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);
        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();

        progress?.Report("Localizando Jean e todas as ocorrências do Athirson...");
        List<long> jeanAnchors = FindUInt32(data, JeanDatabaseId).Select(x => (long)x).ToList();
        List<long> athirsonAnchors = FindUInt32(data, AthirsonDatabaseId).Select(x => (long)x).ToList();
        if (jeanAnchors.Count == 0) throw new InvalidOperationException("O PersonDatabaseId 315116 do Jean não foi encontrado.");
        if (athirsonAnchors.Count == 0) throw new InvalidOperationException("O PersonDatabaseId 3301535 do Athirson não foi encontrado.");
        long jeanAnchor = jeanAnchors[0];

        progress?.Report("Classificando as ocorrências do Athirson...");
        var classifications = new List<AthirsonOccurrenceClassification>();
        for (int i = 0; i < athirsonAnchors.Count; i++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            classifications.Add(Classify(data, jeanAnchor, athirsonAnchors[i], i + 1));
        }

        AthirsonOccurrenceClassification selected = classifications
            .OrderByDescending(x => x.Score)
            .ThenByDescending(x => x.SemanticPairHitCount)
            .ThenByDescending(x => x.LayoutSimilarity)
            .ThenBy(x => x.Utf16NameCount)
            .ThenBy(x => x.AnchorOffset)
            .First();

        progress?.Report($"Ocorrência selecionada: 0x{selected.AnchorOffset:X8} ({selected.Classification})...");
        List<AthirsonSemanticComparison> semantic = BuildSemanticComparisons(data, jeanAnchor, selected.AnchorOffset);

        var report = new AthirsonOccurrenceClassifierReport(
            source, data.LongLength, sha, jeanAnchor, athirsonAnchors, selected.AnchorOffset,
            classifications.OrderByDescending(x => x.Score).ToArray(), semantic, output, DateTimeOffset.UtcNow);

        await File.WriteAllTextAsync(Path.Combine(output, "athirson-occurrence-classifier-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "athirson-occurrence-classifications.csv"), FormatClassificationsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "athirson-occurrence-contexts.txt"), FormatContexts(report, data), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "jean-selected-athirson-semantic-comparisons.csv"), FormatSemanticCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "jean-selected-athirson-offset-matrix.csv"), FormatOffsetMatrix(data, report.JeanAnchor, report.SelectedAthirsonAnchor), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);

        progress?.Report("Classificação das ocorrências do Athirson concluída.");
        return report;
    }

    private static AthirsonOccurrenceClassification Classify(byte[] data, long jeanAnchor, long anchor, int ordinal)
    {
        bool identity189 = TryReadUInt32(data, anchor - 8, out uint marker) && marker == 189;
        int names = CountPlausibleUtf16Strings(data, anchor - 256, anchor + 256);
        int zeroCount = CountByte(data, anchor - 128, anchor + 256, 0);
        int ffCount = CountUInt32(data, anchor - 128, anchor + 256, uint.MaxValue);
        int knownHits = CountKnownAthirsonValues(data, anchor);
        int semanticPairHits = CountSemanticPairHits(data, jeanAnchor, anchor);
        double similarity = ComputeLayoutSimilarity(data, jeanAnchor, anchor);

        double score = similarity * 45.0 + knownHits * 12.0 + semanticPairHits * 25.0;
        score += Math.Min(ffCount, 6) * 1.5;
        score -= Math.Min(names, 20) * 5.0;
        if (identity189) score -= 80.0;

        string classification;
        if (identity189 || names >= 5) classification = "IDENTITY_NAME_TABLE";
        else if (semanticPairHits >= 2 || (knownHits >= 3 && similarity >= 0.55)) classification = "PLAYER_OR_CONTRACT_RECORD";
        else if (similarity >= 0.55 || knownHits >= 2) classification = "STRUCTURALLY_COMPARABLE_CANDIDATE";
        else if (names > 0) classification = "AUXILIARY_REFERENCE";
        else classification = "UNKNOWN_REFERENCE";

        string evidence = string.Join("|", new[]
        {
            identity189 ? "MARKER_189_MINUS8" : null,
            names > 0 ? $"UTF16_NAMES={names}" : null,
            knownHits > 0 ? $"KNOWN_VALUES={knownHits}" : null,
            semanticPairHits > 0 ? $"SEMANTIC_PAIRS={semanticPairHits}" : null,
            $"LAYOUT={similarity:F3}",
            $"ZERO_BYTES={zeroCount}",
            $"FFFFFFFF={ffCount}"
        }.Where(x => x is not null));

        return new AthirsonOccurrenceClassification(anchor, ordinal, identity189, names, knownHits,
            semanticPairHits, similarity, zeroCount, ffCount, score, classification, evidence);
    }

    private static int CountKnownAthirsonValues(byte[] data, long anchor)
    {
        int[] values = [1977, 2004, 2006, 5000, 240, 2_600_000, 12_750_000];
        int hits = 0;
        foreach (int value in values)
            if (ContainsIntegerNear(data, anchor, value)) hits++;
        return hits;
    }

    private static int CountSemanticPairHits(byte[] data, long jeanAnchor, long athirsonAnchor)
    {
        int hits = 0;
        foreach (var target in SemanticTargets)
        {
            bool found = false;
            for (int rel = -WindowBefore; rel < WindowAfter && !found; rel++)
            {
                foreach (string type in new[] { "BYTE", "UINT16", "UINT32", "INT32" })
                {
                    int width = Width(type);
                    if (!CanRead(data, jeanAnchor + rel, width) || !CanRead(data, athirsonAnchor + rel, width)) continue;
                    long j = ReadInteger(data, jeanAnchor + rel, type);
                    long a = ReadInteger(data, athirsonAnchor + rel, type);
                    if (j == target.JeanValue && a == target.AthirsonValue) { found = true; break; }
                }
            }
            if (found) hits++;
        }
        return hits;
    }

    private static List<AthirsonSemanticComparison> BuildSemanticComparisons(byte[] data, long jeanAnchor, long athirsonAnchor)
    {
        var result = new List<AthirsonSemanticComparison>();
        foreach (var target in SemanticTargets)
        {
            foreach (string type in new[] { "BYTE", "UINT16", "UINT32", "INT32" })
            {
                int width = Width(type);
                for (int rel = -WindowBefore; rel < WindowAfter; rel++)
                {
                    if (!CanRead(data, jeanAnchor + rel, width) || !CanRead(data, athirsonAnchor + rel, width)) continue;
                    long j = ReadInteger(data, jeanAnchor + rel, type);
                    long a = ReadInteger(data, athirsonAnchor + rel, type);
                    bool jm = j == target.JeanValue;
                    bool am = a == target.AthirsonValue;
                    if (!jm && !am) continue;
                    string assessment = jm && am ? "SEMANTIC_PAIR_CONFIRMED" : jm ? "JEAN_ONLY" : "ATHIRSON_ONLY";
                    double score = jm && am ? 100 : 35;
                    result.Add(new AthirsonSemanticComparison(target.Target, type, rel, target.JeanValue, j,
                        target.AthirsonValue, a, jm, am, assessment, score));
                }
            }
        }
        return result.OrderByDescending(x => x.Score).ThenBy(x => Math.Abs(x.RelativeOffset)).ToList();
    }

    private static double ComputeLayoutSimilarity(byte[] data, long jeanAnchor, long athirsonAnchor)
    {
        int compared = 0;
        int matches = 0;
        for (int rel = -128; rel < 256; rel += 4)
        {
            if (!CanRead(data, jeanAnchor + rel, 4) || !CanRead(data, athirsonAnchor + rel, 4)) continue;
            uint j = ReadUInt32(data, jeanAnchor + rel);
            uint a = ReadUInt32(data, athirsonAnchor + rel);
            string jc = Category(j);
            string ac = Category(a);
            compared++;
            if (jc == ac) matches++;
        }
        return compared == 0 ? 0 : matches / (double)compared;
    }

    private static string Category(uint value) => value switch
    {
        0 => "ZERO",
        uint.MaxValue => "FFFFFFFF",
        <= 1 => "FLAG",
        <= 255 => "BYTE_RANGE",
        <= 65535 => "U16_RANGE",
        <= 10_000_000 => "ID_OR_VALUE",
        _ => "LARGE"
    };

    private static bool ContainsIntegerNear(byte[] data, long anchor, int expected)
    {
        for (int rel = -WindowBefore; rel < WindowAfter; rel++)
        {
            long pos = anchor + rel;
            if (expected is >= 0 and <= 255 && CanRead(data, pos, 1) && data[(int)pos] == expected) return true;
            if (expected is >= 0 and <= ushort.MaxValue && CanRead(data, pos, 2) && BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan((int)pos, 2)) == expected) return true;
            if (CanRead(data, pos, 4) && BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan((int)pos, 4)) == expected) return true;
        }
        return false;
    }

    private static int CountPlausibleUtf16Strings(byte[] data, long startLong, long endLong)
    {
        int start = Math.Max(0, checked((int)Math.Max(0, startLong)));
        int end = Math.Min(data.Length - 4, checked((int)Math.Min(data.LongLength - 4, endLong)));
        int count = 0;
        for (int i = start; i <= end; i++)
        {
            int length = BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(i, 4));
            if (length < 2 || length > 60) continue;
            long bytes = (long)length * 2;
            if (i + 4L + bytes + 2 > data.Length) continue;
            string text = Encoding.Unicode.GetString(data, i + 4, checked((int)bytes));
            if (!IsPlausibleName(text)) continue;
            if (data[i + 4 + bytes] != 0 || data[i + 5 + bytes] != 0) continue;
            count++;
            i += checked((int)bytes) + 5;
        }
        return count;
    }

    private static bool IsPlausibleName(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return false;
        int letters = 0;
        foreach (char c in text)
        {
            if (char.IsLetter(c)) letters++;
            else if (!(char.IsWhiteSpace(c) || char.IsDigit(c) || c is '-' or '\'' or '.' or '(' or ')')) return false;
        }
        return letters >= 2 && letters * 2 >= text.Length;
    }

    private static int CountByte(byte[] data, long startLong, long endLong, byte value)
    {
        int start = Math.Max(0, checked((int)Math.Max(0, startLong)));
        int end = Math.Min(data.Length, checked((int)Math.Min(data.LongLength, endLong)));
        int count = 0;
        for (int i = start; i < end; i++) if (data[i] == value) count++;
        return count;
    }

    private static int CountUInt32(byte[] data, long startLong, long endLong, uint value)
    {
        int start = Math.Max(0, checked((int)Math.Max(0, startLong)));
        int end = Math.Min(data.Length - 4, checked((int)Math.Min(data.LongLength - 4, endLong)));
        int count = 0;
        for (int i = start; i <= end; i++) if (ReadUInt32(data, i) == value) count++;
        return count;
    }

    private static string FormatReport(AthirsonOccurrenceClassifierReport report)
    {
        AthirsonOccurrenceClassification selected = report.Classifications.First(x => x.AnchorOffset == report.SelectedAthirsonAnchor);
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — AthirsonOccurrenceClassifierDiagnostic 0.0.28.2");
        sb.AppendLine(new string('=', 96));
        sb.AppendLine($"Arquivo: {report.SourceFile}");
        sb.AppendLine($"Tamanho: {report.SourceSize:N0} bytes");
        sb.AppendLine($"SHA-256: {report.Sha256}");
        sb.AppendLine($"Jean: 0x{report.JeanAnchor:X8}");
        sb.AppendLine($"Ocorrências do Athirson: {report.AthirsonAnchors.Count}");
        sb.AppendLine($"Selecionada: 0x{selected.AnchorOffset:X8} | score={selected.Score:F2} | {selected.Classification}");
        sb.AppendLine($"Evidência: {selected.Evidence}");
        sb.AppendLine();
        sb.AppendLine("Classificação das ocorrências:");
        foreach (AthirsonOccurrenceClassification x in report.Classifications)
            sb.AppendLine($"  #{x.Ordinal} 0x{x.AnchorOffset:X8} score={x.Score,7:F2} layout={x.LayoutSimilarity:F3} nomes={x.Utf16NameCount,2} conhecidos={x.KnownValueHitCount} pares={x.SemanticPairHitCount} | {x.Classification}");
        sb.AppendLine();
        sb.AppendLine("Pares semânticos confirmados na ocorrência selecionada:");
        foreach (AthirsonSemanticComparison x in report.SemanticComparisons.Where(x => x.Assessment == "SEMANTIC_PAIR_CONFIRMED"))
            sb.AppendLine($"  {x.Target,-22} {x.DataType,-6} rel={x.RelativeOffset,5} Jean={x.JeanActual} Athirson={x.AthirsonActual}");
        sb.AppendLine();
        sb.AppendLine("Arquivos gerados: athirson-occurrence-classifier-report.txt, athirson-occurrence-classifications.csv, athirson-occurrence-contexts.txt, jean-selected-athirson-semantic-comparisons.csv e jean-selected-athirson-offset-matrix.csv.");
        sb.AppendLine("O arquivo de origem não foi modificado.");
        return sb.ToString();
    }

    public static string FormatReportForUi(AthirsonOccurrenceClassifierReport report) => FormatReport(report);

    private static string FormatClassificationsCsv(AthirsonOccurrenceClassifierReport report)
    {
        var sb = new StringBuilder("ordinal,anchor_offset,selected,identity_marker_189_minus8,utf16_name_count,known_value_hit_count,semantic_pair_hit_count,layout_similarity,zero_byte_count,ffffffff_count,score,classification,evidence\r\n");
        foreach (AthirsonOccurrenceClassification x in report.Classifications)
            sb.AppendLine(string.Join(',', x.Ordinal, $"0x{x.AnchorOffset:X8}", x.AnchorOffset == report.SelectedAthirsonAnchor,
                x.IdentityMarker189AtMinus8, x.Utf16NameCount, x.KnownValueHitCount, x.SemanticPairHitCount,
                x.LayoutSimilarity.ToString("F6", CultureInfo.InvariantCulture), x.ZeroByteCount, x.FfffffffCount,
                x.Score.ToString("F2", CultureInfo.InvariantCulture), Csv(x.Classification), Csv(x.Evidence)));
        return sb.ToString();
    }

    private static string FormatSemanticCsv(AthirsonOccurrenceClassifierReport report)
    {
        var sb = new StringBuilder("target,data_type,relative_offset,jean_expected,jean_actual,athirson_expected,athirson_actual,jean_match,athirson_match,assessment,score\r\n");
        foreach (AthirsonSemanticComparison x in report.SemanticComparisons)
            sb.AppendLine(string.Join(',', Csv(x.Target), x.DataType, x.RelativeOffset, x.JeanExpected, x.JeanActual,
                x.AthirsonExpected, x.AthirsonActual, x.JeanMatch, x.AthirsonMatch, Csv(x.Assessment), x.Score.ToString("F2", CultureInfo.InvariantCulture)));
        return sb.ToString();
    }

    private static string FormatOffsetMatrix(byte[] data, long jeanAnchor, long athirsonAnchor)
    {
        var sb = new StringBuilder("relative_offset,data_type,jean_absolute_offset,athirson_absolute_offset,jean_raw_hex,athirson_raw_hex,jean_value,athirson_value,equal\r\n");
        for (int rel = -WindowBefore; rel < WindowAfter; rel++)
        {
            foreach (string type in new[] { "BYTE", "UINT16", "UINT32", "INT32", "FLOAT32" })
            {
                int width = Width(type);
                if ((type == "UINT16" && (rel & 1) != 0) || (width == 4 && (rel & 3) != 0)) continue;
                long jPos = jeanAnchor + rel;
                long aPos = athirsonAnchor + rel;
                if (!CanRead(data, jPos, width) || !CanRead(data, aPos, width)) continue;
                string jHex = Convert.ToHexString(data.AsSpan((int)jPos, width));
                string aHex = Convert.ToHexString(data.AsSpan((int)aPos, width));
                string jValue = ReadAsString(data, jPos, type);
                string aValue = ReadAsString(data, aPos, type);
                sb.AppendLine(string.Join(',', rel, type, $"0x{jPos:X8}", $"0x{aPos:X8}", jHex, aHex, Csv(jValue), Csv(aValue), jHex == aHex));
            }
        }
        return sb.ToString();
    }

    private static string FormatContexts(AthirsonOccurrenceClassifierReport report, byte[] data)
    {
        var sb = new StringBuilder();
        AppendContext(sb, data, "Jean", report.JeanAnchor, null);
        foreach (AthirsonOccurrenceClassification x in report.Classifications.OrderBy(x => x.Ordinal))
            AppendContext(sb, data, $"Athirson #{x.Ordinal}", x.AnchorOffset, x);
        return sb.ToString();
    }

    private static void AppendContext(StringBuilder sb, byte[] data, string title, long anchor, AthirsonOccurrenceClassification? classification)
    {
        sb.AppendLine($"[{title} @ 0x{anchor:X8}]" + (classification is null ? string.Empty : $" score={classification.Score:F2} {classification.Classification} {classification.Evidence}"));
        int start = Math.Max(0, checked((int)anchor) - WindowBefore);
        int length = Math.Min(WindowBefore + WindowAfter, data.Length - start);
        for (int offset = 0; offset < length; offset += 16)
        {
            int count = Math.Min(16, length - offset);
            long absolute = start + offset;
            int relative = checked((int)(absolute - anchor));
            sb.Append($"{relative,6:+0;-0;0} 0x{absolute:X8}  ");
            sb.AppendLine(Convert.ToHexString(data.AsSpan(start + offset, count)));
        }
        sb.AppendLine();
    }

    private static int Width(string type) => type switch { "BYTE" => 1, "UINT16" => 2, _ => 4 };
    private static bool CanRead(byte[] data, long offset, int width) => offset >= 0 && offset + width <= data.LongLength;
    private static uint ReadUInt32(byte[] data, long offset) => BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(checked((int)offset), 4));
    private static bool TryReadUInt32(byte[] data, long offset, out uint value)
    {
        if (!CanRead(data, offset, 4)) { value = 0; return false; }
        value = ReadUInt32(data, offset); return true;
    }
    private static long ReadInteger(byte[] data, long pos, string type) => type switch
    {
        "BYTE" => data[checked((int)pos)],
        "UINT16" => BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(checked((int)pos), 2)),
        "UINT32" => BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(checked((int)pos), 4)),
        "INT32" => BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(checked((int)pos), 4)),
        _ => long.MinValue
    };
    private static string ReadAsString(byte[] data, long pos, string type) => type switch
    {
        "BYTE" => data[checked((int)pos)].ToString(CultureInfo.InvariantCulture),
        "UINT16" => BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(checked((int)pos), 2)).ToString(CultureInfo.InvariantCulture),
        "UINT32" => BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(checked((int)pos), 4)).ToString(CultureInfo.InvariantCulture),
        "INT32" => BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(checked((int)pos), 4)).ToString(CultureInfo.InvariantCulture),
        "FLOAT32" => BitConverter.Int32BitsToSingle(BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan(checked((int)pos), 4))).ToString("R", CultureInfo.InvariantCulture),
        _ => string.Empty
    };
    private static IEnumerable<int> FindUInt32(byte[] data, uint value)
    {
        byte b0 = (byte)value; byte b1 = (byte)(value >> 8); byte b2 = (byte)(value >> 16); byte b3 = (byte)(value >> 24);
        for (int i = 0; i <= data.Length - 4; i++)
            if (data[i] == b0 && data[i + 1] == b1 && data[i + 2] == b2 && data[i + 3] == b3) yield return i;
    }
    private static string Csv(string? value)
    {
        string text = value ?? string.Empty;
        return '"' + text.Replace("\"", "\"\"") + '"';
    }
}
