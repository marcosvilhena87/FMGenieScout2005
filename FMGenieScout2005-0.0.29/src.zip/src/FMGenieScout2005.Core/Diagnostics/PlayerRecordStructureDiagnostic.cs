using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using FMGenieScout2005.Core.Domain;
using FMGenieScout2005.Core.Models;
using FMGenieScout2005.Core.Parsing;

namespace FMGenieScout2005.Core.Diagnostics;

/// <summary>
/// Valida a hipótese de que o ClubSaveIndex do registro funcional do jogador fica
/// 17 bytes antes do PersonDatabaseId. Compara jogadores conhecidos de Flamengo e Corinthians.
/// Somente leitura.
/// </summary>
public sealed class PlayerRecordStructureDiagnostic
{
    private const int ClubFieldRelativeOffset = -17;
    private const int ContextBefore = 48;
    private const int ContextAfter = 64;

    private static readonly KnownPlayerRecordSample[] Samples =
    [
        new("CR Flamengo", 322, "Andrezinho", 302728),
        new("CR Flamengo", 322, "André Bahia", 311169),
        new("CR Flamengo", 322, "Bruno Santos", 8832815),
        new("CR Flamengo", 322, "Dimba", 303048),
        new("CR Flamengo", 322, "Douglas Silva", 3300410),
        new("CR Flamengo", 322, "Fabiano Eller", 3300219),
        new("CR Flamengo", 322, "Júlio César Moraes", 8825041),
        new("CR Flamengo", 322, "Júnior Baiano", 6900111),
        new("CR Flamengo", 322, "Reginaldo Araújo", 3300780),

        new("SC Corinthians Paulista", 319, "Édson Araújo", 308345),
        new("SC Corinthians Paulista", 319, "Fábio Baiano", 3300471),
        new("SC Corinthians Paulista", 319, "Fábio Costa", 6900151),
        new("SC Corinthians Paulista", 319, "Luciano Ratinho", 6900008),
        new("SC Corinthians Paulista", 319, "Marcelo Magalhães", 302580),
        new("SC Corinthians Paulista", 319, "Bruno Octávio", 8832887),
        new("SC Corinthians Paulista", 319, "Alessandro", 3902245),
        new("SC Corinthians Paulista", 319, "Rosinei", 316596),
        new("SC Corinthians Paulista", 319, "Dinélson", 320774)
    ];

    private readonly Fm2005PersonIdentityParser _personParser = new();
    private readonly Fm2005ClubParser _clubParser = new();

    public async Task<PlayerRecordStructureReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source)) throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);
        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();

        progress?.Report("Extraindo pessoas e clubes...");
        Fm2005PersonIdentityParseResult people = _personParser.Parse(data, source, sha, progress, cancellationToken);
        Fm2005ClubParseResult clubs = _clubParser.Parse(data, cancellationToken);

        var expectedClubs = Samples.Select(x => x.ExpectedClubDatabaseId).Distinct()
            .ToDictionary(id => id, id => clubs.FindByDatabaseId(id)
                ?? throw new InvalidDataException($"Clube esperado DatabaseId={id} não localizado."));

        var candidates = new List<PlayerRecordCandidate>();
        var missing = new List<string>();

        foreach (KnownPlayerRecordSample sample in Samples)
        {
            cancellationToken.ThrowIfCancellationRequested();
            PersonIdentity? identity = people.FindByDatabaseId(sample.PersonDatabaseId);
            if (identity is null)
            {
                missing.Add($"{sample.DisplayName} ({sample.PersonDatabaseId}) — identidade não encontrada");
                continue;
            }

            progress?.Report($"Validando {sample.DisplayName}...");
            Club expected = expectedClubs[sample.ExpectedClubDatabaseId];
            foreach (int dbidOffset in FindUInt32(data, sample.PersonDatabaseId, cancellationToken))
            {
                int clubOffset = dbidOffset + ClubFieldRelativeOffset;
                if (clubOffset < 0 || clubOffset + 4 > data.Length) continue;

                uint clubSaveIndex = BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(clubOffset, 4));
                Club? resolved = clubs.FindBySaveIndex(clubSaveIndex);
                long identityDatabaseIdOffset = checked(identity.NameOffset + (long)identity.NameLength * 2L + 12L);
                bool identityOccurrence = Math.Abs((long)dbidOffset - identityDatabaseIdOffset) <= 16L;
                string classification = identityOccurrence ? "TABELA_DE_IDENTIDADE"
                    : resolved is null ? "CLUB_INDEX_INVALIDO"
                    : resolved.DatabaseId == sample.ExpectedClubDatabaseId ? "PLAYER_RECORD_CONFIRMADO"
                    : "PLAYER_RECORD_OUTRO_CLUBE";

                candidates.Add(new PlayerRecordCandidate(
                    sample.ExpectedClub, sample.ExpectedClubDatabaseId, expected.SaveIndex,
                    sample.DisplayName, sample.PersonDatabaseId, dbidOffset, clubOffset,
                    clubSaveIndex, resolved?.DatabaseId, resolved?.FullName,
                    identityOccurrence, classification,
                    HexContext(data, dbidOffset, ContextBefore, ContextAfter)));
            }
        }

        PlayerRecordClubSummary[] summaries = Samples.GroupBy(x => new { x.ExpectedClub, x.ExpectedClubDatabaseId })
            .Select(g =>
            {
                Club expected = expectedClubs[g.Key.ExpectedClubDatabaseId];
                string[] playerNames = g.Select(x => x.DisplayName).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
                PlayerRecordCandidate[] rows = candidates.Where(x => x.ExpectedClubDatabaseId == g.Key.ExpectedClubDatabaseId).ToArray();
                int confirmedPlayers = rows.Where(x => x.Classification == "PLAYER_RECORD_CONFIRMADO")
                    .Select(x => x.DisplayName).Distinct(StringComparer.OrdinalIgnoreCase).Count();
                int confirmedOccurrences = rows.Count(x => x.Classification == "PLAYER_RECORD_CONFIRMADO");
                int wrong = rows.Count(x => x.Classification == "PLAYER_RECORD_OUTRO_CLUBE");
                int invalid = rows.Count(x => x.Classification == "CLUB_INDEX_INVALIDO");
                int resolvedPeople = playerNames.Length - missing.Count(m => playerNames.Any(n => m.StartsWith(n + " (", StringComparison.OrdinalIgnoreCase)));
                string assessment = confirmedPlayers >= 6 ? "EVIDENCIA_FORTE"
                    : confirmedPlayers >= 4 ? "EVIDENCIA_MEDIA"
                    : confirmedPlayers >= 2 ? "EVIDENCIA_FRACA"
                    : "INCONCLUSIVO";
                return new PlayerRecordClubSummary(g.Key.ExpectedClub, g.Key.ExpectedClubDatabaseId,
                    expected.SaveIndex, playerNames.Length, resolvedPeople, confirmedPlayers,
                    confirmedOccurrences, wrong, invalid, assessment);
            }).ToArray();

        var report = new PlayerRecordStructureReport(source, data.LongLength, sha, ClubFieldRelativeOffset,
            candidates.OrderBy(x => x.ExpectedClubDatabaseId).ThenBy(x => x.DisplayName).ThenBy(x => x.PersonDatabaseIdOffset).ToArray(),
            summaries, missing, output, DateTimeOffset.UtcNow);

        progress?.Report("Gravando relatórios da estrutura de jogador...");
        await File.WriteAllTextAsync(Path.Combine(output, "player-record-structure-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "player-record-candidates.csv"), FormatCandidatesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "player-club-resolution.csv"), FormatResolutionCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "player-record-contexts.txt"), FormatContexts(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "player-record-variant-candidates.csv"), FormatVariantsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllLinesAsync(Path.Combine(output, "people-not-resolved.txt"), report.MissingPeople, new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        progress?.Report("Validação da estrutura de jogador concluída.");
        return report;
    }

    private static IEnumerable<int> FindUInt32(byte[] data, uint value, CancellationToken cancellationToken)
    {
        byte b0 = (byte)value;
        byte b1 = (byte)(value >> 8);
        byte b2 = (byte)(value >> 16);
        byte b3 = (byte)(value >> 24);

        for (int i = 0; i <= data.Length - 4; i++)
        {
            if ((i & 0xFFFF) == 0) cancellationToken.ThrowIfCancellationRequested();
            if (data[i] == b0 && data[i + 1] == b1 && data[i + 2] == b2 && data[i + 3] == b3)
                yield return i;
        }
    }

    private static string HexContext(byte[] data, int center, int before, int after)
    {
        int start = Math.Max(0, center - before);
        int length = Math.Min(data.Length - start, before + 4 + after);
        return Convert.ToHexString(data.AsSpan(start, length));
    }

    public static string FormatReport(PlayerRecordStructureReport report)
    {
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — PlayerRecordStructureDiagnostic 0.0.24");
        sb.AppendLine(new string('=', 96));
        sb.AppendLine($"Arquivo: {report.SourceFile}");
        sb.AppendLine($"Tamanho: {report.SourceSize:N0} bytes");
        sb.AppendLine($"SHA-256: {report.Sha256}");
        sb.AppendLine($"Hipótese testada: ClubSaveIndex em PersonDatabaseIdOffset {report.RelativeClubOffset:+0;-0;0}");
        sb.AppendLine($"Ocorrências avaliadas: {report.Candidates.Count:N0}");
        sb.AppendLine($"Pessoas não resolvidas: {report.MissingPeople.Count:N0}");
        sb.AppendLine();
        sb.AppendLine("Resultado por clube:");
        foreach (PlayerRecordClubSummary x in report.ClubSummaries)
            sb.AppendLine($"  {x.ExpectedClub,-25} DBID={x.ExpectedClubDatabaseId,6} SaveIndex={x.ExpectedClubSaveIndex,5} | conhecidos={x.KnownPlayers} resolvidos={x.ResolvedPeople} confirmados={x.ConfirmedPlayers} jogadores/{x.ConfirmedOccurrences} ocorrências | outro_clube={x.WrongClubOccurrences} inválidos={x.InvalidClubIndexOccurrences} | {x.Assessment}");
        sb.AppendLine();
        sb.AppendLine("Registros confirmados:");
        foreach (PlayerRecordCandidate x in report.Candidates.Where(x => x.Classification == "PLAYER_RECORD_CONFIRMADO"))
            sb.AppendLine($"  {x.DisplayName,-24} dbid={x.PersonDatabaseId,8} dbid_offset=0x{x.PersonDatabaseIdOffset:X8} club_offset=0x{x.ClubFieldOffset:X8} save_index={x.ClubSaveIndexValue,5} → {x.ResolvedClubName}");
        sb.AppendLine();
        bool strongAll = report.ClubSummaries.Count >= 2 && report.ClubSummaries.All(x => x.ConfirmedPlayers >= 6);
        sb.AppendLine("Interpretação automática:");
        sb.AppendLine(strongAll
            ? "  EVIDÊNCIA_FORTE_MULTICLUBE: o offset -17 resolveu corretamente pelo menos 6 jogadores em cada um dos dois clubes."
            : "  AINDA_REVISAR: um ou mais clubes não atingiram 6 jogadores confirmados no offset -17.");
        sb.AppendLine();
        sb.AppendLine("Arquivos gerados: player-record-structure-report.txt, player-record-candidates.csv, player-club-resolution.csv, player-record-contexts.txt, player-record-variant-candidates.csv e people-not-resolved.txt.");
        sb.AppendLine("O arquivo de origem não foi modificado.");
        return sb.ToString();
    }

    private static string FormatCandidatesCsv(PlayerRecordStructureReport r)
    {
        var sb = new StringBuilder("expected_club,expected_club_database_id,expected_club_save_index,display_name,person_database_id,person_database_id_offset,club_field_offset,club_save_index_value,resolved_club_database_id,resolved_club_name,is_identity_occurrence,classification,context_hex\r\n");
        foreach (PlayerRecordCandidate x in r.Candidates)
            sb.AppendLine(string.Join(',', Csv(x.ExpectedClub), x.ExpectedClubDatabaseId, x.ExpectedClubSaveIndex, Csv(x.DisplayName), x.PersonDatabaseId,
                $"0x{x.PersonDatabaseIdOffset:X8}", $"0x{x.ClubFieldOffset:X8}", x.ClubSaveIndexValue,
                x.ResolvedClubDatabaseId?.ToString(CultureInfo.InvariantCulture) ?? string.Empty, Csv(x.ResolvedClubName), x.IsIdentityOccurrence, x.Classification, x.ContextHex));
        return sb.ToString();
    }

    private static string FormatResolutionCsv(PlayerRecordStructureReport r)
    {
        var sb = new StringBuilder("expected_club,display_name,person_database_id,person_database_id_offset,club_save_index,resolved_club_database_id,resolved_club_name,classification\r\n");
        foreach (PlayerRecordCandidate x in r.Candidates.Where(x => !x.IsIdentityOccurrence))
            sb.AppendLine(string.Join(',', Csv(x.ExpectedClub), Csv(x.DisplayName), x.PersonDatabaseId, $"0x{x.PersonDatabaseIdOffset:X8}", x.ClubSaveIndexValue,
                x.ResolvedClubDatabaseId?.ToString(CultureInfo.InvariantCulture) ?? string.Empty, Csv(x.ResolvedClubName), x.Classification));
        return sb.ToString();
    }

    private static string FormatVariantsCsv(PlayerRecordStructureReport r)
    {
        var sb = new StringBuilder("expected_club,display_name,person_database_id,person_database_id_offset,club_save_index,resolved_club_name,classification\r\n");
        foreach (PlayerRecordCandidate x in r.Candidates.Where(x => x.Classification is "PLAYER_RECORD_OUTRO_CLUBE" or "CLUB_INDEX_INVALIDO"))
            sb.AppendLine(string.Join(',', Csv(x.ExpectedClub), Csv(x.DisplayName), x.PersonDatabaseId, $"0x{x.PersonDatabaseIdOffset:X8}", x.ClubSaveIndexValue, Csv(x.ResolvedClubName), x.Classification));
        return sb.ToString();
    }

    private static string FormatContexts(PlayerRecordStructureReport r)
    {
        var sb = new StringBuilder();
        foreach (PlayerRecordCandidate x in r.Candidates.Where(x => !x.IsIdentityOccurrence))
        {
            sb.AppendLine($"[{x.Classification}] {x.DisplayName} | esperado={x.ExpectedClub} | dbid={x.PersonDatabaseId} | dbid_offset=0x{x.PersonDatabaseIdOffset:X8} | club_offset=0x{x.ClubFieldOffset:X8} | valor={x.ClubSaveIndexValue} | resolvido={x.ResolvedClubName ?? "-"}");
            sb.AppendLine(x.ContextHex);
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string Csv(string? value)
    {
        string text = value ?? string.Empty;
        return '"' + text.Replace("\"", "\"\"") + '"';
    }
}
