using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using FMGenieScout2005.Core.Domain;
using FMGenieScout2005.Core.Models;
using FMGenieScout2005.Core.Parsing;

namespace FMGenieScout2005.Core.Diagnostics;

/// <summary>
/// Diagnóstico 0.0.28.7: compara jogadores emprestados em sentidos opostos para
/// localizar uma segunda referência de clube dentro do registro contratual.
/// Nenhum arquivo do save é modificado.
/// </summary>
public sealed class LoanRelationshipDiagnostic
{
    private const int ContextBefore = 32;
    private const int ContextAfter = 32;

    private static readonly KnownLoanCase[] KnownCases =
    [
        new("Reginaldo Araújo", 3300780, 104776, "Coritiba", 322, "CR Flamengo", "CR Flamengo", "LOANED_IN"),
        new("Anderson", 3301240, 322, "CR Flamengo", 301266, "Caxias", "CR Flamengo", "LOANED_OUT"),
        new("Édson Araújo", 308345, 319, "SC Corinthians Paulista", 104750, "Fortaleza", "SC Corinthians Paulista", "LOANED_OUT"),
        new("Luciano Ratinho", 6900008, 319, "SC Corinthians Paulista", 324, "Grêmio", "SC Corinthians Paulista", "LOANED_OUT"),
        new("Marcelo Magalhães", 302580, 319, "SC Corinthians Paulista", 324, "Grêmio", "SC Corinthians Paulista", "LOANED_OUT")
    ];

    public async Task<LoanRelationshipDiagnosticReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source))
            throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);

        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();

        progress?.Report("Extraindo clubes e contratos...");
        Fm2005ClubParseResult clubs = new Fm2005ClubParser().Parse(data, cancellationToken);
        Fm2005PlayerContractParseResult contracts = new Fm2005PlayerContractHeaderParser()
            .Parse(data, source, sha, progress, cancellationToken);

        Dictionary<uint, Club> clubBySaveIndex = clubs.Clubs.ToDictionary(x => x.SaveIndex);
        Dictionary<uint, Club> clubByDatabaseId = clubs.Clubs.ToDictionary(x => x.DatabaseId);
        Dictionary<uint, PlayerContractHeader> contractByPerson = contracts.Contracts
            .GroupBy(x => x.PersonDatabaseId)
            .ToDictionary(g => g.Key, g => g.OrderByDescending(x => x.ConfidenceScore).First());

        var hits = new List<LoanClubReferenceHit>();
        var caseResults = new List<LoanRelationshipCaseResult>();

        foreach (KnownLoanCase known in KnownCases)
        {
            cancellationToken.ThrowIfCancellationRequested();
            progress?.Report($"Analisando empréstimo: {known.Player}...");

            clubByDatabaseId.TryGetValue(known.OwnerClubDatabaseId, out Club? ownerClub);
            clubByDatabaseId.TryGetValue(known.ActiveClubDatabaseId, out Club? activeClub);
            contractByPerson.TryGetValue(known.PersonDatabaseId, out PlayerContractHeader? contract);

            if (contract is null)
            {
                caseResults.Add(new LoanRelationshipCaseResult(
                    known.Player, known.PersonDatabaseId, false, null, null, null,
                    ownerClub?.SaveIndex, activeClub?.SaveIndex, false, 0, 0,
                    "CONTRACT_NOT_FOUND"));
                continue;
            }

            int start = checked((int)contract.RecordStartOffset);
            int dbidOffset = checked((int)contract.PersonDatabaseIdOffset);
            int end = Math.Min(data.Length, dbidOffset + 5);
            ScanClubReferences(data, start, end, start, dbidOffset, known, contract,
                clubBySaveIndex, hits);

            LoanClubReferenceHit[] personHits = hits
                .Where(x => x.PersonDatabaseId == known.PersonDatabaseId)
                .ToArray();
            int ownerHits = personHits.Count(x => x.IsExpectedOwnerClub && !x.IsContractClub);
            int distinctClubs = personHits.Select(x => x.ClubDatabaseId).Distinct().Count();
            bool activeConfirmed = contract.CurrentClubDatabaseId == known.ActiveClubDatabaseId;
            string assessment = activeConfirmed && ownerHits > 0
                ? "LOAN_RELATIONSHIP_CANDIDATE"
                : activeConfirmed
                    ? "ACTIVE_CLUB_CONFIRMED_OWNER_NOT_FOUND"
                    : "ACTIVE_CLUB_MISMATCH";

            caseResults.Add(new LoanRelationshipCaseResult(
                known.Player,
                known.PersonDatabaseId,
                true,
                contract.CurrentClubSaveIndex,
                contract.CurrentClubDatabaseId,
                contract.CurrentClubName,
                ownerClub?.SaveIndex,
                activeClub?.SaveIndex,
                activeConfirmed,
                ownerHits,
                distinctClubs,
                assessment));
        }

        LoanOwnerOffsetSummary[] summaries = BuildOwnerOffsetSummaries(hits);
        var report = new LoanRelationshipDiagnosticReport(
            source, data.LongLength, sha, KnownCases, caseResults, hits, summaries,
            contracts.Contracts.Count, output, DateTimeOffset.UtcNow);

        progress?.Report("Gravando relatórios de empréstimo...");
        await File.WriteAllTextAsync(Path.Combine(output, "loan-relationship-report.txt"),
            FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "loan-known-cases.csv"),
            FormatKnownCasesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "loan-case-results.csv"),
            FormatCaseResultsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "loan-club-reference-hits.csv"),
            FormatHitsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "loan-owner-offset-summaries.csv"),
            FormatSummariesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "loan-record-contexts.txt"),
            FormatContexts(report, data), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "loan-unresolved.txt"),
            FormatUnresolved(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);

        progress?.Report("Diagnóstico de empréstimos concluído.");
        return report;
    }

    private static void ScanClubReferences(
        byte[] data,
        int start,
        int end,
        int recordStart,
        int dbidOffset,
        KnownLoanCase known,
        PlayerContractHeader contract,
        IReadOnlyDictionary<uint, Club> clubBySaveIndex,
        List<LoanClubReferenceHit> output)
    {
        for (int offset = start; offset < end; offset++)
        {
            if (clubBySaveIndex.TryGetValue(data[offset], out Club? byteClub))
                AddHit("BYTE", offset, data[offset], byteClub);

            if (offset + 2 <= end)
            {
                ushort value16 = BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(offset, 2));
                if (clubBySaveIndex.TryGetValue(value16, out Club? club16))
                    AddHit("UINT16", offset, value16, club16);
            }

            if (offset + 4 <= end)
            {
                uint value32 = BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(offset, 4));
                if (clubBySaveIndex.TryGetValue(value32, out Club? club32))
                    AddHit("UINT32", offset, value32, club32);
            }
        }

        void AddHit(string width, int absoluteOffset, uint saveIndex, Club club)
        {
            int relRecord = absoluteOffset - recordStart;
            int relDbid = absoluteOffset - dbidOffset;
            bool isContract = club.DatabaseId == contract.CurrentClubDatabaseId && relRecord == 5;
            bool isOwner = club.DatabaseId == known.OwnerClubDatabaseId;
            bool isActive = club.DatabaseId == known.ActiveClubDatabaseId;
            string region = relRecord switch
            {
                0 => "RECORD_INTERNAL_KEY",
                5 => "CONFIRMED_CONTRACT_CLUB",
                >= 17 when absoluteOffset < dbidOffset - 8 => "VARIABLE_PAYLOAD",
                >= 0 when absoluteOffset < dbidOffset => "CONTRACT_HEADER_OR_TAIL",
                _ => "POST_DBID"
            };
            string assessment = isContract
                ? "CONFIRMED_ACTIVE_CLUB_FIELD"
                : isOwner
                    ? "EXPECTED_OWNER_CLUB_CANDIDATE"
                    : isActive
                        ? "ACTIVE_CLUB_DUPLICATE_OR_FLAG"
                        : "OTHER_VALID_CLUB_REFERENCE";

            output.Add(new LoanClubReferenceHit(
                known.Player, known.PersonDatabaseId, width, absoluteOffset,
                relRecord, relDbid, saveIndex, club.DatabaseId, club.FullName,
                isContract, isOwner, isActive, region, assessment));
        }
    }

    private static LoanOwnerOffsetSummary[] BuildOwnerOffsetSummaries(
        IReadOnlyList<LoanClubReferenceHit> hits)
    {
        IEnumerable<LoanOwnerOffsetSummary> fromRecord = hits
            .Where(x => x.IsExpectedOwnerClub && !x.IsContractClub)
            .GroupBy(x => new { x.ReferenceWidth, x.RelativeToRecordStart })
            .Select(g => Create(g.Key.ReferenceWidth, "RECORD_START", g.Key.RelativeToRecordStart, g));

        IEnumerable<LoanOwnerOffsetSummary> fromDbid = hits
            .Where(x => x.IsExpectedOwnerClub && !x.IsContractClub)
            .GroupBy(x => new { x.ReferenceWidth, x.RelativeToDatabaseId })
            .Select(g => Create(g.Key.ReferenceWidth, "PERSON_DATABASE_ID", g.Key.RelativeToDatabaseId, g));

        return fromRecord.Concat(fromDbid)
            .OrderByDescending(x => x.PlayersCovered)
            .ThenByDescending(x => x.HitCount)
            .ThenBy(x => Math.Abs(x.RelativeOffset))
            .ToArray();

        static LoanOwnerOffsetSummary Create(
            string width,
            string anchor,
            int relativeOffset,
            IEnumerable<LoanClubReferenceHit> group)
        {
            LoanClubReferenceHit[] rows = group.ToArray();
            int players = rows.Select(x => x.PersonDatabaseId).Distinct().Count();
            string assessment = players >= 4
                ? "OWNER_CLUB_OFFSET_STRONG"
                : players >= 3
                    ? "OWNER_CLUB_OFFSET_MEDIUM"
                    : players >= 2
                        ? "OWNER_CLUB_OFFSET_WEAK"
                        : "ISOLATED";
            return new LoanOwnerOffsetSummary(
                width, anchor, relativeOffset, players, rows.Length,
                string.Join(" | ", rows.Select(x => x.Player).Distinct()), assessment);
        }
    }

    public static string FormatReportForUi(LoanRelationshipDiagnosticReport report) =>
        FormatReport(report);

    public static string FormatReport(LoanRelationshipDiagnosticReport report)
    {
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — LoanRelationshipDiagnostic 0.0.28.7");
        sb.AppendLine(new string('=', 94));
        sb.AppendLine($"Arquivo: {report.SourceFile}");
        sb.AppendLine($"Tamanho: {report.SourceSize:N0} bytes");
        sb.AppendLine($"SHA-256: {report.Sha256}");
        sb.AppendLine($"Contratos extraídos pelo parser: {report.ContractsParsed:N0}");
        sb.AppendLine($"Casos controlados: {report.KnownCases.Count}");
        sb.AppendLine($"Contratos encontrados: {report.Cases.Count(x => x.ContractFound)}/{report.Cases.Count}");
        sb.AppendLine($"Clube ativo confirmado: {report.Cases.Count(x => x.ActiveClubConfirmed)}/{report.Cases.Count}");
        sb.AppendLine($"Hits de clube no registro: {report.Hits.Count:N0}");
        sb.AppendLine();
        sb.AppendLine("Casos:");
        foreach (LoanRelationshipCaseResult row in report.Cases)
            sb.AppendLine($"  {row.Player,-20} contrato={row.ContractClub ?? "-",-24} ownerHits={row.OwnerReferenceHits,3} clubes={row.DistinctClubReferences,3} | {row.Assessment}");
        sb.AppendLine();
        sb.AppendLine("Melhores offsets do clube proprietário:");
        foreach (LoanOwnerOffsetSummary row in report.OwnerOffsetSummaries.Take(30))
            sb.AppendLine($"  {row.ReferenceWidth,-6} {row.AlignmentAnchor,-18} rel={row.RelativeOffset,5} jogadores={row.PlayersCovered} hits={row.HitCount} | {row.Assessment} | {row.Players}");
        sb.AppendLine();
        sb.AppendLine("Arquivos: loan-known-cases.csv, loan-case-results.csv, loan-club-reference-hits.csv, loan-owner-offset-summaries.csv, loan-record-contexts.txt e loan-unresolved.txt.");
        sb.AppendLine("O save não foi modificado.");
        return sb.ToString();
    }

    private static string FormatKnownCasesCsv(LoanRelationshipDiagnosticReport report)
    {
        var sb = new StringBuilder("player,person_database_id,owner_club_database_id,owner_club,active_club_database_id,active_club,roster_context_club,expected_direction\r\n");
        foreach (KnownLoanCase x in report.KnownCases)
            sb.AppendLine(string.Join(',', Csv(x.Player), x.PersonDatabaseId, x.OwnerClubDatabaseId, Csv(x.OwnerClub), x.ActiveClubDatabaseId, Csv(x.ActiveClub), Csv(x.RosterContextClub), x.ExpectedDirection));
        return sb.ToString();
    }

    private static string FormatCaseResultsCsv(LoanRelationshipDiagnosticReport report)
    {
        var sb = new StringBuilder("player,person_database_id,contract_found,contract_club_save_index,contract_club_database_id,contract_club,expected_owner_save_index,expected_active_save_index,active_club_confirmed,owner_reference_hits,distinct_club_references,assessment\r\n");
        foreach (LoanRelationshipCaseResult x in report.Cases)
            sb.AppendLine(string.Join(',', Csv(x.Player), x.PersonDatabaseId, x.ContractFound,
                Nullable(x.ContractClubSaveIndex), Nullable(x.ContractClubDatabaseId), Csv(x.ContractClub),
                Nullable(x.ExpectedOwnerSaveIndex), Nullable(x.ExpectedActiveSaveIndex), x.ActiveClubConfirmed,
                x.OwnerReferenceHits, x.DistinctClubReferences, x.Assessment));
        return sb.ToString();
    }

    private static string FormatHitsCsv(LoanRelationshipDiagnosticReport report)
    {
        var sb = new StringBuilder("player,person_database_id,width,absolute_offset,relative_record_start,relative_database_id,club_save_index,club_database_id,club_name,is_contract_club,is_expected_owner,is_expected_active,region,assessment\r\n");
        foreach (LoanClubReferenceHit x in report.Hits)
            sb.AppendLine(string.Join(',', Csv(x.Player), x.PersonDatabaseId, x.ReferenceWidth,
                $"0x{x.AbsoluteOffset:X8}", x.RelativeToRecordStart, x.RelativeToDatabaseId,
                x.ClubSaveIndex, x.ClubDatabaseId, Csv(x.ClubName), x.IsContractClub,
                x.IsExpectedOwnerClub, x.IsExpectedActiveClub, x.Region, x.Assessment));
        return sb.ToString();
    }

    private static string FormatSummariesCsv(LoanRelationshipDiagnosticReport report)
    {
        var sb = new StringBuilder("width,anchor,relative_offset,players_covered,hit_count,players,assessment\r\n");
        foreach (LoanOwnerOffsetSummary x in report.OwnerOffsetSummaries)
            sb.AppendLine(string.Join(',', x.ReferenceWidth, x.AlignmentAnchor, x.RelativeOffset,
                x.PlayersCovered, x.HitCount, Csv(x.Players), x.Assessment));
        return sb.ToString();
    }

    private static string FormatContexts(LoanRelationshipDiagnosticReport report, byte[] data)
    {
        var sb = new StringBuilder();
        foreach (LoanRelationshipCaseResult caseRow in report.Cases)
        {
            sb.AppendLine($"[{caseRow.Player}] DBID={caseRow.PersonDatabaseId} contrato={caseRow.ContractClub ?? "NÃO ENCONTRADO"} | {caseRow.Assessment}");
            foreach (LoanClubReferenceHit hit in report.Hits.Where(x => x.PersonDatabaseId == caseRow.PersonDatabaseId))
            {
                int center = checked((int)hit.AbsoluteOffset);
                int start = Math.Max(0, center - ContextBefore);
                int length = Math.Min(data.Length - start, ContextBefore + ContextAfter + 4);
                sb.AppendLine($"  {hit.Assessment,-31} {hit.ReferenceWidth,-6} relRecord={hit.RelativeToRecordStart,5} relDBID={hit.RelativeToDatabaseId,5} clube={hit.ClubName} ({hit.ClubSaveIndex})");
                sb.AppendLine($"  offset=0x{hit.AbsoluteOffset:X8} bytes={Convert.ToHexString(data.AsSpan(start, length))}");
            }
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string FormatUnresolved(LoanRelationshipDiagnosticReport report)
    {
        var sb = new StringBuilder();
        foreach (LoanRelationshipCaseResult row in report.Cases.Where(x => !x.ContractFound || !x.ActiveClubConfirmed || x.OwnerReferenceHits == 0))
            sb.AppendLine($"{row.Player} | DBID={row.PersonDatabaseId} | {row.Assessment} | contrato={row.ContractClub ?? "-"} | ownerHits={row.OwnerReferenceHits}");
        return sb.ToString();
    }

    private static string Nullable(uint? value) => value?.ToString(CultureInfo.InvariantCulture) ?? string.Empty;
    private static string Csv(string? value) => '"' + (value ?? string.Empty).Replace("\"", "\"\"") + '"';
}
