using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using FMGenieScout2005.Core.Models;

namespace FMGenieScout2005.Core.Diagnostics;

public sealed class PostIdPlayerRecordFieldDiagnostic
{
    private const int PostIdEnd = 136;
    private static readonly KnownPostIdPlayer[] Players =
    [
        new("Jean", 315116, 2001, "CR Flamengo"),
        new("Athirson", 3301535, 2004, "CR Flamengo"),
        new("Andrezinho", 302728, null, "CR Flamengo"),
        new("André Bahia", 311169, null, "CR Flamengo"),
        new("Dimba", 303048, null, "CR Flamengo"),
        new("Douglas Silva", 3300410, null, "CR Flamengo"),
        new("Fabiano Eller", 3300219, null, "CR Flamengo"),
        new("Júlio César Moraes", 8825041, null, "CR Flamengo"),
        new("Júnior Baiano", 6900111, null, "CR Flamengo"),
        new("Reginaldo Araújo", 3300780, null, "CR Flamengo"),
        new("Édson Araújo", 308345, null, "SC Corinthians Paulista"),
        new("Fábio Baiano", 3300471, null, "SC Corinthians Paulista"),
        new("Fábio Costa", 6900151, null, "SC Corinthians Paulista"),
        new("Luciano Ratinho", 6900008, null, "SC Corinthians Paulista"),
        new("Marcelo Magalhães", 302580, null, "SC Corinthians Paulista"),
        new("Bruno Octávio", 8832887, null, "SC Corinthians Paulista"),
        new("Alessandro", 3902245, null, "SC Corinthians Paulista"),
        new("Rosinei", 316596, null, "SC Corinthians Paulista"),
        new("Dinélson", 320774, null, "SC Corinthians Paulista")
    ];

    public async Task<PostIdPlayerRecordFieldReport> AnalyzeAsync(
        string inputFile,
        string outputDirectory,
        IProgress<string>? progress = null,
        CancellationToken cancellationToken = default)
    {
        string source = Path.GetFullPath(inputFile);
        if (!File.Exists(source)) throw new FileNotFoundException("O arquivo game_db.payload.bin não existe.", source);
        string output = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(output);

        progress?.Report("Lendo game_db.payload.bin...");
        byte[] data = await File.ReadAllBytesAsync(source, cancellationToken).ConfigureAwait(false);
        string sha = Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();

        progress?.Report("Selecionando registros ricos de jogadores...");
        var anchors = new List<PostIdPlayerAnchor>();
        foreach (KnownPostIdPlayer player in Players)
        {
            cancellationToken.ThrowIfCancellationRequested();
            List<int> candidates = FindUInt32(data, player.DatabaseId);
            if (candidates.Count == 0) continue;
            (int Offset, double Score) best = candidates
                .Select(x => (Offset: x, Score: ScoreCandidate(data, x, player.ContractStartYear)))
                .OrderByDescending(x => x.Score)
                .ThenBy(x => x.Offset)
                .First();
            if (!CanRead(data, best.Offset - 8L, PostIdEnd + 8)) continue;
            uint startYear = ReadUInt32(data, best.Offset - 8L);
            uint internalKey = ReadUInt32(data, best.Offset - 4L);
            byte subtype = data[best.Offset + 4];
            string assessment = best.Score >= 120 ? "RICH_PLAYER_RECORD_STRONG" : best.Score >= 70 ? "RICH_PLAYER_RECORD_MEDIUM" : "RICH_PLAYER_RECORD_WEAK";
            anchors.Add(new PostIdPlayerAnchor(player.Name, player.DatabaseId, best.Offset, candidates.Count, best.Score, startYear, internalKey, subtype, assessment));
        }

        progress?.Report("Mapeando o bloco fixo pós-DBID...");
        var fields = new List<PostIdFieldValue>();
        foreach (PostIdPlayerAnchor anchor in anchors)
        {
            for (int rel = -8; rel <= PostIdEnd; rel++)
            {
                long pos = anchor.AnchorOffset + rel;
                if (CanRead(data, pos, 1)) AddField(fields, anchor, rel, "BYTE", data[(int)pos], data[(int)pos], Convert.ToHexString(data.AsSpan((int)pos, 1)), rel >= 0);
                if ((rel & 1) == 0 && CanRead(data, pos, 2))
                {
                    ushort u16 = BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan((int)pos, 2));
                    short i16 = BinaryPrimitives.ReadInt16LittleEndian(data.AsSpan((int)pos, 2));
                    AddField(fields, anchor, rel, "UINT16", i16, u16, Convert.ToHexString(data.AsSpan((int)pos, 2)), true);
                }
                if ((rel & 3) == 0 && CanRead(data, pos, 4))
                {
                    uint u32 = BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan((int)pos, 4));
                    int i32 = BinaryPrimitives.ReadInt32LittleEndian(data.AsSpan((int)pos, 4));
                    AddField(fields, anchor, rel, "UINT32", i32, u32, Convert.ToHexString(data.AsSpan((int)pos, 4)), true);
                }
            }
        }

        List<PostIdFieldSummary> summaries = BuildSummaries(fields, anchors.Count);

        progress?.Report("Procurando globalmente a chave interna em DBID−4...");
        var keyOccurrences = new List<InternalKeyOccurrence>();
        foreach (PostIdPlayerAnchor anchor in anchors)
        {
            foreach (int occurrence in FindUInt32(data, anchor.InternalKey))
            {
                if (occurrence == anchor.AnchorOffset - 4) continue;
                int rel = checked((int)(occurrence - anchor.AnchorOffset));
                int start = Math.Max(0, occurrence - 24);
                int length = Math.Min(56, data.Length - start);
                string context = Convert.ToHexString(data.AsSpan(start, length));
                string assessment = Math.Abs(rel) <= 4096 ? "NEAR_SOURCE_RECORD" : "GLOBAL_REFERENCE";
                keyOccurrences.Add(new InternalKeyOccurrence(anchor.Player, anchor.InternalKey, anchor.AnchorOffset, occurrence, rel, context, assessment));
            }
        }

        var report = new PostIdPlayerRecordFieldReport(source, data.LongLength, sha, anchors, fields, summaries, keyOccurrences, output, DateTimeOffset.UtcNow);
        await File.WriteAllTextAsync(Path.Combine(output, "post-id-player-record-report.txt"), FormatReport(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "post-id-player-anchors.csv"), FormatAnchorsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "post-id-field-values.csv"), FormatFieldsCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "post-id-field-summaries.csv"), FormatSummariesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "post-id-offset-matrix.csv"), FormatMatrixCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "internal-key-occurrences.csv"), FormatKeyOccurrencesCsv(report), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        await File.WriteAllTextAsync(Path.Combine(output, "post-id-record-contexts.txt"), FormatContexts(report, data), new UTF8Encoding(true), cancellationToken).ConfigureAwait(false);
        progress?.Report("Mapeamento do bloco fixo pós-DBID concluído.");
        return report;
    }

    private static double ScoreCandidate(byte[] data, int offset, int? expectedStartYear)
    {
        if (!CanRead(data, offset - 8L, PostIdEnd + 8)) return double.MinValue;
        double score = 0;
        uint marker = ReadUInt32(data, offset - 8L);
        if (marker == 189) score -= 150;
        if (expectedStartYear.HasValue && marker == expectedStartYear.Value) score += 140;
        else if (marker is >= 1900 and <= 2030) score += 60;
        if (data[offset + 4] == 2) score += 45;
        if (ReadUInt32(data, offset + 19L) == uint.MaxValue) score += 30;
        if (ReadUInt32(data, offset + 130L) == uint.MaxValue) score += 15;
        if (ReadUInt32(data, offset + 135L) == uint.MaxValue) score += 15;
        int zeros = 0;
        for (int rel = 40; rel <= 105; rel++) if (data[offset + rel] == 0) zeros++;
        score += zeros / 4.0;
        return score;
    }

    private static void AddField(List<PostIdFieldValue> output, PostIdPlayerAnchor anchor, int rel, string type, long signed, ulong unsigned, string hex, bool aligned) =>
        output.Add(new PostIdFieldValue(anchor.Player, anchor.DatabaseId, anchor.AnchorOffset, rel, type, signed, unsigned, hex, Category(unsigned, type), aligned));

    private static List<PostIdFieldSummary> BuildSummaries(IReadOnlyList<PostIdFieldValue> fields, int playerCount)
    {
        var result = new List<PostIdFieldSummary>();
        foreach (IGrouping<(int RelativeOffset, string DataType), PostIdFieldValue> group in fields.GroupBy(x => (x.RelativeOffset, x.DataType)).OrderBy(x => x.Key.RelativeOffset).ThenBy(x => x.Key.DataType))
        {
            PostIdFieldValue[] values = group.ToArray();
            int distinct = values.Select(x => x.UnsignedValue).Distinct().Count();
            bool sameCategory = values.Select(x => x.Category).Distinct().Count() == 1;
            bool duplicate = false;
            if (group.Key.DataType == "UINT16")
            {
                Dictionary<string, PostIdFieldValue> previous = fields.Where(x => x.RelativeOffset == group.Key.RelativeOffset - 2 && x.DataType == "UINT16").ToDictionary(x => x.Player);
                duplicate = values.Count(v => previous.TryGetValue(v.Player, out PostIdFieldValue? p) && p.UnsignedValue == v.UnsignedValue) >= Math.Max(2, playerCount / 2);
            }
            string assessment = values.Count() < Math.Max(2, playerCount / 2) ? "LOW_COVERAGE"
                : distinct == 1 ? "FIELD_CONSTANT"
                : duplicate ? "DUPLICATED_FIELD_PATTERN"
                : sameCategory ? "STRUCTURALLY_STABLE_FIELD"
                : "VARIABLE_FIELD";
            string list = string.Join(" | ", values.Select(x => $"{x.Player}={x.UnsignedValue.ToString(CultureInfo.InvariantCulture)}"));
            result.Add(new PostIdFieldSummary(group.Key.RelativeOffset, group.Key.DataType, values.Length, distinct,
                values.Count(x => x.UnsignedValue == 0), values.Count(x => x.UnsignedValue == uint.MaxValue), sameCategory, duplicate, list, assessment));
        }
        return result;
    }

    private static string Category(ulong value, string type) => value switch
    {
        0 => "ZERO",
        uint.MaxValue => "FFFFFFFF",
        <= 1 => "FLAG",
        <= 255 => type == "BYTE" ? "BYTE" : "SMALL",
        <= 65535 => "UINT16_RANGE",
        <= 10_000_000 => "VALUE",
        _ => "LARGE"
    };

    private static List<int> FindUInt32(byte[] data, uint value)
    {
        byte b0 = (byte)value, b1 = (byte)(value >> 8), b2 = (byte)(value >> 16), b3 = (byte)(value >> 24);
        var result = new List<int>();
        for (int i = 0; i <= data.Length - 4; i++) if (data[i] == b0 && data[i + 1] == b1 && data[i + 2] == b2 && data[i + 3] == b3) result.Add(i);
        return result;
    }

    private static bool CanRead(byte[] data, long offset, int width) => offset >= 0 && offset + width <= data.LongLength;
    private static uint ReadUInt32(byte[] data, long offset) => BinaryPrimitives.ReadUInt32LittleEndian(data.AsSpan(checked((int)offset), 4));
    private static string Csv(string? value) => '"' + (value ?? string.Empty).Replace("\"", "\"\"") + '"';

    public static string FormatReportForUi(PostIdPlayerRecordFieldReport report) => FormatReport(report);

    private static string FormatReport(PostIdPlayerRecordFieldReport report)
    {
        var sb = new StringBuilder();
        sb.AppendLine("FM Genie Scout 2005 — PostIdPlayerRecordFieldDiagnostic 0.0.28.4");
        sb.AppendLine(new string('=', 92));
        sb.AppendLine($"Arquivo: {report.SourceFile}");
        sb.AppendLine($"Tamanho: {report.SourceSize:N0} bytes");
        sb.AppendLine($"SHA-256: {report.Sha256}");
        sb.AppendLine($"Jogadores ancorados: {report.Anchors.Count}/{Players.Length}");
        sb.AppendLine($"Campos lidos: {report.Fields.Count:N0}");
        sb.AppendLine($"Resumos estruturais: {report.Summaries.Count:N0}");
        sb.AppendLine($"Referências adicionais da chave DBID−4: {report.InternalKeyOccurrences.Count:N0}");
        sb.AppendLine();
        sb.AppendLine("Âncoras selecionadas:");
        foreach (PostIdPlayerAnchor x in report.Anchors) sb.AppendLine($"  {x.Player,-24} dbid={x.DatabaseId,8} offset=0x{x.AnchorOffset:X8} start={x.ContractStartYear,4} key={x.InternalKey,6} subtype={x.RecordSubtype} score={x.SelectionScore:F1} {x.Assessment}");
        sb.AppendLine();
        sb.AppendLine("Campos mais estáveis:");
        foreach (PostIdFieldSummary x in report.Summaries.Where(x => x.Assessment is "FIELD_CONSTANT" or "DUPLICATED_FIELD_PATTERN" or "STRUCTURALLY_STABLE_FIELD").Take(40))
            sb.AppendLine($"  rel={x.RelativeOffset,4} {x.DataType,-6} n={x.PlayerCount,2} distinct={x.DistinctValueCount,2} {x.Assessment}");
        sb.AppendLine();
        sb.AppendLine("Arquivos: post-id-player-anchors.csv, post-id-field-values.csv, post-id-field-summaries.csv, post-id-offset-matrix.csv, internal-key-occurrences.csv e post-id-record-contexts.txt.");
        sb.AppendLine("O save não foi modificado.");
        return sb.ToString();
    }

    private static string FormatAnchorsCsv(PostIdPlayerRecordFieldReport r)
    {
        var sb = new StringBuilder("player,database_id,anchor_offset,candidate_count,selection_score,contract_start_year,internal_key,record_subtype,assessment\r\n");
        foreach (PostIdPlayerAnchor x in r.Anchors) sb.AppendLine($"{Csv(x.Player)},{x.DatabaseId},0x{x.AnchorOffset:X8},{x.CandidateCount},{x.SelectionScore.ToString("F3", CultureInfo.InvariantCulture)},{x.ContractStartYear},{x.InternalKey},{x.RecordSubtype},{x.Assessment}");
        return sb.ToString();
    }

    private static string FormatFieldsCsv(PostIdPlayerRecordFieldReport r)
    {
        var sb = new StringBuilder("player,database_id,anchor_offset,relative_offset,data_type,signed_value,unsigned_value,hex,category,aligned\r\n");
        foreach (PostIdFieldValue x in r.Fields) sb.AppendLine($"{Csv(x.Player)},{x.DatabaseId},0x{x.AnchorOffset:X8},{x.RelativeOffset},{x.DataType},{x.SignedValue},{x.UnsignedValue},{x.Hex},{x.Category},{x.Aligned}");
        return sb.ToString();
    }

    private static string FormatSummariesCsv(PostIdPlayerRecordFieldReport r)
    {
        var sb = new StringBuilder("relative_offset,data_type,player_count,distinct_value_count,zero_count,ffffffff_count,same_category,duplicate_with_previous,assessment,values\r\n");
        foreach (PostIdFieldSummary x in r.Summaries) sb.AppendLine($"{x.RelativeOffset},{x.DataType},{x.PlayerCount},{x.DistinctValueCount},{x.ZeroCount},{x.FfffffffCount},{x.SameCategoryAcrossPlayers},{x.DuplicateWithPreviousField},{x.Assessment},{Csv(x.Values)}");
        return sb.ToString();
    }

    private static string FormatMatrixCsv(PostIdPlayerRecordFieldReport r)
    {
        string[] players = r.Anchors.Select(x => x.Player).ToArray();
        var sb = new StringBuilder("relative_offset,data_type");
        foreach (string p in players) sb.Append(',').Append(Csv(p));
        sb.AppendLine();
        foreach (var group in r.Fields.Where(x => x.Aligned).GroupBy(x => (x.RelativeOffset, x.DataType)).OrderBy(x => x.Key.RelativeOffset).ThenBy(x => x.Key.DataType))
        {
            Dictionary<string, PostIdFieldValue> map = group.ToDictionary(x => x.Player);
            sb.Append(group.Key.RelativeOffset).Append(',').Append(group.Key.DataType);
            foreach (string p in players) sb.Append(',').Append(map.TryGetValue(p, out PostIdFieldValue? v) ? v.UnsignedValue.ToString(CultureInfo.InvariantCulture) : string.Empty);
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string FormatKeyOccurrencesCsv(PostIdPlayerRecordFieldReport r)
    {
        var sb = new StringBuilder("player,internal_key,source_anchor,occurrence_offset,relative_to_source,assessment,context_hex\r\n");
        foreach (InternalKeyOccurrence x in r.InternalKeyOccurrences) sb.AppendLine($"{Csv(x.Player)},{x.InternalKey},0x{x.SourceAnchor:X8},0x{x.OccurrenceOffset:X8},{x.RelativeToSource},{x.Assessment},{x.ContextHex}");
        return sb.ToString();
    }

    private static string FormatContexts(PostIdPlayerRecordFieldReport r, byte[] data)
    {
        var sb = new StringBuilder();
        foreach (PostIdPlayerAnchor x in r.Anchors)
        {
            int start = checked((int)Math.Max(0, x.AnchorOffset - 32));
            int length = Math.Min(208, data.Length - start);
            sb.AppendLine($"[{x.Player}] DBID={x.DatabaseId} anchor=0x{x.AnchorOffset:X8} startYear={x.ContractStartYear} internalKey={x.InternalKey} subtype={x.RecordSubtype}");
            sb.AppendLine(Convert.ToHexString(data.AsSpan(start, length)));
            sb.AppendLine();
        }
        return sb.ToString();
    }
}
